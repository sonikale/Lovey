# matching-backend

 local.settings.json configurations
 {
    "IsEncrypted": false,
    "Values": {
        "AzureWebJobsStorage": "",
        "FUNCTIONS_WORKER_RUNTIME": "node",
        "DATABASE_NAME": "loveymatch_db",
        "DATABASE_USERNAME": "loveyadmin",
        "DATABASE_PASSWORD": "Harbinger@2023",
        "DATABASE_HOST": "loveypgsql.postgres.database.azure.com",
        "DATABASE_DIALECT": "postgres",
        "JWT_SECRET": "vnbsjksajkdcbkjfgblmcv",
        "AZURE_STORAGE_CONNECTION_STRING": "DefaultEndpointsProtocol=https;AccountName=loveyappstorage;AccountKey=Z4LNJ6rJh04AIvDTjJcuEoP01ndmWi2EgfQn5EqXNLBv1P3V+7mLaq7h0CrOJSF2hvmuMZkog0tL+AStWyeWPw==;EndpointSuffix=core.windows.net",
        "AZURE_BLOB_CONTAINER_NAME": "userimages",
        "STRIPE_KEY": "sk_test_51NGO7fLoBlCpfXpsdMY5VN2olK4Ie3r0vAVCOnupJ8sDt2BgPZWRi9GuWIMQvuO8cXOABwCIFa190k8kxvNAL1QV00EuLtrbJt"
        "AZURE_COMMUNICATION_CONNECTION_STRING": "endpoint=https://loveycommservice.unitedstates.communication.azure.com/;accesskey=MUeUcvWO+e6nwXxKG8jDv2u0LGlLaUIf0kyGYdL2HBBaVyPRB7o3wgkbkZkE/8nqh+Aa9HN6gyre8auGdQaPZQ==",
        "AZURE_COMMUNICATION_ENDPOINT":"https://loveycommservice.unitedstates.communication.azure.com/",
        "CLICKSEND_USERNAME": "Sayali.M@harbingergroup.com",
        "CLICKSEND_API_KEY":"3EAE6B8B-247E-CAE5-1D6A-FF6ABDD20E02",
         "CRYPTO_SECRET": "LOVEY_HARBINGER",
        "AZURE_SENDER_ADDRESS":"donotreply@7a882b7e-42b2-4746-9aca-741bb1a22033.azurecomm.net",
        "COUNTRY_CODE": "+1"

    }
}

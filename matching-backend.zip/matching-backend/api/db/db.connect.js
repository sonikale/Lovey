import { Sequelize } from 'sequelize';

const sequelize = new Sequelize(process.env['DATABASE_NAME'], process.env['DATABASE_USERNAME'], process.env['DATABASE_PASSWORD'], {
    host: process.env['DATABASE_HOST'],
    dialect: process.env['DATABASE_DIALECT'],
    pool: {
        min: 0,
        max: 10,
        idle: 10000,
        acquire: 6000,
        evict: 1000,
    },
    dialectOptions: {
        prependSearchPath: true,
        ssl: true,
        multipleStatements: true,
    },
    define: {
        //prevent sequelize from pluralizing table names
        freezeTableName: true
    }
    //searchPath: process.env['DATABASE_SCHEMA']
});

export default sequelize;
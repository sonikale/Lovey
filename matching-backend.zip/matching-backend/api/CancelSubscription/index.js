import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import * as stripe from '../utils/stripe/stripe.js';
import { messages } from '../core/constants.js';
import subscriptionModel from '../models/custSubscription.model.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Cancel subscription API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.cancelSubscription, req.body);
            if (validSchema.isValidRequest) {
                const canceledSubscription = await stripe.cancelSubscription(req.body.subscriptionId);
                await subscriptionModel.update({ subscriptionStatus: canceledSubscription.status, message: messages.SUBSCRIPTION_CANCELLED, cancelReason: req.body.reason },
                    { where: { subscriptionStatus: 'active', subscriptionId: req.body.subscriptionId } });
                    
                context.log('Cancelled subscription successfully. Details: ', canceledSubscription);
                result = successResponse("Subscription cancelled successfully", canceledSubscription, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Cancel subscription API Error: " + error);
        result = errorResponse('Something went wrong while cancelling your subscription Please contact support', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
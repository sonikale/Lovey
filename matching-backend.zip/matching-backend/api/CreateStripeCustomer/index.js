import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as stripe from '../utils/stripe/stripe.js';
import stripeCustomerModel from '../models/stripeCustomer.model.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Create Stripe customer API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            let customer= {};
            const stripeCustomer = await stripeCustomerModel.findOne({ where: { userId: validateTokenResult.userDetails.dataValues.id } });
            if (!stripeCustomer) {
                customer = await stripe.createCustomer(validateTokenResult.userDetails.dataValues);
                const stripeCustPayload = {
                    userId: validateTokenResult.userDetails.dataValues.id,
                    customerId: customer.id,
                    strpCreated:  new Date(customer.created * 1000)
                };
                await stripeCustomerModel.create(stripeCustPayload);
            
            } else {
                customer = await stripe.retrieveCustomer(stripeCustomer.customerId);
            }
            context.log('Created stripe customer successfully for userId:', validateTokenResult.userDetails.dataValues.id);
            result = successResponse("Stripe customer created successfully.", customer, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Create Stripe customer API Error: " + error);
        result = errorResponse('Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as stripe from '../utils/stripe/stripe.js';
import custSubscriptionModel from '../models/custSubscription.model.js';
import * as schema from '../utils/schema.js';
import * as constants from '../core/constants.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Create Stripe Subscription API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.createSubscription, req.body);
            if (validSchema.isValidRequest) {
                const subscription = await stripe.createSubscription(req.body.customerId, req.body.priceId, req.body.coupon);

                let subscriptionPayload = {
                    userId: validateTokenResult.userDetails.dataValues.id,
                    customerId: req.body.customerId,
                    subscriptionId: subscription.id,
                    productId: req.body.priceId,
                    couponId: req.body.coupon,
                    couponCode: req.body.couponCode,
                    subscriptionStatus: subscription.status,
                    subscriptionEndDate: new Date(subscription.current_period_end * 1000),
                    message: constants.messages.SUBSCRIPTION_SUCCESS
                }

                await custSubscriptionModel.create(subscriptionPayload);
                context.log('subscription', subscription);
                context.log('subscriptionPayload', subscriptionPayload);

                // subscriptionPayload.clientSecret = subscription.latest_invoice.payment_intent.client_secret || null;
                subscriptionPayload.clientSecret = subscription && subscription.latest_invoice && subscription.latest_invoice.payment_intent && subscription.latest_invoice.payment_intent.client_secret;
                context.log('Subscription created successfully for userId:', validateTokenResult.userDetails.dataValues.id);
                result = successResponse("Subscribed successfully.", subscriptionPayload, StatusCodes.OK);
            } else {
                context.log('Invalid Schema. Details:', validSchema.error);
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Create Stripe Subscription API Error: " + error);
        result = errorResponse('Something went wrong while creating your subscription Please contact support.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
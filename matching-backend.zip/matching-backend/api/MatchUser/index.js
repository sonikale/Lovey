import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { Op, QueryTypes } from 'sequelize';
import sequelize from "../db/db.connect.js";
import { runAlgorithm } from '../utils/ruleEngine.js'
import { chatbotQuestionIds } from '../core/constants.js';

export default async function (context, req) {
  let result = "";

  try {
    //get user id in req.body
    let userId = req.body.userId
    await runAlgorithm(context, userId);
  } catch (error) {
    context.log("match user API Error. Details:", error);
    result = errorResponse(error.message.length > 0 ? error.message : 'Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
  }

  context.res = {
    status: result.statusCode,
    body: result
  }
}

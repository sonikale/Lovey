import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import imageModel from '../models/image.model.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("getUserProfile API START");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            delete validateTokenResult.userDetails.dataValues.password;
            delete validateTokenResult.userDetails.dataValues.jwttoken;
            delete validateTokenResult.userDetails.dataValues.fcmDeviceToken;
            validateTokenResult.userDetails.dataValues.profileImgName = '';
            validateTokenResult.userDetails.dataValues.profileImgUrl = '';

            // const imageData = await imageModel.findOne({  attributes : ['imageUrl','imageName'], where:{userId: validateTokenResult.userDetails.dataValues.id, isProfileImage: true}});
            const imageData = await imageModel.findAll({ where:{ userId: validateTokenResult.userDetails.dataValues.id }});
            const profileImage = imageData.find(o => o.isProfileImage);
            if(imageData.length > 0 && profileImage){
                validateTokenResult.userDetails.dataValues.profileImgName = profileImage.imageName;
                validateTokenResult.userDetails.dataValues.profileImgUrl = profileImage.imageUrl;
                validateTokenResult.userDetails.dataValues.allImages = imageData.map(i => i.imageUrl);
            } 
            context.log('User details fetched successfully for email:', validateTokenResult.userDetails.dataValues.email);
            result = successResponse("User details fetched successfully.", validateTokenResult.userDetails.dataValues, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("getUserProfile API Error. Details:",error);
        result = errorResponse('Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { getMatchProfile } from '../utils/common.util.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get Match profile Details API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const matchdDetails = await getMatchProfile(req.query.userId);
            context.log('Match profile details fetched successfully. Details:',req.query.userId);
            result = successResponse("Match profile details fetched successfully", matchdDetails, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get Match profile Details API Error: " + error);
        result = errorResponse('Something went wrong while getting Match profile details. Please contact admin.', StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
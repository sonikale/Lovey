import { QueryTypes } from 'sequelize';
import sequelize from "../db/db.connect.js";
import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { getUserProfile } from '../utils/common.util.js';
import * as schema from '../utils/schema.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("getPartnerProfile API START");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.getPartnerProfile, req.query);
            if (validSchema.isValidRequest) {
                let profileForFeedback = await getUserProfile(req.query.partnerUserId, true);

                //TO DO: calculate match and send
                let getMatchPercentage = await sequelize.query(`select "matchPercentage" from "servedMatches" where "partnerUserId"='${req.query.partnerUserId}' and "userId"='${validateTokenResult.userDetails.dataValues.id}'`, { type: QueryTypes.SELECT })
                profileForFeedback.matchPercentage = getMatchPercentage[0].matchPercentage;

                context.log('User profile for feedback fetched successfully for userId:', req.query.partnerUserId);
                result = successResponse("User profile fetched successfully.", profileForFeedback, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("getUserProfile API Error. Details:", error);
        result = errorResponse('Something went wrong while fetching the user profile. Please contact support.', StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
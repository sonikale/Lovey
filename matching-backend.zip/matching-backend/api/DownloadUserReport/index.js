import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import { messages } from '../core/constants.js';
import { exportDataToCSV } from '../utils/reports.util.js';

export default async function (context, req) {
    let result = "", report, reportCreated = false;

    try {
        context.log("Download user report API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.downloadUserReport, req.query);
            if (validSchema.isValidRequest) {
                report = await exportDataToCSV(context, req.query);
                reportCreated = true;
                context.log(`User report downloaded successfully`);
            } else {
                context.log('Invalid Schema. Details:', validSchema.error);
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Download user report API Error: " + error);
        result = errorResponse((error.message.length > 0) ? error.message : messages.DOWNLOAD_USER_REPORT_ERROR, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    if (reportCreated) {
        context.res = {
            status: 200,
            headers: {
                'Content-Type': 'text/csv',
                'Content-Disposition': `attachment; filename=user-report-${Date.now()}.csv`,
            },
            body: report
        };
    } else {
        context.res = {
            status: result.statusCode,
            body: result
        }
    }
}
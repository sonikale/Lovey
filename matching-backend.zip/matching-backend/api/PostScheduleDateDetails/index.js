import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import { messages } from '../core/constants.js';
import { postMatchDateSchedule } from '../utils/matchDateSchedule.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Post schedule date details API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.postScheduleDateDetails, req.body);
            if (validSchema.isValidRequest) {
                const dateScheduleDetails = await postMatchDateSchedule(validateTokenResult.userDetails.dataValues.id, req.body, context);
                context.log(`Updated date schedule successfully for user Id: ${validateTokenResult.userDetails.dataValues.id} and partner id: ${req.body.partnerUserId}`);
                result = successResponse(`${messages.POST_DATE_SCHEDULE_SUCCESS}`, dateScheduleDetails, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Post schedule date details API Error: " + error);
        result = errorResponse((error.message.length > 0) ? error.message : messages.POST_DATE_SCHEDULE_ERROR, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
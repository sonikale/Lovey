import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import * as schema from '../utils/schema.js';
import * as appRulesTemplates from '../templates/appRules.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get App Rules API Start");
        const validSchema = schema.validateRequest(schema.appRule, req.query);
        if (validSchema.isValidRequest) {
            let appRuleData = '';

            switch (req.query.appRuleType) {
                case 'PrivacyPolicy':
                    appRuleData = appRulesTemplates.rulesTemplate.privacyPolicy;
                    context.log('Privacy policy fetched successfully.');
                    break;
                case 'HelpAndSupport':
                    appRuleData = appRulesTemplates.rulesTemplate.helpAndSupport;
                    context.log('Help and support fetched successfully.');
                    break;
                case 'AboutUs':
                    appRuleData = appRulesTemplates.rulesTemplate.aboutUs;
                    context.log('About us fetched successfully.');
                    break;
                case 'TermsAndCondition':
                    appRuleData = appRulesTemplates.rulesTemplate.termsAndCondition;
                    context.log('Terms and Conditions fetched successfully.');
                    break;
                case 'SecurityPolicy':
                    appRuleData = appRulesTemplates.rulesTemplate.securityPolicy;
                    context.log('Security policy fetched successfully.');
                    break;
            }

            result = successResponse(`${req.query.appRuleType} fetched successfully.`, appRuleData, StatusCodes.OK);
        } else {
            context.log('Invalid Schema. Details:', validSchema.error);
            result = validationResponse(validSchema.error);
        }
    } catch (error) {
        context.log("Get App Rules API Error: " + error);
        result = errorResponse(`Something went wrong while getting ${req.query.appRule}. Please contact admin.`, StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}

const messages = {
    registerSuccessSubject: "Registration Successful - Lovey",
    registerSuccessBody: `Dear {{Users Name}},\n\n
    We are thrilled to welcome you to Lovey, the place where you find people that love like you do. Thank you for choosing us as your platform for creating meaningful relationships.\n
    Your Lovey App Account Details:\n
    Username: {{username}}
    Email Address:{{email}}
    Registration Date: {{registration date}}\n
    Now that you've joined Lovey, here's what you can look forward to:
    Connect with Amazing People: Start exploring matches and connect with like-minded individuals who share your interests and values.\n
    Personalized Matchmaking: Our advanced algorithms will work tirelessly to match you with potential partners based on your preferences.\n
    Safety and Privacy: Your security is our priority. We have robust safety measures in place to ensure a safe and secure environment for all users.\n
    Tips for Success: Discover expert tips and advice on building meaningful relationships in our blog and resources section.\n\n
    Get Started Now:\n
    1. Complete Your Profile: Add 4 pictures and complete your profile by chatting with Aphrodite your personal A.I Matchmaker to create your ideal match profile. \n
    2. Browse Matches: Start exploring matches and accept up to [3] per month. \n
    3. Setup the date: When you have a match, it is time to set up a date. There is no messaging until 2 hours before the date. \n\n
    
    
    If you ever need assistance or have any questions, our support team is here to help. You can reach us at support@lovey.ai.\n
    Once again, welcome to Lovey! We're excited to have you on board, and we hope that your experience here leads to the kind of love and connections you're seeking.\n\n
    Happy matching!\n
    Warm regards,\n
    Lovey
    `,
    purchaseSubscriptionSubject: 'Subscription purchased - Lovey',
    purchaseSubscriptionBody: `Dear {{Subscribers Name}}\n\n,
    We're thrilled to welcome you as a subscriber to Lovey! Thank you for choosing to join our community of users who enjoy the benefits of our premium features. Your subscription purchase was successful, and we're excited to share what this means for you.\n\n
    Subscription Details:\n
    Subscription Plan: {{Plan Name}}\n
    Subscription Period: Monthly\n
    Subscription Price: {{Price}}\n\n
    Key Features You Can Now Access:\n
    [3 or 6] Matches per month \n\n
    What to Expect Next:\n
    Uninterrupted Access: You now have full access to all the premium features of Lovey. Enjoy an enhanced experience without any limitations.\n
    Regular Updates: We are constantly working to improve Lovey and will regularly roll out updates and new features exclusively for our subscribers.\n
    Priority Support: As a subscriber, you'll receive priority support from our dedicated team. If you have any questions or encounter any issues, please don't hesitate to reach out to our support team at support@lovey.ai.\n
    Automatic Renewal: Your subscription will be automatically renewed according to the chosen plan (monthly or annually). You can manage or cancel your subscription at any time through your account settings.\n
    Billing Receipt: You will receive a billing receipt for your subscription purchase shortly. This will include all the details of your transaction for your records.\n\n
    We want to express our sincere appreciation for your support. Your subscription enables us to continue improving and expanding Lovey to provide you with the best possible experience.\n
    If you have any feedback, suggestions, or questions, please feel free to share them with us. We value your input and are here to help.\n
    Once again, thank you for choosing Lovey. We look forward to delivering an exceptional experience to you.\n\n
    Best regards,\n
    Lovey Team\n
    Dallas TX 
    `,
    phoneVerifyBody: `Use {{OTPCode}} to verify your phone number.\n\n
    Best regards,\n
    Lovey App LLC.  Dallas, TX`,
    sendOTPEmailSubject: "OTP - Lovey",
    sendOTPEmailBody: `Hello,\n\nUse {{OTPCode}} to verify your phone number.\n\n
    Best regards,\n
    Lovey App LLC.  Dallas, TX `,
    editUserNameSubject: 'Username updated - Lovey',
    editUserNameBody: `Dear {{Users Name}},\n\n
    This is to inform you that changes have been made to your profile information on our platform. Below are the details of the updates:
    Edit Profile - Username\n
    Previous Username: {{Old Username}}\n
    New Username: {{New Username}}\n\n
    If you did not make these changes, please contact our support team immediately at support@lovey.ai.\n
    Your security and privacy are important to us, and we take all necessary measures to protect your account information.\n\n
    Thank you for using our platform.\n
    Best regards,\n
    Lovey App LLC.  Dallas, TX 
    `,
    editCitySubject: 'City changed - Lovey',
    editCityBody: `Dear {{Users Name}},\n\n
    This is to inform you that changes have been made to your profile information on our platform. Below are the details of the updates:
    Edit Profile - City\n
    Previous City: {{Old City}}\n
    New City: {{New City}}\n\n
    If you did not make these changes, please contact our support team immediately at support@lovey.ai.\n
    Your security and privacy are important to us, and we take all necessary measures to protect your account information.\n\n
    Thank you for using our platform.\n
    Best regards,\n
    Lovey App LLC.  Dallas, TX 
    `,
    editAddressSubject: 'Address updated - Lovey',
    editAddressBody: `Dear {{Users Name}},\n\n
    This is to inform you that changes have been made to your profile information on our platform. Below are the details of the updates:
    Edit Profile - Address\n
    Previous Address: {{Old Address}}\n
    New Address: {{New Address}}\n\n
    If you did not make these changes, please contact our support team immediately at support@lovey.ai.\n
    Your security and privacy are important to us, and we take all necessary measures to protect your account information.\n\n
    Thank you for using our platform.\n
    Best regards,\n
    Lovey App LLC.  Dallas, TX 
    `,
    purchaseSubscriptionPushNoteTitle: 'Subscription purchased',
    purchaseSubscriptionPushNoteBody: 'Subscription purchased',
    chatPNTitle: 'You Received a Message',
    chatPNMsg: 'You received a message from {{partnerUserName}}',
    chatTxtMsg: 'You have received a message from {{partnerUserName}}',
    fixDateInRestauInitPNTitle: 'Its go time!',
    fixDateInRestauInitPNMsg: 'Check your schedule and confirm your date.',
    fixDateInRestauTxtMsg: 'Its go time! Check your schedule and confirm your date.',
    fixDateInRestauSuggestPNTitle: 'Its go time!',
    fixDateInRestauSuggestPNMsg: 'Check your schedule and confirm your date.',
    fixDateInRestauAcceptPNTitle: 'Its go time!',
    fixDateInRestauAcceptPNMsg: 'Your date and time is confirmed.',
    fixDateInRestauDeclinePNTitle: 'Another time?',
    fixDateInRestauDeclinePNMsg: 'Check your schedule and find another time for your date.',
    feedbackTxtMsg: 'Do you want to know what {{partnerUserName}} said about your date? Check Lovey.',
    feedbackPNTitle: 'Date Feedback',
    feedbackPNMsg: 'Do you want to know what {{partnerUserName}} said about your date? Check Lovey.',
    purchaseSubscriptionAfterBotCmplt: 'You have completed your profile sign up for one of our plans to receive matches!',
    recommendedMatchAcceptPNTitle: "Ready to Connect?",
    recommendedMatchAcceptPNMsg: "{{NAME}} would like to meet you.",
    recommendedMatchAcceptTxtMsg: "{{NAME}} would like to meet you.",
    loggedInNotCmpletedPrfPNTitle: "Finish your profile",
    loggedInNotCmpltdPrflPNMsg: "How serious are you about finding the right one? Please finish your profile.",
    forgotpassTxtMsg: `Hello {{Users Name}},\n\n
    It seems like you've forgotten your password. No worries! We're here to help you reset it and regain access to your account.\n
    Your One-Time Password (OTP) for password reset is: {{OTPCode}}\n
    Please use this OTP to reset your password.\n\n
    Thank you from the Lovey team.`,
    resetPasswordTxtMsg: `Hello {{Users Name}}\n\n,
    Great news! Your password has been successfully reset for your Lovey account.\n
    Your account security is important to us, and we're here to assist you every step of the way. If you have any questions or concerns, please don't hesitate to reach out to our support team.\n\n
    Thank you from the Lovey team. `,
    initiateDateTxtMsg: `Its go time! check your schedule and confirm your date.`,
    suggestDateTxtMsg: `Its go time! check your schedule and confirm your date.`,
    declineDateTxtMsg: `Check your schedule and find another time for your date. `,
    acceptDateTxtMsg: `Your date and time is confirmed`,
    chatTxtMsg: `you have received a message from {{userName}}`,
    chatPNTitle: `You Received a Message`,
    chatPNMsg: `You Received a message from {{userName}}`,
    twoHrPNTitle: `Friendly Reminder`,
    twoHrPNMsg: `Hey there! Don't forget to complete your personality assessment within 24 hours. Your preferences matter, and it will help us find your ideal match.`,
    fourHrPNTitle: `Time's Ticking`,
    fourHrPNMsg: `Just a friendly reminder – you have 20 hours left to complete your personality assessment. The clock is ticking, so let's get started!`,
    sixHrPNTitle: `Personalize Your Experience`,
    sixHrPNMsg: `Your dating experience is about to get more personalized. Complete your personality assessment within the next 18 hours to unlock its full potential!`,
    twelveHrPNTitle: `Time is Ticking`,
    twelveHrPNMsg: `Are you serious about finding love? Please complete your assessment in the next 12 hours if you want to be successful at it. Don't miss your chance.`,
    twentyFourHrPNTitle: `Last Chance to Save Your Preferences!`,
    twentyFourHrPNMsg: `Time's almost up! Complete your  assessment within the next hour to customize your matchmaking experience.`,
    fourHrTxtMsg: `Hi {{Users Name}}, it's Lovey Don't forget to complete your assessment today. Your love awaits!`,
    eightHrTxtMsg: `Hey {{Users Name}}, time's running out! You have 16 hours left to finish your assessment. This process is key in helping you find the perfect partner.`,
    twelveHrTxtMsg: `Hi {{Users Name}}, finding the perfect match is all about details. Complete your assessment within 12 hours to avoid losing your data. Take the first step towards it!`,
    sixteenHrTxtMsg: `Last reminder! You only have eight hours left to complete your assessment or you completely lose any data that you have saved. Make love a priority. It only takes a few minutes to curate the perfect partner.`,
    signUpProfCompltPNTitle: `Welcome to Lovey!`,
    signUpProfCompltPNMsg: `Welcome to Lovey! Your journey to finding the perfect match starts with your personality assessment. Complete it now to get the best matches tailored to you!`,
    beforeChatOpenPNTitle:'Chat with your Date!',
    beforeChatOpenPNMsg:'The chat with your Date is opening in {{minutes}}. Click here for some instructions for your date.',
}

const inAppMessages = {
    registerTitle: 'Registration Successful',
    registerMessage: 'We are thrilled to welcome you to Lovey, the place where you find people that love like you do. Thank you for choosing us as your platform for creating meaningful relationships.',
    purchaseSubscriptionAfterBotCmpltTitle: 'Profile successfully completed',
    purchaseSubscriptionAfterBotCmpltMsg: 'You have completed your profile sign up for one of our plans to receive matches!',
    purchaseSubscriptionTitle: 'Subscription purchased',
    purchaseSubscriptionMsg: 'You have successfully subscribed to the {{Plan Name}} plan.',
    upgradepurchaseSubscriptionTitle: 'Subscription Upgraded',
    upgradeSubscriptionMsg: 'You have successfully upgraded to {{Plan Name}} plan.',
    beforeChatMsg: `Have fun on your date! Remember if you two like each other, you will want to exchange information to see each other again. 
    First date tips and checklist:
    "- Remember to dress to impress. You only get one chance to make a first impression 
    - Always meet your match at the restaurant of your choice. Do not give any identifying information out prior to your first day. That includes last name.   
    - If you do wish to conduct a background check on your own, make sure that you get whatever information you need from your date
    - Remember to be yourself. You don't need to impress someone else you should be going to learn more about them so remember to be authentic and listen and ask lots of questions that matter 
    - Be on time for your first date ! 
    - Guys… Remember that if you like her and want to see her again, you should ask her out or let her know your intentions prior to leaving the first date"
    `
}

export { messages, inAppMessages }
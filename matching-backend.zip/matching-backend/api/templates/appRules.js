const rulesTemplate = {
    helpAndSupport: `
    <html>
    <head>
    <meta charset="UTF-8" name="viewport" content="width=device-width", initial-scale=1.0>
    <style>
        /* styles start */
        body {
            font-family: calibri;
            
            padding:20px;
            margin:0px;
        }

        h1 {
            font-size:24px;
            color:#FFFFFF;
        }
        h2 {
            font-size:20px;
            color:#FFFFFF;
            text-decoration:underline;
        }
        h3 {
            font-size:20px;
            color:#FFFFFF;
            text-decoration:underline;
        }

        p {
            color:#A0999E;
            padding-top:0px;
        }

        ul {
            list-style-type: disc;
        }
        ul li {
            padding-bottom:10px;
            color:#A0999E;
        }

        a {
            text-decoration: none;
            color: #0077cc;
        }
    </style>
    </head>    
    <body>
    <p>Welcome to the help and support page for our application! We understand that sometimes you may encounter difficulties or have questions while using our platform. We're here to assist you and ensure your experience is as smooth as possible. Please take a moment to read through the following information on how to seek help and get in touch with us.</p>
    <p><h3>Frequently Asked Questions (FAQ)</h3></p>
    <p> Before reaching out for support, we recommend checking our Frequently Asked Questions (FAQ) section. It contains a comprehensive list of common queries and their answers, which may address your concern right away. The FAQ section can be found in the application's settings or on our website at <a href="http://www.lovey.ai/support/faq">http://www.lovey.ai/support/faq</a>. </p>
    <p><h3>Contacting Support</h3>
    <p>If you need further assistance or your question is not addressed in the FAQ section, our support team is ready to help. You can reach out to us by sending an email to <a href="mailto:admin@lovey.ai">admin@lovey.ai</a>. Please provide as much detail as possible about your issue or question so that we can assist you effectively. Our support team strives to respond to all inquiries within 24 hours.</p><br>
    <p>When contacting support, please keep the following guidelines in mind:<p><br>
    <ul>
    <li>Be specific: Clearly explain your issue or question, providing relevant details such as error messages, steps to reproduce the problem, or any other relevant information.</li>
    <li>Include your account information: If you are experiencing an issue with your account, please include the email address or username associated with it to help us locate your account and provide more accurate assistance.</li>
    <li>Screenshots or attachments: If applicable, feel free to attach any screenshots or files that can help us better understand the problem.</li>
    </ul></p>
    <p><h3>System Status and Updates</h3></p>
    <p>For any service outages, scheduled maintenance, or important announcements, we will keep you informed through our system status page. You can access the system status page by visiting <a href="http://www.lovey.ai/status">http://www.lovey.ai/status</a> or by following us on Twitter at @LoveyAI_Support. We recommend checking these sources before contacting support in case the issue you are experiencing is already known.</p>
    <p><h3>Feedback and Suggestions</h3></p>
    <p>We value your feedback and suggestions as they help us improve our application. If you have any ideas, feature requests, or general feedback, please don't hesitate to reach out to us at feedback@lovey.ai. We appreciate your input and take it into consideration for future updates.<br>
        Thank you for choosing our application! We strive to provide the best support possible and ensure your experience is enjoyable.</p>
    </body>
    </html>`,
    privacyPolicy: ` <html>
    <head>
      <meta charset="UTF-8" name="viewport" content="width=device-width" , initial-scale=1.0>
      <style>
        /* styles start */
        body {
          font-family: calibri;
          padding: 20px;
          margin: 0px;
        }

        h1 {
          font-size: 24px;
          color: #FFFFFF;
        }

        h2 {
          font-size: 20px;
          color: #FFFFFF;
          text-decoration: underline;
        }

        p {
          color: #A0999E;
          padding-top: 0px;
        }

        ul {
          list-style-type: disc;
        }

        ul li {
          padding-bottom: 10px;
          color: #A0999E;
        }

        a {
          text-decoration: none;
          color: #0077cc;
        }
      </style>
    </head>
    <body>
      <p class="grey">Last modified: November 21, 2023</p>
      <h2>Introduction</h2>
      <p>Lovey App, LLC (“Lovey” or “we,” “us,” or “our”) respect your privacy and are committed to protecting it through our compliance with this policy. This policy describes:</p>
      <ul>
        <li>The types of information we may collect or that you may provide when you download, install, register with, access, or use the “Lovey” mobile application available on iOS and Android devices or our website, <a href="https://lovey.ai/">https://lovey.ai/ </a>(collectively, our “App”) . </li>
        <li>Our practices for collecting, using, maintaining, protecting, and disclosing that information.</li>
      </ul>
      <p>This policy applies only to information we collect in our App and in email, text, and other electronic communications sent through or in connection with our App. </p>
      <p>This policy DOES NOT apply to information that you provide to or is collected by any third party (see <i>Third-Party Information Collection</i> later in this policy).These other third parties may have their own privacy policies, which we encourage you to read before providing information on or through them. </p>
      <p>Please read this policy carefully to understand our policies and practices regarding your information and how we will treat it. If you do not agree with our policies and practices, do not download, register with, or use our App. By downloading, registering with, or using our App, you agree to this privacy policy. This policy may change from time to time (see Changes to Our Privacy Policy later in this policy). Your continued use of our App after we revise this policy means you accept those changes, so please check the policy periodically for updates.</p>
      <h2>Age Requirements</h2>
      <p>Our App is not intended for anyone under the age of 18, and we do not knowingly collect personal information persons under the age of 18. If you do not confirm that you are at least the age of 18 when you sign up on our App, we will not let you complete the sign up process. If we learn we have collected or received personal information from anyone under the age of 18 without verification of parental consent, we will delete that information. If you believe we might have any information from or about a child under 16, please contact us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai.</a>
      </p>
      <p>California residents under 16 years of age may have additional rights regarding the collection and sale of their personal information. Please see Your State Privacy Rights later in this policy for more information.</p>
      <h2>Information We Collect and How We Collect It</h2>
      <p>We collect information from and about users of our App:</p>
      <ul>
        <li>Directly from you when you provide it to us.</li>
        <li>Automatically when you use our App. </li>
      </ul>
      <h2>
        <i>Information You Provide to Us</i>
      </h2>
      <p>When you download, register with, or use our App, we may ask you provide information:</p>
      <ul>
        <li>By which you may be personally identified, such as name, postal address, email address, telephone number any other identifier by which you may be contacted online or offline (“personal information”).</li>
        <li>That is about you but individually does not identify you, such as age and gender. </li>
      </ul>
      <p>This information includes:</p>
      <ul>
        <li>Information that you provide by filling in forms in our App. This includes information provided at the time of registering to use our App or subscribing to our service. We may also ask you for information when you enter a contest or promotion sponsored by us, or when you report a problem with our App.</li>
        <li>Records and copies of your correspondence (including email addresses and phone numbers), if you contact us.</li>
        <li>Your responses to surveys that we might ask you to complete for research purposes.</li>
        <li>Details of transactions you carry out through our App and of the fulfillment of your orders. You may be required to provide financial information before placing an order through our App.</li>
        <li>Your search queries on our App.</li>
      </ul>
      <h2>
        <i>Automatic Information Collection and Tracking</i>
      </h2>
      <p>When you download, access, and use our App, it may use technology to automatically collect: </p>
      <ul>
        <li>
          <b>Usage Details.</b> When you access and use our App, we may automatically collect certain details of your access to and use of our App, including communication data and the resources that you access and use on or through our App.
        </li>
        <li>
          <b>Device Information.</b> We may collect information about your mobile device and internet connection, including the device's unique device identifier, operating system, and mobile network information.
        </li>
        <li>
          <b>Stored Information and Files.</b> Our App also may access metadata and other information associated with other files stored on your device. This may include, for example, photographs, and audio and video clips.
        </li>
        <li>
          <b>Location Information.</b> Our App does not collect real-time information about the location of your device.
        </li>
        <li>If you do not want us to collect this information you may opt out at any time by emailing us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai. </a> For more information, see Your <i>Choices About Our Collection, Use, and Disclosure of Your Information</i> later in this policy. Note, however, that opting out of our App’s collection of location information will disable its location-based features. </li>
      </ul>
      <p>We also may use these technologies to collect information about your activities over time and across third-party websites, apps, or other online services (behavioral tracking). If you do not want us to collect this information you may opt out at any time by emailing us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai. </a>
      </p>
      <h2>
        <i>Information Collection and Tracking Technologies</i>
      </h2>
      <p>The technologies we use for automatic information collection may include: </p>
      <ul>
        <li>
          <b>Cookies (or mobile cookies).</b> A cookie is a small file placed on your smartphone. It may be possible to refuse to accept mobile cookies by activating the appropriate setting on your smartphone. However, if you select this setting you may be unable to access certain parts of our App.
        </li>
      </ul>
      <h2>
        <i>Third-Party Information Collection</i>
      </h2>
      <p>When you use our App or its content, certain third parties may use automatic information collection technologies to collect information about you or your device. These third parties may include:</p>
      <ul>
        <li>Advertisers, ad networks, and ad servers.</li>
        <li>Analytics companies.</li>
        <li>Your mobile device manufacturer.</li>
        <li>Your mobile service provider.</li>
      </ul>
      <p>These third parties may use tracking technologies to collect information about you when you use this app. The information they collect may be associated with your personal information or they may collect information, including personal information, about your online activities over time and across different websites, apps, and other online services websites. They may use this information to provide you with interest-based (behavioral) advertising or other targeted content.</p>
      <p>We do not control these third parties’ tracking technologies or how they may be used. If you have any questions about an advertisement or other targeted content, you should contact the responsible provider directly. If you do not want third parties to collect this information you may opt out at any time by emailing us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai</a>.
      <h2>How We Use Your Information</h2>
      <p>We use information that we collect about you or that you provide to us, including any personal information, to:</p>
      <ul>
        <li>Provide you with our App and its contents, and any other information, products, or services that you request from us.</li>
        <li>Fulfill any other purpose for which you provide it.</li>
        <li>Give you notices about your account or subscription, including expiration and renewal notices.</li>
        <li>Carry out our obligations and enforce our rights arising from any contracts entered into between you and us, including for billing and collection.</li>
        <li>Notify you when App updates are available, and of changes to any products or services we offer or provide though it.</li>
      </ul>
      <p>The usage information we collect helps us to improve our App and to deliver a better and more personalized experience by enabling us to:</p>
      <ul>
        <li>Estimate our audience size and usage patterns.</li>
        <li>Store information about your preferences, allowing us to customize our App according to your individual interests.</li>
        <li>Speed up your searches.</li>
        <li>Recognize you when you use our App.</li>
      </ul>
      <p>We use location information we collect to find matches within a radius from you.</p>
      <p>We may also use your information to contact you about our own and third parties’ goods and services that may be of interest to you. If you do not want us to use your information in this way, you may opt out at any time by emailing us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai.</a>
      <p>We may use the information we collect to display advertisements to our advertisers’ target audiences. Even though we do not disclose your personal information for these purposes without your consent, if you click on or otherwise interact with an advertisement, the advertiser may assume that you meet its target criteria.</p>
      <h2>Disclosure of Your Information</h2>
      <p>We may disclose aggregated information about our users, and information that does not identify any individual or device, without restriction.</p>
      <p>In addition, we may disclose personal information that we collect or you provide: </p>
      <ul>
        <li>To our subsidiaries and affiliates.</li>
        <li>To contractors, service providers, and other third parties we use to support our business.</li>
        <li>To a buyer or other successor in the event of a merger, divestiture, restructuring, reorganization, dissolution, or other sale or transfer of some or all of Lovey’s assets, whether as a going concern or as part of bankruptcy, liquidation, or similar proceeding, in which personal information held by Lovey about our App users is among the assets transferred.</li>
        <li>To third parties to market their products or services to you if you have not opted out of these disclosures.</li>
        <li>To fulfill the purpose for which you provide it.</li>
        <li>For any other purpose disclosed by us when you provide the information.</li>
        <li>With your consent.</li>
        <li>To comply with any court order, law, or legal process, including to respond to any government or regulatory request.</li>
        <li>To enforce our rights arising from any contracts entered into between you and us, including our App "Terms of use" and for billing and collection.</li>
        <li>If we believe disclosure is necessary or appropriate to protect the rights, property, or safety of Lovey, our customers, or others.</li>
      </ul>
      <h2>Your Choices About Our Collection, Use, and Disclosure of Your Information</h2>
      <p>We strive to provide you with choices regarding the personal information you provide to us. This section describes mechanisms we provide for you to control certain uses and disclosures of over your information.</p>
      <ul>
        <li>
          <b>Tracking Technologies.</b> You can set your browser to refuse all or some browser cookies, or to alert you when cookies are being sent. You can choose whether or not to allow our App to collect information through other tracking technologies by emailing us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai. </a>. If you disable or refuse cookies or block the use of other tracking technologies, some parts of our App may then be inaccessible or not function properly.
        </li>
        <li>
          <b>Location Information.</b> You can choose whether or not to allow our App to collect and use real-time information about your device’s location technologies by emailing us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai.</a>. If you block the use of location information, some parts of our App may become inaccessible or not function properly.
        </li>
        <li>
          <b>Promotion by Lovey.</b> If you do not want us to use your email address or other contact information to promote our own or third parties’ products or services, you can opt-out by emailing us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai. </a>.
        </li>
        <li>
          <b>Targeted Advertising by Lovey.</b> If you do not want us to use information that we collect or that you provide to us to deliver advertisements according to our advertisers’ target-audience preferences, you can opt-out by emailing us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai.</a>
        </li>
        <li>
          <b>Disclosure of Your Information for Third-Party Advertising and Marketing.</b> If you do not want us to share your personal information with unaffiliated or non-agent third parties for advertising and marketing purposes, you can opt-out by emailing us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai</a>
        </li>
      </ul>
      <p>We do not control third parties’ collection or use of your information to serve interest-based advertising. However these third parties may provide you with ways to choose not to have your information collected or used in this way. You can opt out of receiving targeted ads from members of the Network Advertising Initiative (“NAI”) on the NAI’s website.</p>
      <p>Residents in certain states, such as California, may have additional personal information rights and choices. Please see Your State Privacy Rights later in this policy for more information. </p>
      <h2>Accessing and Correcting Your Personal Information</h2>
      <p>You can review and change your personal information by logging into our App and visiting your account profile page. </p>
      <p>You may also email us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai. </a> to request access to, correct, or delete any personal information that you have provided to us. We cannot delete your personal information except by also deleting your user account. We may not accommodate a request to change information if we believe the change would violate any law or legal requirement or cause the information to be incorrect. </p>
      <p>Residents in certain states, such as California, may have additional personal information rights and choices. Please see <i>Your State Privacy Rights</i> later in this policy for more information. </p>
      <h2>Your State Privacy Rights</h2>
      <p>State consumer privacy laws may provide their residents with additional rights regarding our use of their personal information. For instance, California's “Shine the Light” law (Civil Code Section § 1798.83) permits users of our App that are California residents to request certain information regarding our disclosure of personal information to third parties for their direct marketing purposes. To make such a request, please email us at <a href="mailto:Support@Lovey.ai">Support@Lovey.ai.</a>
      </p>
      <h2>Data Security</h2>
      <p>We have implemented measures designed to secure your personal information from accidental loss and from unauthorized access, use, alteration, and disclosure.</p>
      <p>The safety and security of your information also depends on you. Where we have given you (or where you have chosen) a password for access to certain parts of our App, you are responsible for keeping this password confidential. We ask you not to share your password with anyone.</p>
      <p>Unfortunately, the transmission of information via the internet and mobile platforms is not completely secure. Although we do our best to protect your personal information, we cannot guarantee the security of your personal information transmitted through our App. Any transmission of personal information is at your own risk. We are not responsible for circumvention of any privacy settings or security measures we provide.</p>
      <h2>Changes to Our Privacy Policy</h2>
      <p>We may update our privacy policy from time to time. If we make material changes to how we treat our users’ personal information, we will notify you by email. </p>
      <p>The date the privacy policy was last revised is identified at the top of the page. You are responsible for ensuring we have an up-to-date active and deliverable email address or phone number for you and for periodically visiting this privacy policy to check for any changes.</p>
      <h2>Contact Information</h2>
      <p>To ask questions or comment about this privacy policy and our privacy practices, email us at: <a href="mailto:Support@Lovey.ai">Support@Lovey.ai. </a>
      </p>
      <p>To register a complaint or concern, email us at: <a href="mailto:Support@Lovey.ai">Support@Lovey.ai.</a>
      </p>
    </body>
  </html>`,
    termsAndCondition: `<html>
    <head>
      <meta charset="UTF-8" name="viewport" content="width=device-width" , initial-scale=1.0>
      <style>
        /* styles start */
        body {
          font-family: calibri;
          padding: 20px;
          margin: 0px;
        }
  
        h1 {
          font-size: 24px;
          color: #FFFFFF;
        }
  
        h2 {
          font-size: 20px;
          color: #FFFFFF;
          text-decoration: underline;
        }
  
        p {
          color: #A0999E;
          padding-top: 0px;
        }
  
        ul {
          list-style-type: disc;
        }
  
        ul li {
          padding-bottom: 10px;
          color: #A0999E;
        }
  
        a {
          text-decoration: none;
          color: #0077cc;
        }
      </style>
    </head>
    <body>
      <p class="grey">Last modified: 12/7/2023</p>
      <h2>Acceptance of the Terms of Use</h2>
      <p>These terms of use are entered into by and between You and Lovey App LLC (“Lovey” or “we,” “us,” or “our”). The following terms and conditions, together with any documents they expressly incorporate by reference (collectively, “Terms of Use”), govern your access to and use of “Lovey” mobile application available on iOS and Android devices or our website,www.lovey.ai (collectively, our “App”). </p>
      <p>Please read the Terms of Use carefully before you start to use the App. <b>By using the App or by clicking to accept or agree to the Terms of Use when this option is made available to you, you accept and agree to be bound and abide by these Terms of Use and our Privacy Policy, found at [TBD], incorporated herein by reference.</b> If you do not want to agree to these Terms of Use or the Privacy Policy, you must not access or use the App. </p>
      <p>You must register for an account (“Account”) to use our App. You may only open an Account if you are 18 years of age or older and legally permitted to use the App where you reside. By using our App, you represent and warrant that you are of legal age to form a binding contract with Lovey and meet all of the foregoing eligibility requirements. If you do not meet all of these requirements, you must not access or use our App </p>
      <p>If you want to delete your Account we have a provision in the settings of the App. </p>
      <h2>Subscription and Auto-Renewal</h2>
      <p>Lovey app provides a subscription service featuring auto-renewal options, offering a selection between the <b>Basic or Plus package</b>. The subscription is billed on a <b>monthly basis</b>, and the renewal cost is determined by your choice of the <b>Basic package at $199</b> which includes upto <b>3 matches a month</b> or the <b>Plus package at $289</b> which includes <b>6 matches a month</b>. Each subscription has a <b>one-month duration</b>, continuing automatically until the user opts to cancel. If the user decides to cancel and has already been billed for the current month, the cancellation will take effect in the following month. <b>EACH SUBSCRIPTION CHARGE AUTOMATICALLY RENEWS EVERY MONTH UNLESS YOU CANCEL</b>.</p>
      <h2>Changes to the Terms of Use </h2>
      <p>We may revise and update these Terms of Use from time to time in our sole discretion. All changes are effective immediately when we post them. However, any changes to the dispute resolution provisions set forth in Governing Law and Jurisdiction will not apply to any disputes for which the parties have actual notice prior to the date the change is posted on our App. </p>
      <p>Your continued use of our App following the posting of revised Terms of Use means that you accept and agree to the changes. You are expected to check this page from time to time so you are aware of any changes, as they are binding on you.</p>
      <h2>Access and Account Security</h2>
      <p>We reserve the right to withdraw or amend our App, your Account, and any service or material we provide on our App, in our sole discretion without notice. We will not be liable if for any reason all or any part of the App is unavailable at any time or for any period. From time to time, we may restrict access to some parts or all of the App. </p>
      <p>You are responsible for making all arrangements necessary for you to have access to our App, including internet service, and ensuring that you are the only person accessing our App with your Account. </p>
      <p>You must log in to your Account to access our App. It is a condition of your use of the App that all the information you provide on is correct, current and complete. You consent to all actions we take with respect to your information consistent with our Privacy Policy. </p>
      <p>If you choose, or are provided with, a user name, password or any other piece of information as part of our security procedures, you must treat such information as confidential, and you must not disclose it to any other person or entity. You also acknowledge that your Account is personal to you and agree not to provide any other person with access to your Account or using our App while using your user name, password or other security information. You agree to notify us immediately of any unauthorized access to or use of your Account, user name, password or any other breach of security. You should use particular caution when accessing your Account so that others are not able to view or record your password or other personal information. </p>
      <p>We have the right to disable any Account, user name, password or other identifier, whether chosen by you or provided by us, at any time in our sole discretion for any or no reason, including if, in our opinion, you have violated any provision of these Terms of Use. </p>
      <h2>Intellectual Property Rights </h2>
      <p>Our App and its entire contents, features and functionality (including but not limited to all information, software, text, displays, images, video and audio, and the design, selection and arrangement thereof), are owned by Lovey, its licensors or other providers of such material and are protected by copyright, trademark, patent, trade secret and other intellectual property or proprietary rights laws. </p>
      <p>These Terms of Use permit you to use our App for your personal, non-commercial use only. You must not reproduce, distribute, modify, create derivative works of, publicly display, publicly perform, republish, download, store or transmit any of the material on our App, except as follows: </p>
      <ul>
        <li>Your mobile device or computer may temporarily store copies of such materials incidental to your accessing and viewing those materials. </li>
        <li>You may store files that are automatically cached by your internet browser for display enhancement purposes. </li>
        <li>may download a single copy of our App to your mobile device solely for your own personal, non-commercial use. </li>
      </ul>
      <p>You must not: </p>
      <ul>
        <li>Modify copies of any materials from our App.</li>
        <li>Use any illustrations, photographs, video or audio sequences or any graphics separately from the accompanying text.</li>
        <li>Delete or alter any copyright, trademark or other proprietary rights notices from copies of materials from this site.</li>
      </ul>
      <p>You must not access or use for any commercial purposes any part of our App or any services or materials available through our App.</p>
      <p>If you print, copy, modify, download or otherwise use or provide any other person with access to any part of our App in breach of the Terms of Use, your right to use the App will cease immediately and you must, at our option, return or destroy any copies of the materials you have made. No right, title or interest in or to our App or any content on our App is transferred to you, and all rights not expressly granted are reserved by Lovey. Any use of the App not expressly permitted by these Terms of Use is a breach of these Terms of Use and may violate copyright, trademark and other laws. </p>
      <h2>Trademarks</h2>
      <p>The Lovey name and logo and all related names, logos, product and service names, designs and slogans are trademarks of Lovey or its affiliates or licensors. You must not use such marks without the prior written permission of Lovey. All other names, logos, product and service names, designs and slogans on the App are the trademarks of their respective owners. </p>
      <h2>Prohibited Uses</h2>
      <p>You may use our App only for lawful purposes and in accordance with these Terms of Use. You agree not to use the App: </p>
      <ul>
        <li>In any way that violates any applicable federal, state, local or international law or regulation (including, without limitation, any laws regarding the export of data or software to and from the US or other countries).</li>
        <li>For the purpose of exploiting, harming or attempting to exploit or harm minors in any way by exposing them to inappropriate content, asking for personally identifiable information or otherwise.</li>
        <li>To send, knowingly receive, upload, download, use or re-use any material which does not comply with the Content Standards set out in these Terms of Use.</li>
        <li>To transmit, or procure the sending of, any advertising or promotional material, including any "junk mail," "chain letter," "spam," or any other similar solicitation.</li>
        <li>To impersonate or attempt to impersonate Lovey, a Lovey employee, another user or any other person or entity (including, without limitation, by using e-mail addresses associated with any of the foregoing). </li>
        <li>To engage in any other conduct that restricts or inhibits anyone's use or enjoyment of the Website, or which, as determined by us, may harm Lovey or users of the Website, or expose them to liability. </li>
      </ul>
      <p>Additionally, you agree not to:</p>
      <ul>
        <li>Use the App in any manner that could disable, overburden, damage, or impair the App or interfere with any other party's use of the App, including their ability to engage in real time activities through the App.</li>
        <li>Use any robot, spider or other automatic device, process or means to access the App for any purpose, including monitoring or copying any of the material on the App.</li>
        <li>Use any manual process to monitor or copy any of the material on the App, or for any other purpose not expressly authorized in these Terms of Use, without our prior written consent.</li>
        <li>Use any device, software or routine that interferes with the proper working of the App.</li>
        <li>Introduce any viruses, trojan horses, worms, logic bombs or other material which is malicious or technologically harmful.</li>
        <li>Attempt to gain unauthorized access to, interfere with, damage or disrupt any parts of the App, the server on which the App is stored, or any server, computer or database connected to the App.</li>
        <li>Otherwise attempt to interfere with the proper working of the App.</li>
      </ul>
      <h2>User Contributions</h2>
      <p>Our App allows users to share content (collectively, <b> "User Contributions" </b>) with other users on or through our App. All User Contributions must comply with the Content Standards set out in these Terms of Use. </p>
      <p>Any User Contribution you share on our App will be considered non-confidential and non-proprietary. By providing any User Contribution on the Website, you grant us and our affiliates and service providers, and each of their and our respective licensees, successors and assigns the right to use, reproduce, modify, perform, display, distribute and otherwise disclose to third parties any such material for any purpose.</p>
      <p>You represent and warrant that:</p>
      <ul>
        <li>You own or control all rights in and to the User Contributions and have the right to grant the license granted above to us and our affiliates and service providers, and each of their and our respective licensees, successors and assigns.</li>
        <li>All of your User Contributions do and will comply with these Terms of Use.</li>
      </ul>
      <p>You understand and acknowledge that you are responsible for any User Contributions you submit or contribute, and you, not Lovey, have full responsibility for such content, including its legality, reliability, accuracy and appropriateness.</p>
      <p>We are not responsible, or liable to any third party, for the content or accuracy of any User Contributions posted by you or any other user of our App.</p>
      <h2>Monitoring and Enforcement; Termination</h2>
      <p>We have the right to:</p>
      <ul>
        <li>Remove or refuse to post any User Contributions for any or no reason in our sole discretion.</li>
        <li>Take any action with respect to any User Contribution that we deem necessary or appropriate in our sole discretion, including if we believe that such User Contribution violates the Terms of Use, including the Content Standards, infringes any intellectual property right or other right of any person or entity, threatens the personal safety of users of our App or the public or could create liability for Lovey. </li>
        <li>Disclose your identity or other information about you to any third party who claims that material posted by you violates their rights, including their intellectual property rights or their right to privacy. </li>
        <li>Take appropriate legal action, including without limitation, referral to law enforcement, for any illegal or unauthorized use of our App. </li>
        <li>Terminate or suspend your access to all or part of our App for any or no reason, including without limitation, any violation of these Terms of Use.</li>
      </ul>
      <p>Without limiting the foregoing, we have the right to fully cooperate with any law enforcement authorities or court order requesting or directing us to disclose the identity or other information of anyone posting any materials on or through our App. YOU WAIVE AND HOLD HARMLESS LOVEY AND ITS AFFILIATES, LICENSEES AND SERVICE PROVIDERS FROM ANY CLAIMS RESULTING FROM ANY ACTION TAKEN BY ANY OF THE FOREGOING PARTIES DURING OR AS A RESULT OF ITS INVESTIGATIONS AND FROM ANY ACTIONS TAKEN AS A CONSEQUENCE OF INVESTIGATIONS BY EITHER SUCH PARTIES OR LAW ENFORCEMENT AUTHORITIES.</p>
      <p>However, we do not undertake to review material before it is posted on our App, and cannot ensure prompt removal of objectionable material after it has been posted. Accordingly, we assume no liability for any action or inaction regarding transmissions, communications or content provided by any user or third party. We have no liability or responsibility to anyone for performance or nonperformance of the activities described in this section.</p>
      <h2>Content Standards</h2>
      <p>These content standards apply to any and all User Contributions. User Contributions must in their entirety comply with all applicable federal, state, local and international laws and regulations. Without limiting the foregoing, User Contributions must not:</p>
      <ul>
        <li>Contain any material which is defamatory, obscene, indecent, abusive, offensive, harassing, violent, hateful, inflammatory or otherwise objectionable.</li>
        <li>Promote sexually explicit or pornographic material, violence, or discrimination based on race, sex, religion, nationality, disability, sexual orientation or age.</li>
        <li>Infringe any patent, trademark, trade secret, copyright or other intellectual property or other rights of any other person.</li>
        <li>Violate the legal rights (including the rights of publicity and privacy) of others or contain any material that could give rise to any civil or criminal liability under applicable laws or regulations or that otherwise may be in conflict with these Terms of Use or our Privacy Policy.</li>
        <li>Be likely to deceive any person.</li>
        <li>Promote any illegal activity, or advocate, promote or assist any unlawful act.</li>
        <li>Cause annoyance, inconvenience or needless anxiety or be likely to upset, embarrass, alarm or annoy any other person.</li>
        <li>Impersonate any person, or misrepresent your identity or affiliation with any person or organization.</li>
        <li>Involve commercial activities or sales, such as contests, sweepstakes and other sales promotions, barter or advertising.</li>
        <li>Give the impression that they emanate from or are endorsed by us or any other person or entity, if this is not the case.</li>
      </ul>
      <h2>Copyright Infringement</h2>
      <p>If you believe that any User Contributions violate your copyright, please send us a notice alleging infringement (“DMCA Takedown Notice”) to admin@lovey.ai. It is the policy of Lovey to terminate the user accounts of repeat infringers. Any DMCA Takedown Notice must include:</p>
      <ul>
        <li>Your physical or electronic signature.</li>
        <li>Identification of the copyrighted work you believe to have been infringed or, if the claim involves multiple works on the App, a representative list of such works.</li>
        <li>Identification of the material you believe to be infringing in a sufficiently precise manner to allow us to locate that material.</li>
        <li>Adequate information by which we can contact you (including your name, postal address, telephone number, and, if available, email address).</li>
        <li>A statement that you have a good faith belief that use of the copyrighted material is not authorized by the copyright owner, its agent, or the law.</li>
        <li>A statement that the information in the written notice is accurate.</li>
        <li>A statement, under penalty of perjury, that you are authorized to act on behalf of the copyright owner.</li>
      </ul>
      <h2>Reliance on Information Posted</h2>
      <p>The information presented on or through our App is made available solely for general information purposes. We do not warrant the accuracy, completeness or usefulness of this information. Any reliance you place on such information is strictly at your own risk. We disclaim all liability and responsibility arising from any reliance placed on such materials by you or any other visitor to the App, or by anyone who may be informed of any of its contents.</p>
      <p>Our App may include content provided by third parties, including materials provided by other users, third-party licensors, syndicators, aggregators and/or reporting services. All statements and/or opinions expressed in these materials, and all articles and responses to questions and other content, other than the content provided by Lovey, are solely the opinions and the responsibility of the person or entity providing those materials. These materials do not necessarily reflect the opinion of Lovey. We are not responsible, or liable to you or any third party, for the content or accuracy of any materials provided by any third parties.</p>
      <h2>Privacy Policy</h2>
      <p>All information we collect on our App is subject to our Privacy Policy. By using the App, you consent to all actions taken by us with respect to your information in compliance with the Privacy Policy.</p>
      <h2>Online Purchases and Other Terms and Conditions</h2>
      <p>All purchases through our site or other transactions for the sale of goods, services, or information formed through the App, or as a result of visits made by you are governed by our [TBD], which are hereby incorporated into these Terms of Use.</p>
      <p>Additional terms and conditions may also apply to specific portions, services or features of the App. All such additional terms and conditions are hereby incorporated by this reference into these Terms of Use.</p>
      <h2>Geographic Restrictions</h2>
      <p>We provide this App for use only by persons located in the United States. We make no claims that our App or any of its content is accessible or appropriate outside of the United States. Access to the App may not be legal by certain persons or in certain countries. If you access the App from outside the United States, you do so on your own initiative and are responsible for compliance with local laws.</p>
      <p>Our app will determine your location using location-based technology, such as GPS, Bluetooth or other software in your mobile device. If you disabled that technology, then you may not be able to access all or some of our App.</p>
      <h2>Notifications</h2>
      <p>From time to time, we’ll send you notifications about changes to our App, promotions or other announcements. Notifications may come as push notifications or texts to your mobile devices, emails or other messages. You’ll be asked to accept or deny push notifications after you download the App. If you want to change your push notifications settings for our App, you may change your settings at any time in your mobile device’s notifications settings. For opting out of emails and other messages, please follow the opt-out procedures in those notifications or email us at [TBD].</p>
      <h2>Disclaimer of Warranties</h2>
      <p>YOUR USE OF OUR APP, ITS CONTENT AND ANY SERVICES OR ITEMS OBTAINED THROUGH OUR APP IS AT YOUR OWN RISK. THE APP, ITS CONTENT AND ANY SERVICES OR ITEMS OBTAINED THROUGH THE APP ARE PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS, WITHOUT ANY WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED. NEITHER LOVEY NOR ANY PERSON ASSOCIATED WITH LOVEY MAKES ANY WARRANTY OR REPRESENTATION WITH RESPECT TO THE COMPLETENESS, SECURITY, RELIABILITY, QUALITY, ACCURACY OR AVAILABILITY OF THE APP. WITHOUT LIMITING THE FOREGOING, NEITHER LOVEY NOR ANYONE ASSOCIATED WITH LOVEY REPRESENTS OR WARRANTS THAT THE APP, ITS CONTENT OR ANY SERVICES OR ITEMS OBTAINED THROUGH THE APP WILL BE ACCURATE, RELIABLE, ERROR-FREE OR UNINTERRUPTED, THAT DEFECTS WILL BE CORRECTED, THAT OUR SITE OR THE SERVER THAT MAKES IT AVAILABLE ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS OR THAT THE APP OR ANY SERVICES OR ITEMS OBTAINED THROUGH THE APP WILL OTHERWISE MEET YOUR NEEDS OR EXPECTATIONS.</p>
      <p>LOVEY HEREBY DISCLAIMS ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, STATUTORY OR OTHERWISE, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF MERCHANTABILITY, NON-INFRINGEMENT AND FITNESS FOR PARTICULAR PURPOSE.</p>
      <p>THE FOREGOING DOES NOT AFFECT ANY WARRANTIES WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.</p>
      <h2>Limitation on Liability</h2>
      <p>TO THE FULLEST EXTENT PROVIDED BY LAW, IN NO EVENT WILL THE COLLECTIVE LIABILITY OF LOVEY AND ITS SUBSIDIARIES AND AFFILIATES, AND THEIR LICENSORS, SERVICE PROVIDERS, EMPLOYEES, AGENTS, OFFICERS, AND DIRECTORS, TO ANY PARTY (REGARDLESS OF THE FORM OF ACTION, WHETHER IN CONTRACT, TORT, OR OTHERWISE) EXCEED $100.</p>
      <p>The limitation of liability set out above does not apply to liability resulting from our gross negligence or willful misconduct.</p>
      <p>THE FOREGOING DOES NOT AFFECT ANY LIABILITY WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.</p>
      <h2>Indemnification</h2>
      <p>You agree to defend, indemnify and hold harmless Lovey, its affiliates, licensors and service providers, and its and their respective officers, directors, employees, contractors, agents, licensors, suppliers, successors and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses or fees (including reasonable attorneys' fees) arising out of or relating to your violation of these Terms of Use or your use of the App, including, but not limited to, your User Contributions, any use of the App’s content, services and products other than as expressly authorized in these Terms of Use, or your use of any information obtained from the App. </p>
      <h2>Governing Law and Jurisdiction</h2>
      <p>All matters relating to the App and these Terms of Use, and any dispute or claim arising therefrom or related thereto (in each case, including non-contractual disputes or claims), shall be governed by and construed in accordance with the internal laws of the State of Texas without giving effect to any choice or conflict of law provision or rule (whether of the State of Texas or any other jurisdiction).</p>
      <p>Subject to the Arbitration provision in these Terms of Use, any legal suit, action or proceeding arising out of, or related to, these Terms of Use or the App shall be instituted exclusively in the federal courts of the United States or the courts of the State of Texas, in each case the serve the City of Dallas, although we retain the right to bring any suit, action or proceeding against you for breach of these Terms of Use in your country or other jurisdiction of residence. You waive any and all objections to the exercise of jurisdiction over you by such courts and to venue in such courts.</p>
      <h2>Arbitration</h2>
      <p>At Lovey's sole discretion, we may require you to submit any disputes arising from these Terms of Use or use of the App, including disputes arising from or concerning their interpretation, violation, invalidity, non-performance, or termination, to final and binding arbitration under the Rules of Arbitration of the American Arbitration Association applying Texas law.</p>
      <h2>Limitation on Time to File Claims</h2>
      <p>ANY CAUSE OF ACTION OR CLAIM YOU MAY HAVE ARISING OUT OF OR RELATING TO THESE TERMS OF USE OR THE APP MUST BE COMMENCED WITHIN ONE (1) YEAR AFTER THE CAUSE OF ACTION ACCRUES; OTHERWISE, SUCH CAUSE OF ACTION OR CLAIM IS PERMANENTLY BARRED.</p>
      <h2>Waiver and Severability</h2>
      <p>No waiver of by Lovey of any term or condition set forth in these Terms of Use shall be deemed a further or continuing waiver of such term or condition or a waiver of any other term or condition, and any failure of Lovey to assert a right or provision under these Terms of Use shall not constitute a waiver of such right or provision.</p>
      <p>If any provision of these Terms of Use is held by a court or other tribunal of competent jurisdiction to be invalid, illegal or unenforceable for any reason, such provision shall be eliminated or limited to the minimum extent such that the remaining provisions of the Terms of Use will continue in full force and effect.</p>
      <h2>Entire Agreement</h2>
      <p>The Terms of Use, and our Privacy Policy constitute the sole and entire agreement between you and Lovey App LLC with respect to our App and supersede all prior and contemporaneous understandings, agreements, representations and warranties, both written and oral, with respect to our App.</p>
      <h2>Your Comments and Concerns</h2>
      <p>This website is operated by Lovey App LLC, 5950 Berkshire Lane, Suite 200, Dallas, Texas 75225.</p>
      <p>All other feedback, complaints, comments, requests for technical support and other communications relating to our App should be directed to: admin@lovey.ai</p>
    </body>
  </html>`,
    aboutUs: `<html>
    <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width", initial-scale=1.0>
        <style>
            /* styles start */
            body {
                font-family: calibri;
                
                padding:20px;
                margin:0px;
            }

            h1 {
                font-size:24px;
                color:#FFFFFF;
            }
            h2 {
                font-size:20px;
                color:#FFFFFF;
                text-decoration:underline;
            }
            h3 {
                font-size:20px;
                color:#FFFFFF;
                text-decoration:underline;
            }

            p {
                color:#A0999E;
                padding-top:0px;
            }

            ul {
                list-style-type: disc;
            }
            ul li {
                padding-bottom:10px;
                color:#A0999E;
            }

            a {
                text-decoration: none;
                color: #0077cc;
            }
        </style>
    </head>
    <body>
    <h1>About Lovey</h1>
    <p>There’s more to finding love than switching apps. We have to change our mind set about what we're looking for.  If you think about it, dating apps work in reverse. The whole system is flawed. Everything starts off with a picture and the real person almost always eludes you. People have probably swiped left to multiple potential soulmates.</p>
    <p>
    We absolutely have to be attracted to our partner, but compatibility comes first. How attractive a person is or how much chemistry we have with them matters not, if our basic framework for relationships in partnership isn’t a match. 
    </p>
    <p>For people who are looking for true love… you’ll only find it if you change your approach. Love really is more of an inside out process than outside in.
    </p>
    <p>The reason so many people are unsuccessful finding love on dating apps is because they're searching backwards (superficial before true compatability) and searching blindly. 
    When we go from relationship to relationship without examining who we are today and knowing specifically what we want and need in a relationship at this point in our life, we end up searching for the wrong thing.</p> 
    <p>What we need and who we are changes after each relationship and from our life experiences.  If we don't examine and understand those changes, we keep searching for the same dysfunctional/toxic partner we may have in the past. Hence, broken pickers. 
    </p>
    <p>What we need in our most intimate relationship is more than just physical, more than just superficial.<p>
    <h3>Why Lovey?</h3>
    <p>
    The average dating app appeals to a good portion of the population. We could use the 80/20 rule- 80% of people may be content with a certain level of relationship, connection, achievement, satisfaction, or effort, while the remaining 20% may strive for more in a partnership. These people desire more and are willing to work harder and smarter to get exactly what they want.
    Lovey is for that 20%. 
    </p>
    <p>Lovey is for people who don't like the dating app process, don't have time to waste wading through the riffraff and want a higher level connection, ultimately leading to a committed relationship.
    Our founder, Jennifer Styers, created this app because she knows what works in order to find real love. As a successful Matchmaker, she knows that a large majority of people really do want this kind of connection but may be unable to afford a traditional Matchmaker, to find it for them. 
    Love should be not be expensive. 
    </p>
    <p>The 'dating world' has just needed a better system, science and process to help people find better quality matches. Nobody has time or emotions to waste. 
    </p>
    <p>In an age of online deception, filtered pictures and so much well-documented online fraud/theft, there is a lot at stake for daters today.  What you see is not always what you get. Not just some of the time with online dating, but unfortunately, most of the time. Many people cycle in and out of the same dating apps for years. 
    </p>
    <p>Those apps make a fortune on people who can't afford a higher level service, but want love. 
    If we want something different, we have to do things differently. Simple, Lovey.</p>
    </body>
    </html> `,
    securityPolicy: `<html>
    <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width", initial-scale=1.0>
        <style>
            /* styles start */
            body {
                font-family: calibri;
                
                padding:20px;
                margin:0px;
            }
    
            h1 {
                font-size:24px;
                color:#FFFFFF;
            }
            h2 {
                font-size:20px;
                color:#FFFFFF;
                text-decoration:underline;
            }
    
            p {
                color:#A0999E;
                padding-top:0px;
            }
    
            ul {
                list-style-type: disc;
            }
            ul li {
                padding-bottom:10px;
                color:#A0999E;
            }
    
            a {
                text-decoration: none;
                color: #0077cc;
            }
        </style>
    </head>
    <body>
    <p>As our company is hosted on Azure, it is crucial for all users to acquaint themselves with Azure's robust security and backup and recovery policies. These policies directly apply to our infrastructure, ensuring that our data is safeguarded against potential threats, and establishing a resilient framework for business continuity. Navigate through the Azure Security Center to gain insights into threat detection, vulnerability management, and the enforcement of security policies tailored to our hosted environment. Additionally, explore Azure's backup and recovery solutions to comprehend the scalable and efficient mechanisms available for protecting our critical information. By adhering to these policies, our organization strengthens its security posture and enhances data resilience, contributing to a reliable and secure computing environment hosted on Azure.</p>
    <p>Link: <a href="https://learn.microsoft.com/en-us/azure/security/">https://learn.microsoft.com/en-us/azure/security/</a></p>
</body>           
</html>
`
};

export {
    rulesTemplate
}
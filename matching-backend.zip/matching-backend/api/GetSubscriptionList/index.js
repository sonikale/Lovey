import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import * as stripe from '../utils/stripe/stripe.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get subscription list API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.getSubscriptionList, req.body);
            if (validSchema.isValidRequest) {
                const subscriptionList = await stripe.getSubscriptionList(req.body.planId);
                context.log('Fetched subscription list sucessfully. Details req.body: ', req.body);
                result = successResponse("Fetched subscription list sucessfully.", subscriptionList, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get subscription list API Error: " + error);
        result = errorResponse('Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import { getUserListForAdmin } from '../utils/common.util.js';
import { messages } from '../core/constants.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get User List API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.getUserListForAdmin, req.body);
            if (validSchema.isValidRequest) {
                const usersDetails = await getUserListForAdmin(req.body);
                context.log(messages.USER_LIST_ADMIN_SUCCESS);
                result = successResponse(messages.USER_LIST_ADMIN_SUCCESS, usersDetails, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get User List API Error: " + error);
        result = errorResponse(messages.USER_LIST_ADMIN_ERROR, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
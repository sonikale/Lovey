import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { getRestaurantList } from '../utils/common.util.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("api/GetRestaurantList API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const restaurantList = await getRestaurantList();
            context.log('Restaurant list fetched successfully for user:', validateTokenResult.userDetails.dataValues.id);
            result = successResponse("Restaurant list fetched successfully", restaurantList, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("api/GetRestaurantList API Error: " + error);
        result = errorResponse('Something went wrong while getting restaurant list. Please contact admin.', StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
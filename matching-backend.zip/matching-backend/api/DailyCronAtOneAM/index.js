import sequelize from "../db/db.connect.js";
import { QueryTypes } from 'sequelize';
import { sendPushNotification } from '../utils/fcm.js'
import { messages } from '../templates/SMSEmailTemplates.js';
import * as stripe from '../utils/stripe/stripe.js';
import { runAlgorithm } from '../utils/ruleEngine.js'
import { verifyPurchaseWithApple } from '../utils/getInPurchaseReceipt.js';


export async function DailyCronAtOneAM(context, myTimer) {
    var timeStamp = new Date().toISOString();
    if (myTimer.isPastDue) {
        context.log('DailyCronAtOneAM is late. Time:', timeStamp);
    }
    try {
        context.log('Daily cron at 1 AM started! Time: ', timeStamp);
        // remove chat history record after 7 days - except chtbot record
        context.log("Cron 1: Delete 7 days older Chat history Started ");
        const res = await sequelize.query(`DELETE FROM "chatHistory" WHERE DATE_PART('day', now() - "createdAt") > 7 and "conversationId" IS NULL;`, { type: QueryTypes.DELETE });

        context.log("Cron 1: Details:", res);
        context.log("Cron 1: Delete 7 days older Chat history ran successfully");
        //---------------------------cron to send Push notification when user is 24 hrs logged in but havn't completed profile
        // send push notification to users who 24Hrs- logged in and not completed profile
        context.log("Cron 3: send push notification to users who 24Hrs- logged in and not completed profile Started ");
        const inCompletedProfile = await sequelize.query(` SELECT id, "firstName", "lastName", lastlogin, "fcmDeviceToken", "deviceType", "userStatus", "profileCompleted"
            FROM users where "profileCompleted" = false and "userStatus" = 'active';`, { type: QueryTypes.SELECT });
        context.log("inCompletedProfile :", JSON.stringify(inCompletedProfile));


        await Promise.all(inCompletedProfile.map(async user => {
            context.log("user :", user);
            // To DO: check 24 hrs here
            const currentDate = new Date();
            const lastlogin = new Date(user.lastlogin);

            // Calculate the time difference in milliseconds
            const timeDifferenceMs = lastlogin - currentDate;

            // Convert the time difference to hours and minutes
            const hoursDifference = Math.floor(timeDifferenceMs / (1000 * 60 * 60));

            if (hoursDifference == 24) {
                let userDetails = { screen: 'aphrodite', userId: user.id };

                const pushNotificationBody = {
                    fcmDeviceToken: user.fcmDeviceToken,
                    userDetails,
                    title: messages.loggedInNotCmpletedPrfPNTitle,
                    body: messages.loggedInNotCmpltdPrflPNMsg
                };
                await sendPushNotification(context, pushNotificationBody);
            }
        }));

        context.log("Cron 3: send push notification to users who 24Hrs- logged in and not completed profile ran successfully");

        //------------delete in app notification after 1 month -----------------
        context.log("Cron 4: ------------delete in app notification after 1 month ----------------- started");
        await sequelize.query(`DELETE FROM notifications WHERE DATE_PART('day', now() - "createdAt") > 30`, { type: QueryTypes.DELETE });
        context.log("Cron 4: ------------delete in app notification after 1 month ----------------- ran successfully");
        //===========================================for new rule engine algo logic======================
        const getAllActiveUser = await stripe.getAllActiveSubscription(context);
        const customerIds = Array.from(new Set(getAllActiveUser.data.map(subscription => subscription.customer))).join("','");
        const getAllUserActive = await sequelize.query(`select "userId","customerId" from "stripeCustomer" where "customerId" in ('${customerIds}')`, { type: QueryTypes.SELECT })
        console.log("customerIds", getAllUserActive)
        Promise.all(getAllUserActive.map(async item => {
            let checkDataExist = await sequelize.query(`select * from "generatedMatches" where "userId"='${item.userId}'`, { type: QueryTypes.SELECT })
            if (checkDataExist.length == 0) {
                runAlgorithm(context, item.userId);
            }
        }))

        //=========================for update subscription status================================
        const getAllUserActiveIOS = await sequelize.query(`select "userId","customerId","subscriptionEndDate" from "stripeCustomer" where "customerId"='CUST_IOS')`, { type: QueryTypes.SELECT })
        console.log("getAllUserActiveIOS", getAllUserActiveIOS)

        Promise.all(getAllUserActiveIOS.map(async item => {
            let iosdata = await sequelize.query(`SELECT "userId","receipt" FROM "appleReceipt" where "userId" = '${item.userId}';`, { type: QueryTypes.SELECT });
            console.log('isodata', iosdata)
            if (iosdata && iosdata.length > 0) {
                let getReceiptData = await verifyPurchaseWithApple(iosdata[0].receipt, item.userId, 'ios');
                let getReceiptExpIos = getReceiptData.receiptPurchase.latest_receipt_info[0].expires_date_ms;
                const updateCount = await sequelize.query(`UPDATE "stripeCustomer" SET "subscriptionEndDate" = '${getReceiptExpIos}', "updatedAt"=current_timestamp  WHERE "userId" = '${item.userId}'`, { type: QueryTypes.UPDATE });

            }
            if (item.subscriptionEndDate < Date.now()) {
                const deleteData = await sequelize.query(`DELETE FROM "stripeCustomer" WHERE "userId"='${item.userId}'`, { type: QueryTypes.DELETE })
            }
        }))
        //get all user who status is subscription active stripe table and
        //use start date and end date from subscription if generated match table doesnot have reacord for this user 
        //with date range start date and end date then run algo 
        context.log('Daily cron at 1 AM timer trigger function ran successfully!', timeStamp);
    }
    catch (err) {
        context.log('Error in DailyCronAtOneAM. Details: ', err);
    }
};
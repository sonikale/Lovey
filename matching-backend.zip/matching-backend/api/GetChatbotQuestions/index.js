import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import * as chatbotData from '../utils/chatbot.util.js';

export default async function (context, req) {
    let result = "",
        finalQuestionDataArr = [];

    try {
        context.log("Get chatbot question API START");
        // ------------commented authentication as request will be from chatbot----------------
        // const validateTokenResult = await validateToken(context, req);

        // if (!validateTokenResult.error) {
        const questionData = await chatbotData.getQuestions();
        const answerData = await chatbotData.getAnswersByUser(req.body.userId);

        await Promise.all(questionData.map(async (ques) => {
            const answerForQues = answerData.find(answer => answer.questionId == ques.id);
            let tempQuestionObj = await chatbotData.formatQuestion(ques, answerForQues);
            if (ques.haschild) {
                const subQuestionData = await chatbotData.getSubQuestions(ques.id);
                await Promise.all(subQuestionData.map(async (subQues) => {
                    const answerForSubQues = answerData.find(answer => answer.questionId == subQues.id);
                    let tempSubQuestionObj = await chatbotData.formatQuestion(subQues, answerForSubQues);

                    if (tempQuestionObj.subquestions.hasOwnProperty(subQues.parentOptionId)) {
                        tempQuestionObj.subquestions[subQues.parentOptionId].push(tempSubQuestionObj);
                    } else {
                        tempQuestionObj.subquestions = {
                            ...tempQuestionObj.subquestions,
                            [subQues.parentOptionId]: [tempSubQuestionObj],
                        }
                    }
                }));
            }
            finalQuestionDataArr.push(tempQuestionObj);
        }));

        const sortedQuestionsObj = finalQuestionDataArr.sort((q1, q2) => q1.sequence - q2.sequence);
        context.log('Chatbot questions fetched successfully:');
        result = successResponse("Questionnaire fetched successfully.", sortedQuestionsObj, StatusCodes.OK);
        // } else {
        //     result = validateTokenResult;
        // }
    } catch (error) {
        context.log("Get chatbot question API Error. Details:", error);
        result = errorResponse('Something went wrong while getting chatbot questions. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
};

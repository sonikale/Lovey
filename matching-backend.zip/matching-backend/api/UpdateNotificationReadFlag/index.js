import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { updateNotificationReadFlag } from '../utils/notifications.js';
import * as schema from '../utils/schema.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("UpdateNotificationReadFlag API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.updateNotificationReadFlag, req.body);
            if (validSchema.isValidRequest) {
                const notifications = await updateNotificationReadFlag(req.body.notificationId);
                context.log('Notification read flag updated for user:', validateTokenResult.userDetails.dataValues.id, ' NotificationId: ', req.body.notificationId);
                result = successResponse("Notification read successfully", notifications, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("UpdateNotificationReadFlag API Error: " + error);
        result = errorResponse('Something went wrong while updating read flag for notification. Please contact admin.', StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
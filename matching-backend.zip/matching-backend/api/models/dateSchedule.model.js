import { DataTypes, INTEGER, UUIDV4 } from 'sequelize';
import sequelize from "../db/db.connect.js";

const dateSchedule = sequelize.define("dateSchedule", {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true,
        defaultValue: UUIDV4
    },

    initiatorUserId: {
        type: String,
        required: true,
        trim: true
    },

    partnerUserId: {
        type: String,
        required: true,
        trim: true
    },

    meetStatus: {
        type: String,
        required: true,
        trim: true
    },

    initiatorMeetLocation: {
        type: String,
        required: true,
        trim: true
    },

    partnerMeetLocation: {
        type: String,
        required: true,
        trim: true
    },

    initiatorMeetDateTime: {
        type: DataTypes.DATE,
        required: true,
        trim: true,
    },

    partnerMeetDateTime: {
        type: DataTypes.DATE,
        required: true,
        trim: true,
    },

    dateNumber: {
        type: DataTypes.INTEGER,
        required: true
    }
},
    { timestamps: true }
);

export default dateSchedule;
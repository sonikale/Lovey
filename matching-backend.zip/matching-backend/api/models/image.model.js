import { DataTypes, UUIDV4 } from 'sequelize';

import sequelize from "../db/db.connect.js";

const photoAlbum = sequelize.define("photoAlbum", {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true,
        defaultValue: UUIDV4
    },

    userId: {
        type: String,
        required: true,
        trim: true,
    },

    imageUrl: {
        type: String,
        required: true,
        trim: true,
    },

    imageName: {
        type: String,
        required: true,
        trim: true,
    },

    isProfileImage: {
        type: DataTypes.BOOLEAN,
        required: true,
        trim: true,
        default: false,
    }
},
    { timestamps: true }
);

export default photoAlbum;
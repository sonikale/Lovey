import { DataTypes, UUIDV4 } from 'sequelize';

import sequelize from "../db/db.connect.js";

const answer = sequelize.define("answer", {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true,
        defaultValue: UUIDV4
    },

    userId: {
        type: String,
        required: true,
        trim: true,
    },

    questionId: {
        type: String,
        required: true,
        trim: true,
    },

    answerType: {
        type: String,
        required: true,
        trim: true,
    },

    answer: {
        type: String,
        required: true,
        trim: true,
    },

    optionId: {
        type: String,
        required: true,
        trim: true,
    }
},
    { timestamps: true }
);

export default answer;
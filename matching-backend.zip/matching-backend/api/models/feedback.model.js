import { DataTypes, UUIDV4 } from 'sequelize';
import sequelize from "../db/db.connect.js";

const Feedback = sequelize.define( "feedback", {
      id: {
        type: DataTypes.UUIDV4,
        primaryKey: true,
        defaultValue: UUIDV4
      },
      positiveFeedback: {
        type: String,
        required: true,
        trim: true,
      },
  
      negativeFeedback: {
        type: String,
        required: true,
        trim: true,
      },
  
      neutralFeedback: {
        type: String,
        required: true,
        trim: true,
      },
  
      partnerUserId: {
        type: String,
        required: true,
      },
  
      userId: {
        type: String,
        required: true,
        trim: true,
      },
  
      tellUsMoreAboutDate: {
        type: String,
        trim: true,
      },

      wantToGoOnSecondDate: {
        type: DataTypes.BOOLEAN,
        required: true,
        trim: true,
      }
    },
    {timestamps: true}
  );

export default Feedback;
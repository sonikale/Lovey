import { DataTypes, UUIDV4 } from 'sequelize';

import sequelize from "../db/db.connect.js";
  const stripeCustomer = sequelize.define( "stripeCustomer", {
      id: {
        type: DataTypes.UUIDV4,
        primaryKey: true,
        defaultValue: UUIDV4
      },
      
      userId: {
        type: String,
        required: true,
        trim: true,
        unique: true
      },
  
      customerId: {
        type: String,
        required: true,
        trim: true,
      },
  
      strpCreated: {
        type: DataTypes.DATE,
        required: true,
        trim: true,
      }
    },
    {timestamps: true}
  );

export default stripeCustomer;
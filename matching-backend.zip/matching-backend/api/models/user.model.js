import { DataTypes, INTEGER, UUIDV4 } from 'sequelize';

import sequelize from "../db/db.connect.js";
//user model
  const Users = sequelize.define( "users", {
      id: {
        type: DataTypes.UUIDV4,
        primaryKey: true,
        defaultValue: UUIDV4
      },
      firstName: {
        type: String,
        required: true,
        trim: true,
      },
  
      lastName: {
        type: String,
        required: true,
        trim: true,
      },
  
      email: {
        type: String,
        required: true,
        trim: true,
      },
  
      userName: {
        type: String,
        required: true,
      },
  
      phone: {
        type: String,
        required: true,
        trim: true,
        unique: true
      },
  
      country: {
        type: String,
        required: true,
        trim: true
      },

      state: {
        type: String,
        required: true,
        trim: true
      },
  
      city: {
        type: String,
        required: true,
        trim: true
      },
  
      address: {
        type: String,
        required: true,
        trim: true,
      },
  
      password: {
        type: String,
        required: true,
        trim: true,
      },

      jwttoken: {
        type: String,
        required: true,
        trim: true,
      },
      
      lastlogin: {
        type: DataTypes.DATE,
        required: true,
        trim: true,
      },

      aboutme: {
        type: String,
        required: true,
        trim: true
      },

      chatUserId: {
        type: String,
        required: true,
        trim: true
      },

      chatUserToken: {
        type: String,
        required: true,
        trim: true
      },

      chatUserTokenExpireAt: {
        type: INTEGER,
        required: true,
        trim: true
      },

      chatUserTokenUpdatedAt: {
        type: DataTypes.DATE,
        required: true,
        trim: true
      },

      fcmDeviceToken: {
        type: String,
        trim: true
      },

      deviceType: {
        type: String,
        trim: true
      },

      gender: {
        type: String,
        trim: true
      },

      dateOfBirth: {
        type: DataTypes.DATE,
        trim: true
      },

      userStatus: {
        type: String,
        trim: true,
        defaultValue: 'active'
      },

      age: {
        type: String,
        trim: true
      },

      travelDistanceUpto: {
        type: String,
        trim: true
      },
      
      profileCompleted: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },

      lattitude: {
        type: String,
        trim: true
      },

      longitude: {
        type: String,
        trim: true
      },
      calculatedMatches: {
        type: String,
        trim: true
      }
    },
    {timestamps: true}
  );

export default Users;
import { DataTypes, UUIDV4 } from 'sequelize';
import sequelize from "../db/db.connect.js";

const chatHistory = sequelize.define("chatHistory", {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true,
        defaultValue: UUIDV4
    },

    participant1UserId: {
        type: String,
        required: true,
        trim: true
    },

    participant2UserId: {
        type: String,
        required: true,
        trim: true
    },

    threadId: {
        type: String,
        required: true,
        trim: true
    },

    lastMsg: {
        type: String,
        trim: true
    },

    lastMsgAt: {
        type: DataTypes.DATE
    },
    
    conversationId: {
        type: String,
        trim: true
    },
    
    watermark: {
        type: String,
        trim: true
    }
},
    { timestamps: true }
);

export default chatHistory;
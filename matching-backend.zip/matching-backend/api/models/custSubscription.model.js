import { DataTypes, UUIDV4 } from 'sequelize';
import sequelize from "../db/db.connect.js";

const stripeSubscription = sequelize.define("stripeSubscription", {
  id: {
    type: DataTypes.UUIDV4,
    primaryKey: true,
    defaultValue: UUIDV4
  },

  userId: {
    type: String,
    required: true,
    trim: true
  },

  customerId: {
    type: String,
    required: true,
    trim: true
  },

  subscriptionId: {
    type: String,
    required: true,
    trim: true
  },

  productId: {
    type: String,
    required: true,
    trim: true
  },

  couponId: {
    type: String,
    trim: true
  },

  couponCode: {
    type: String,
    trim: true
  },

  subscriptionStatus: {
    type: String,
    required: true,
    trim: true
  },

  subscriptionEndDate: {
    type: DataTypes.DATE,
    required: true
  },

  message: {
    type: String,
    required: true,
    trim: true
  },

  cancelReason:{
    type: String,
    trim: true,
    defaultValue: ''
  }
},
  { timestamps: true }
);

export default stripeSubscription;
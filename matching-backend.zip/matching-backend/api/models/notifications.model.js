import { DataTypes, UUIDV4 } from 'sequelize';
import sequelize from "../db/db.connect.js";

const notifications = sequelize.define("notifications", {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true,
        defaultValue: UUIDV4
    },

    fromUserId: {
        type: String,
        required: true,
        trim: true
    },

    toUserId: {
        type: String,
        required: true,
        trim: true
    },

    isRead: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
    },

    notificationType: {
        type: String,
        trim: true,
        required: true
    },

    notificationTitle: {
        type: String,
        trim: true
    },

    notificationText: {
        type: String,
        trim: true
    },

},
    { timestamps: true }
);

export default notifications;
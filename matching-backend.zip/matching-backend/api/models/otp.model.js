import { DataTypes, UUIDV4 } from 'sequelize';
import sequelize from "../db/db.connect.js";

const OTP = sequelize.define("otpDetails", {
  id: {
    type: DataTypes.UUIDV4,
    primaryKey: true,
    defaultValue: UUIDV4
  },
  email: {
    type: String,
    trim: true
  },
  phone: {
    type: String,
    trim: true
  },
  otp: {
    type: String,
    required: true,
    trim: true
  }
},
  { timestamps: true }
);

export default OTP;
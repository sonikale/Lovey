import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { getCouponList } from '../utils/stripe/stripe.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get coupon list API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            let couponList = {};
            couponList = await getCouponList();

            context.log('coupon list fetched successfully. Details:', req.body);
            result = successResponse("Coupon list fetched successfully", couponList, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get coupon list API Error: " + error);
        result = errorResponse('Something went wrong while getting coupon list. Please contact support.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
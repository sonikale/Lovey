import Notifications from '../models/notifications.model.js';
import sequelize from "../db/db.connect.js";
import { QueryTypes } from 'sequelize';
import { sendPushNotification } from '../utils/fcm.js'
import * as clickSend from '../utils/clickSend.util.js';
import { messages, inAppMessages } from '../templates/SMSEmailTemplates.js';
import { createInAppNotification } from '../utils/notifications.js';

export async function Every15MinCron(context, myTimer) {
    var timeStamp = new Date().toISOString();
    if (myTimer.isPastDue) {
        context.log('Every15MinCron is late. Time:', timeStamp);
    }

    try {
        context.log('Cron Every15MinCron started!');
        // Send push notification before 15 mins of chat(chat gets enabled before 2 hrs of date)
        const dateScheduleList = await sequelize.query(` SELECT  "initiatorUserId", "partnerUserId", "meetStatus", "initiatorMeetLocation", "partnerMeetLocation", 
        "initiatorMeetDateTime", "partnerMeetDateTime", "dateNumber" FROM 
        "dateSchedule" where "meetStatus" like 'Accepted%' and (DATE_PART('day', now() - "initiatorMeetDateTime") <=1 or DATE_PART('day', now() - "partnerMeetDateTime") <= 1)`, { type: QueryTypes.SELECT });

        await Promise.all(dateScheduleList.map(async dateSchedule => {
            let meetDateTime;
            if (dateSchedule.meetStatus == 'AcceptedByPartner') {
                meetDateTime = new Date(dateSchedule.partnerMeetDateTime);
            } else {
                meetDateTime = new Date(dateSchedule.initiatorMeetDateTime);
            }

            const currentDate = new Date();

            // Calculate the time difference in milliseconds
            const timeDifferenceMs = meetDateTime - currentDate;

            // Convert the time difference to hours and minutes
            const hoursDifference = Math.floor(timeDifferenceMs / (1000 * 60 * 60));
            const minutesDifference = Math.floor((timeDifferenceMs % (1000 * 60 * 60)) / (1000 * 60));

            // Define the desired difference (2 hours and 15 minutes)
            const desiredHours = 2;
            const desiredMinutes = 15;

            if (desiredHours == hoursDifference && desiredMinutes <= minutesDifference) {
                const userList = await sequelize.query(` SELECT u.id, u.phone, u."firstName", u."fcmDeviceToken" FROM 
                users u where id in('${dateSchedule.initiatorUserId}','${dateSchedule.partnerUserId}')`, { type: QueryTypes.SELECT });

                userList.map(async user => {
                    let userDetails = { screen: 'notificationList', userId: user.id };

                    let pushNotificationBody = {
                        fcmDeviceToken: user.fcmDeviceToken,
                        userDetails,
                        title: messages.beforeChatOpenPNTitle,
                        body: messages.beforeChatOpenPNMsg.replace("{{minutes}}", minutesDifference)
                    };
                    await sendPushNotification(context, pushNotificationBody);
                    context.log('Push notification sent successfully for chat before 2 hrs for user id:', user.id);


                    const inAppNotificationInsertPayload = {
                        fromUserId: user.id,
                        toUserId: user.id,
                        isRead: false,
                        notificationTitle: messages.beforeChatOpenPNTitle,
                        notificationText: inAppMessages.beforeChatMsg
                    }
                    await createInAppNotification(inAppNotificationInsertPayload);
                    context.log('In app notification sent successfully for chat before 2 hrs for user id:', user.id);
                });
            }
        }));


        //----------------------- cron to send push notification and txt msg for chatbot-----------------------------------------
        const userList = await sequelize.query(`SELECT u.id, u.phone, u."firstName", u."fcmDeviceToken", u."profileCompleted", a."updatedAt"
            FROM users u INNER JOIN answer a on a."userId" = u.id where u."profileCompleted" = false and u."userStatus" = 'active' and a."questionId" = '4394f18a-ef4d-4a65-a93a-27cf53b6e99e';`, { type: QueryTypes.SELECT })

        await Promise.all(userList.map(async user => {
            const updatedAtFromDB = new Date(user.updatedAt); // Replace with your database value
            const currentDate = new Date();

            // Calculate the time difference in milliseconds
            const timeDifference = currentDate - updatedAtFromDB;

            // Convert the time difference from milliseconds to hours
            const hoursDifference = timeDifference / (1000 * 60 * 60);

            let userDetails = { screen: 'aphrodite', userId: user.id };

            let pushNotificationBody = {
                fcmDeviceToken: user.fcmDeviceToken,
                userDetails,
                title: '',
                body: ''
            };

            let insertPayload = {};
            // every 2 hrs
            if (hoursDifference >= 2 && hoursDifference < 4) {
                const profCompltNoteSent = await Notifications.findOne({ where: { fromUserId: user.id, notificationType: 'ProfileCompletion-2hr' } });
                if (!profCompltNoteSent) {
                    pushNotificationBody.title = messages.twoHrPNTitle;
                    pushNotificationBody.body = messages.twoHrPNMsg;
                    sendPushNotification(context, pushNotificationBody);

                    insertPayload = {
                        fromUserId: user.id,
                        toUserId: user.id,
                        isRead: false,
                        notificationType: 'ProfileCompletion-2hr',
                        notificationTitle: messages.twoHrPNTitle,
                        notificationText: messages.twoHrPNMsg
                    }
                    await Notifications.create(insertPayload);
                    context.log("Every15MinCron Cron - ProfileCompletion-2hr Push notification sent");
                }
            }
            else if (hoursDifference >= 4 && hoursDifference < 6) {
                const profCompltNoteSent = await Notifications.findOne({ where: { fromUserId: user.id, notificationType: 'ProfileCompletion-4hr' } });
                if (!profCompltNoteSent) {
                    // after every 4 hrs send push notification
                    pushNotificationBody.title = messages.fourHrPNTitle;
                    pushNotificationBody.body = messages.fourHrPNMsg;
                    sendPushNotification(context, pushNotificationBody);

                    insertPayload = {
                        fromUserId: user.id,
                        toUserId: user.id,
                        isRead: false,
                        notificationType: 'ProfileCompletion-4hr',
                        notificationTitle: messages.fourHrPNTitle,
                        notificationText: messages.fourHrPNMsg
                    }
                    await Notifications.create(insertPayload);

                    // Send SMS to user after 4 hrs
                    let sendSMSObj = {
                        to: process.env["COUNTRY_CODE"] + user.phone,
                        body: messages.fourHrTxtMsg.replace('{{Users Name}}', user.firstName)
                    }

                    clickSend.SendSMS(context, sendSMSObj);
                    context.log("Every15MinCron Cron - ProfileCompletion-4hr Push notification sent");
                }
            } else if (hoursDifference >= 6 && hoursDifference < 8) {
                const profCompltNoteSent = await Notifications.findOne({ where: { fromUserId: user.id, notificationType: 'ProfileCompletion-6hr' } });
                if (!profCompltNoteSent) {
                    // after every 6 hrs
                    pushNotificationBody.title = messages.sixHrPNTitle;
                    pushNotificationBody.body = messages.sixHrPNMsg;
                    sendPushNotification(context, pushNotificationBody);

                    insertPayload = {
                        fromUserId: user.id,
                        toUserId: user.id,
                        isRead: false,
                        notificationType: 'ProfileCompletion-6hr',
                        notificationTitle: messages.sixHrPNTitle,
                        notificationText: messages.sixHrPNMsg
                    }
                    await Notifications.create(insertPayload);
                    context.log("Every15MinCron Cron - ProfileCompletion-6hr Push notification sent");
                }
            } else if (hoursDifference >= 8 && hoursDifference < 12) {
                const profCompltNoteSent = await Notifications.findOne({ where: { fromUserId: user.id, notificationType: 'ProfileCompletion-8hr' } });
                if (!profCompltNoteSent) {
                    // Send SMS to user after 8 hrs
                    let sendSMSObj = {
                        to: process.env["COUNTRY_CODE"] + user.phone,
                        body: messages.eightHrTxtMsg.replace('{{Users Name}}', user.firstName)
                    }

                    clickSend.SendSMS(context, sendSMSObj);
                    insertPayload = {
                        fromUserId: user.id,
                        toUserId: user.id,
                        isRead: false,
                        notificationType: 'ProfileCompletion-8hr',
                        notificationTitle: 'ProfileCompletion-8hr-TextMsg',
                        notificationText: sendSMSObj.body
                    }
                    await Notifications.create(insertPayload);
                    context.log("Every15MinCron Cron - ProfileCompletion-8hr Push notification sent");
                }
            } else if (hoursDifference >= 12 && hoursDifference < 16) {
                const profCompltNoteSent = await Notifications.findOne({ where: { fromUserId: user.id, notificationType: 'ProfileCompletion-12hr' } });
                if (!profCompltNoteSent) {
                    // after every 12 hrs
                    pushNotificationBody.title = messages.twelveHrPNTitle;
                    pushNotificationBody.body = messages.twelveHrPNMsg;
                    sendPushNotification(context, pushNotificationBody);

                    insertPayload = {
                        fromUserId: user.id,
                        toUserId: user.id,
                        isRead: false,
                        notificationType: 'ProfileCompletion-12hr',
                        notificationTitle: messages.twelveHrPNTitle,
                        notificationText: messages.twelveHrPNMsg
                    }
                    await Notifications.create(insertPayload);

                    // Send SMS to user after 12 hrs
                    let sendSMSObj = {
                        to: process.env["COUNTRY_CODE"] + user.phone,
                        body: messages.twelveHrTxtMsg.replace('{{Users Name}}', user.firstName)
                    }

                    clickSend.SendSMS(context, sendSMSObj);
                    context.log("Every15MinCron Cron - ProfileCompletion-12hr Push notification sent");
                }
            } else if (hoursDifference >= 16 && hoursDifference < 23) {
                const profCompltNoteSent = await Notifications.findOne({ where: { fromUserId: user.id, notificationType: 'ProfileCompletion-16hr' } });
                if (!profCompltNoteSent) {
                    // Send SMS to user after 16 hrs
                    let sendSMSObj = {
                        to: process.env["COUNTRY_CODE"] + user.phone,
                        body: messages.sixteenHrTxtMsg
                    }

                    clickSend.SendSMS(context, sendSMSObj);

                    insertPayload = {
                        fromUserId: user.id,
                        toUserId: user.id,
                        isRead: false,
                        notificationType: 'ProfileCompletion-16hr',
                        notificationTitle: 'ProfileCompletion-16hr-TextMsg',
                        notificationText: sendSMSObj.body
                    }
                    await Notifications.create(insertPayload);
                    context.log("Every15MinCron Cron - ProfileCompletion-16hr Push notification sent");
                }
            } else if (hoursDifference >= 23 && hoursDifference < 24) {
                const profCompltNoteSent = await Notifications.findOne({ where: { fromUserId: user.id, notificationType: 'ProfileCompletion-24hr' } });
                if (!profCompltNoteSent) {
                    // after every 23 hrs
                    pushNotificationBody.title = messages.twentyFourHrPNTitle;
                    pushNotificationBody.body = messages.twentyFourHrPNMsg;
                    sendPushNotification(context, pushNotificationBody);

                    insertPayload = {
                        fromUserId: user.id,
                        toUserId: user.id,
                        isRead: false,
                        notificationType: 'ProfileCompletion-24hr',
                        notificationTitle: messages.twentyFourHrPNTitle,
                        notificationText: messages.twentyFourHrPNMsg
                    }
                    await Notifications.create(insertPayload);
                    context.log("Every15MinCron Cron - ProfileCompletion-24hr Push notification sent");
                }
            }
        }));

        context.log("Every15MinCron Cron ran successfully");
    }
    catch (err) {
        context.log('Error in Every15MinCron. Details: ', err);
    }
};
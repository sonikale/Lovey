import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import imageModel from '../models/image.model.js';
import { validateToken } from '../utils/token.util.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get Image API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const images = await imageModel.findAll({ where: { userId: validateTokenResult.userDetails.dataValues.id } });
            context.log('Photo album fetched successfully for userId:', validateTokenResult.userDetails.dataValues.id);
            result = successResponse("Photo album fetched successfully.", images, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get Image API Error: " + error);
        result = errorResponse('Something went wrong while fetching the photo album. Please contact support.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
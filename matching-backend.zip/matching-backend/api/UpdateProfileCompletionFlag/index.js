import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import User from '../models/user.model.js'
import { messages, inAppMessages } from '../templates/SMSEmailTemplates.js';
import * as clickSend from '../utils/clickSend.util.js';
import { createInAppNotification } from '../utils/notifications.js';
import { findAttachmentStyle, findLoveLanguage, calculatePersonalityAssessmentScore } from '../utils/ruleEngine.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("api/UpdateProfileCompletionFlag API START");
        // ------------commented authentication as request will be from chatbot----------------
        // const validateTokenResult = await validateToken(context, req);

        // if (!validateTokenResult.error) {
        const updateResult = await User.update({ profileCompleted: true }, { where: { id: req.body.userId } });

        // find and store attachment style, love language, and personality assessment score
        findAttachmentStyle(context, req.body.userId);
        findLoveLanguage(context, req.body.userId);
        calculatePersonalityAssessmentScore(context, req.body.userId)

        // Send SMS to partner
        const userDetails = await User.findOne({ where: { id: req.body.userId } });
        let sendSMSObj = {
            to: process.env["COUNTRY_CODE"] + userDetails.phone,
            body: messages.purchaseSubscriptionAfterBotCmplt
        }

        await clickSend.SendSMS(context, sendSMSObj);
        // in app nootification
        const inAppNotificationInsertPayload = {
            fromUserId: userDetails.id,
            toUserId: userDetails.id,
            isRead: false,
            notificationTitle: inAppMessages.purchaseSubscriptionAfterBotCmpltTitle,
            notificationText: inAppMessages.purchaseSubscriptionAfterBotCmpltMsg
        }
        createInAppNotification(inAppNotificationInsertPayload);

        context.log('Profile completion status updated successfully. Details: ', req.body);
        result = successResponse("Profile completion status updated successfully", updateResult, StatusCodes.OK);
        // } else {
        //     result = validateTokenResult;
        // }
    } catch (error) {
        context.log("api/UpdateProfileCompletionFlag API Error. Details:", error, " req.body: ", req.body);
        result = errorResponse('Something went wrong while updating profile completion flag. Please contact admin.', StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
};

import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import * as chatbotData from '../utils/chatbot.util.js';
import { questionsDictionary } from '../core/chatbotQuestionSeuenceAndIdMapping.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get chatbot question API START");
        // ------------commented authentication as request will be from chatbot----------------
        // const validateTokenResult = await validateToken(context, req);

        // if (!validateTokenResult.error) {
        let questionData = {};
        questionData.question = await chatbotData.getQuestionById(questionsDictionary[req.query.quesSeq]);
        questionData.options = await chatbotData.getQuestionOption(questionsDictionary[req.query.quesSeq]);

        context.log('Chatbot questions fetched successfully:');
        result = successResponse("Questionnaire fetched successfully.", questionData, StatusCodes.OK);
        // } else {
        //     result = validateTokenResult;
        // }
    } catch (error) {
        context.log("Get chatbot question API Error. Details:", error);
        result = errorResponse('Something went wrong while getting next question. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
};

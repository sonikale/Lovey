import bcryptjs from 'bcryptjs';
import { StatusCodes } from 'http-status-codes';
import User from '../models/user.model.js';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import createError from 'http-errors';
import { createJwtToken } from '../utils/token.util.js';
// import sequelize from 'sequelize';
import * as constants from '../core/constants.js';
import * as schema from '../utils/schema.js'
import StripeSubscription from '../models/custSubscription.model.js';
import { messages } from '../templates/SMSEmailTemplates.js';
import * as clickSend from '../utils/clickSend.util.js';
import OTP from '../models/otp.model.js';
import { generateOTP } from "../utils/otp.util.js";
import { verifyPurchaseWithApple } from '../utils/getInPurchaseReceipt.js';
import { Op, QueryTypes } from 'sequelize';
import sequelize from "../db/db.connect.js";

export default async function (context, req) {
    let result = "";

    try {
        context.log("Login API Start");

        const validSchema = schema.validateRequest(schema.login, req.body);
        if (validSchema.isValidRequest) {
            const user = await User.findOne({ where: { userName: req.body.userName } });

            if (!user) throw createError.Conflict(constants.messages.LOGIN_ERROR);

            const isSame = await bcryptjs.compare(req.body.password, user.password);

            if (isSame) {
                // check if user is Admin add 2 factor auth
                if (user.userStatus == 'admin') {
                    let otpPayload = {
                        phone: user.phone,
                        otp: generateOTP()
                    }

                    await OTP.destroy({ where: { phone: user.phone } });
                    await OTP.create(otpPayload);

                    let sendSMSObj = {
                        to: process.env["COUNTRY_CODE"] + user.phone,
                        body: messages.phoneVerifyBody.replace('{{OTPCode}}', otpPayload.otp)
                    }

                    const res = await clickSend.SendSMS(context, sendSMSObj);
                    if (res.body.http_code == 200) {
                        result = successResponse(constants.messages.OTP_SENT, { twoFactorAuth: true, userStatus: 'admin', userId: user.id, phone: user.phone }, StatusCodes.OK);
                    } else {
                        result = errorResponse("OTP not sent. Please try again.", StatusCodes.INTERNAL_SERVER_ERROR);
                    }
                } else {
                    let loginPayload = { userId: user.id, travelDistanceUpto: user.travelDistanceUpto, lattitude: user.lattitude, longitude: user.longitude };
                    context.log("Generating new jwt token.");
                    loginPayload.token = createJwtToken({ email: user.email });
                    loginPayload.subscription = await StripeSubscription.findOne({ where: { subscriptionStatus: 'active', userId: user.id } });

                    await User.update({ jwttoken: loginPayload.token, lastlogin: sequelize.literal('CURRENT_TIMESTAMP'), fcmDeviceToken: req.body.fcmDeviceToken, deviceType: req.body.deviceType }, { where: { id: user.id } });
                    context.log("Login successful for user.userId: ", user.id);
                    if (req.body.deviceType === "ios") {
                        if (user && user.id) {
                            let iosdata = await sequelize.query(`SELECT "userId","receipt" FROM "appleReceipt" where "userId" = '${user.id}';`, { type: QueryTypes.SELECT });
                            console.log('isodata', iosdata)
                            if (iosdata && iosdata.length > 0) {
                                loginPayload.receiptPurchase = await verifyPurchaseWithApple(iosdata[0].receipt, user.id, req.body.deviceType);

                            }
                        }
                    }
                    result = successResponse(constants.messages.LOGIN_SUCCESS, loginPayload, StatusCodes.OK);
                }
            } else {
                context.log("Unsuccessful login for user.userId: ", user.id);
                result = errorResponse(constants.messages.LOGIN_ERROR, StatusCodes.BAD_REQUEST);
            }
        } else {
            result = validationResponse(constants.messages.LOGIN_ERROR);
        }
    } catch (error) {
        context.log("Login API Error:" + error);
        result = errorResponse((error.message.length > 0) ? error.message : constants.messages.LOGIN_FAILED, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
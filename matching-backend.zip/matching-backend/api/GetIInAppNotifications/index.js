import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { getNotifications } from '../utils/notifications.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get In App Notifications API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const notifications = await getNotifications(validateTokenResult.userDetails.dataValues.id, 'InApp');
            context.log('In app notifications fetched successfully for user:', validateTokenResult.userDetails.dataValues.id);
            result = successResponse("In app notifications fetched successfully", notifications, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get In App Notifications API Error: " + error);
        result = errorResponse('Something went wrong while getting in app notifications. Please contact admin.', StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
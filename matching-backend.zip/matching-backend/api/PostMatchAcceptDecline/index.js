import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import { messages } from '../core/constants.js';
import { postMatchAcceptDeclineStatus } from '../utils/matches.js';
import { sendPushNotification } from '../utils/fcm.js';
import  * as smsTemplate  from '../templates/SMSEmailTemplates.js';
import * as clickSend from '../utils/clickSend.util.js';
import User from '../models/user.model.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Post match accept decline API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.postMatchAcceptDecline, req.body);
            if (validSchema.isValidRequest) {
                const matchStatus = await postMatchAcceptDeclineStatus(req.body);
                if (req.body.status == 'accept') {
                    // send Push notification for accept
                    const userDetail = await User.findOne({ where: { id: req.body.userId } });
                    const partnerDetails = await User.findOne({ where: { id: req.body.partnerUserId } });
                    let userDetails = { screen: 'Match', partnerUserId: req.body.partnerUserId };
    
                    const pushMotificationBody = {
                        fcmDeviceToken: partnerDetails.fcmDeviceToken,
                        userDetails,
                        title: smsTemplate.messages.recommendedMatchAcceptPNTitle,
                        body:smsTemplate.messages.recommendedMatchAcceptPNMsg.replace('{{NAME}}', userDetail.firstName)
                    };
                    sendPushNotification(context, pushMotificationBody);

                    // send txt msg for accept
                    let sendSMSObj = {
                        to: process.env["COUNTRY_CODE"] + partnerDetails.phone,
                        body: smsTemplate.messages.recommendedMatchAcceptTxtMsg.replace('{{NAME}}', partnerDetails.firstName)
                    }
            
                    await clickSend.SendSMS(context, sendSMSObj);
                }
                context.log(`Updated match status successfully for user Id: ${validateTokenResult.userDetails.dataValues.id} and partner id: ${req.body.partnerUserId}`);
                result = successResponse(`${messages.POST_MATCH_STATUS_SUCCESS}`, matchStatus, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Post match accept decline API Error: " + error);
        result = errorResponse((error.message.length > 0) ? error.message : messages.POST_MATCH_STATUS_ERROR, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
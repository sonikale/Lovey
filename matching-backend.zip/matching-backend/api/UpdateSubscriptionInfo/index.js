import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import custSubscriptionModel from '../models/custSubscription.model.js';
import * as emailService from '../utils/emailService.js';
import * as smsTemplate from '../templates/SMSEmailTemplates.js';
import { createInAppNotification } from '../utils/notifications.js';
import { runAlgorithm } from '../utils/ruleEngine.js';
import sequelize from "../db/db.connect.js";
import { QueryTypes } from 'sequelize';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Update Subscription Info API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.updateSubscriptionInfo, req.body);
            if (req.body.deviceType === "ios" && validateTokenResult.userDetails.dataValues.gender === "Female") {
                // Insert into "stripeSubscription" ("userId","customerId","subscriptionId","productId","subscriptionStatus","subscriptionEndDate","createdAt","updatedAt") values ('b1464772-3200-4818-bd59-e24f9742d06f','CUST_123','2000000488027320','LoveyBasic','active','2023-09-11 07:56:07+00','2023-09-11 07:56:07+00','2023-09-11 07:56:07+00')
                const saveServeData = await sequelize.query(`Insert into "stripeSubscription" ("userId","customerId","subscriptionId","productId","subscriptionStatus","subscriptionEndDate","createdAt","updatedAt") VALUES ('${validateTokenResult.userDetails.dataValues.id}','CUST_IOS','SUBS_IOS','LoveyBasic','active',current_timestamp,current_timestamp,current_timestamp)`, { type: QueryTypes.INSERT });
                // Send email to user on purchase subscription
                const userData = validateTokenResult.userDetails.dataValues;
                const emailPayload = {
                    subject: smsTemplate.messages.purchaseSubscriptionSubject,
                    mailBody: smsTemplate.messages.purchaseSubscriptionBody.replace('{{Subscribers Name}}', userData.firstName + " " + userData.lastName).replace('{{Plan Name}}', req.body.subscriptionName).replace('{{Price}}', req.body.price),
                    toEmail: validateTokenResult.userDetails.dataValues.email,
                    toName: validateTokenResult.userDetails.dataValues.firstName + ' ' + validateTokenResult.userDetails.dataValues.lastName
                }
                emailService.sendMail(context, emailPayload);

                // in app notification
                const inAppNotificationInsertPayload = {
                    fromUserId: validateTokenResult.userDetails.dataValues.id,
                    toUserId: validateTokenResult.userDetails.dataValues.id,
                    isRead: false,
                    notificationTitle: smsTemplate.inAppMessages.purchaseSubscriptionTitle,
                    notificationText: smsTemplate.inAppMessages.purchaseSubscriptionMsg.replace('{{Plan Name}}', req.body.subscriptionName)
                }
                createInAppNotification(inAppNotificationInsertPayload);
                runAlgorithm(context, validateTokenResult.userDetails.dataValues.id);
            } else {
                const userData = validateTokenResult.userDetails.dataValues;
                if (validSchema.isValidRequest) {
                    await custSubscriptionModel.update({ subscriptionStatus: req.body.newStatus }, { where: { subscriptionId: req.body.subscriptionId, subscriptionStatus: req.body.prevStatus } });
                    if (req.body.newStatus == 'active') {

                        // Send email to user on purchase subscription
                        const emailPayload = {
                            subject: smsTemplate.messages.purchaseSubscriptionSubject,
                            mailBody: smsTemplate.messages.purchaseSubscriptionBody.replace('{{Subscribers Name}}', userData.firstName + " " + userData.lastName).replace('{{Plan Name}}', req.body.subscriptionName).replace('{{Price}}', req.body.price),
                            toEmail: validateTokenResult.userDetails.dataValues.email,
                            toName: validateTokenResult.userDetails.dataValues.firstName + ' ' + validateTokenResult.userDetails.dataValues.lastName
                        }
                        emailService.sendMail(context, emailPayload);

                        // in app notification
                        const inAppNotificationInsertPayload = {
                            fromUserId: validateTokenResult.userDetails.dataValues.id,
                            toUserId: validateTokenResult.userDetails.dataValues.id,
                            isRead: false,
                            notificationTitle: smsTemplate.inAppMessages.purchaseSubscriptionTitle,
                            notificationText: smsTemplate.inAppMessages.purchaseSubscriptionMsg.replace('{{Plan Name}}', req.body.subscriptionName)
                        }
                        createInAppNotification(inAppNotificationInsertPayload);
                        //if status is active then call rule engine algo function run in background
                        if (validateTokenResult.userDetails.dataValues.gender === "Female") {
                            runAlgorithm(context, validateTokenResult.userDetails.dataValues.id);
                        }
                    }
                    context.log('Subscription information updated successfully. Details:', req.body);
                    result = successResponse("Subscription information updated successfully", {}, StatusCodes.OK);
                } else {
                    result = validationResponse(validSchema.error);
                }
            }
        } else {
            result = validateTokenResult;
        }

    } catch (error) {
        context.log("Update Subscription Info API Error: " + error);
        result = errorResponse('Something went wrong while updating subscription information. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import { updateUserInfoByAdmin } from '../utils/common.util.js';
import { messages } from '../core/constants.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Update User Info By Admin API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.updateUserInfoByAdmin, req.body);
            if (validSchema.isValidRequest) {
                await updateUserInfoByAdmin(req.body);
                context.log("Updated user info Successfully. Details: ", req.body);
                let responseMessage = messages.UPDATE_USER_INFO_BY_ADMIN_SUCCESS;

                if (req.body.userStatus == 'active') {
                    responseMessage = messages.UPDATE_USER_ACTIVE_STATUS_BY_ADMIN_SUCCESS;
                } else if (req.body.userStatus == 'inactive') {
                    responseMessage = messages.UPDATE_USER_INACTIVE_STATUS_BY_ADMIN_SUCCESS;
                } else if (req.body.userStatus == 'delete') {
                    responseMessage = messages.UPDATE_USER_DELETE_STATUS_BY_ADMIN_SUCCESS;
                }

                result = successResponse(responseMessage, {}, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Update User Info By Admin API Error: " + error);
        result = errorResponse(messages.UPDATE_USER_INFO_BY_ADMIN_ERROR, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
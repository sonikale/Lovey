import { StatusCodes } from 'http-status-codes';
import bcryptjs from "bcryptjs";
import User from '../models/user.model.js';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import httpError from "http-errors";
import * as schema from '../utils/schema.js';
import * as constants from '../core/constants.js';

export default async function (context, req) {
  let result = "";
  try {
    context.log("Forgot Password API START");
    const validSchema = schema.validateRequest(schema.forgotPassword, req.body);
    if (validSchema.isValidRequest) {
      let user, searchCriteria = {};
      if (req.body.email) {
        searchCriteria.email = req.body.email;
      } else {
        searchCriteria.phone = req.body.phone;
      }
      user = await User.findOne({ where: searchCriteria });
      if (!user) {
        throw httpError.Conflict(constants.messages.USER_NOT_EXIST);
      }

      let newPassword = req.body.newPassword ? req.body.newPassword.trim() : "";
      await User.update({ password: await bcryptjs.hash(newPassword, 10) }, { where: { id: user.id } });

      result = successResponse("Password updated successfully", {}, StatusCodes.OK);
    } else {
      context.log('Invalid Schema. Details:', validSchema.error);
      result = validationResponse(validSchema.error);
    }
  } catch (error) {
    context.log("Forgot Password API Error. Details:", error);
    result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong while updating your password. Please contact support', StatusCodes.BAD_REQUEST);
  }

  context.res = {
    status: result.statusCode,
    body: result
  }
}
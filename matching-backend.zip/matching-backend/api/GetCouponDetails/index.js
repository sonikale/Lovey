import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import { getCouponDetailsByCode } from '../utils/stripe/stripe.js';
import { messages } from '../core/constants.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get coupon details API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.validateCoupon, req.query);
            if (validSchema.isValidRequest) {
                const coupon = await getCouponDetailsByCode(req.query.couponCode);

                context.log('Fetched coupon details successfully. Details:', req.query);
                result = successResponse(messages.COUPON_DETAILS_SUCCESS, coupon.data, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Validate coupon API Error: " + error);
        result = errorResponse(messages.COUPON_DETAILS_ERROR, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
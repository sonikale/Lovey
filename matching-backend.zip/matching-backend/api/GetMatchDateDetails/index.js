import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import { messages } from '../core/constants.js';
import { getMatchDateSchedule } from '../utils/matchDateSchedule.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get match date details API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.getMatchDateDetails, req.query);
            if (validSchema.isValidRequest) {
                const dateScheduleDetails = await getMatchDateSchedule(validateTokenResult.userDetails.dataValues.id, req.query.partnerUserId);
                context.log(`Fetched date schedule successfully for user Id: ${validateTokenResult.userDetails.dataValues.id} and partner id: ${req.query.partnerUserId}`);
                result = successResponse(`${messages.GET_DATE_SCHEDULE_SUCCESS}`, dateScheduleDetails, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get match date details API Error: " + error);
        result = errorResponse((error.message.length > 0) ? error.message : messages.GET_DATE_SCHEDULE_ERROR, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
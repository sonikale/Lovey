import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import imageModel from '../models/image.model.js';
import * as schema from '../utils/schema.js';
import { validateToken } from '../utils/token.util.js';
import { getAzureBlobClient } from '../utils/azure.util.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Upload Image API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.uploadImage, req.body);
            if (validSchema.isValidRequest) {
                const blockBlobClient = await getAzureBlobClient(req.body.imageName);
                const imageUploadURL = blockBlobClient.url;

                const options = { blobHTTPHeaders: { blobContentType: req.body.imageType } };
                const newImgBuffer = Buffer.from(req.body.imageBuffer, 'base64');

                await blockBlobClient.upload(newImgBuffer, newImgBuffer.length, options)
                    .then(async (res) => {
                        const imageUploadPayload = {
                            userId: req.body.userId,
                            imageUrl: imageUploadURL,
                            imageName: req.body.imageName,
                            isProfileImage: req.body.isProfileImage
                        };
                        await imageModel.create(imageUploadPayload);
                        context.log('Successfully uploaded image for userId:', req.body.userId);
                        result = successResponse("Photo Uploaded.", imageUploadPayload, StatusCodes.OK);
                    }).catch((err) => {
                        context.log('Error while uploading image for userId:', req.body.userId, ' Details:', err);
                        result = errorResponse('Error while uploading image. Please try again.', StatusCodes.EXPECTATION_FAILED);
                    });
            } else {
                context.log('Invalid Schema. Details:', validSchema.error);
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Upload Image API Error: " + error);
        result = errorResponse('Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
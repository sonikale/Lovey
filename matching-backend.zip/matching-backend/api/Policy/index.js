import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import fs from 'fs/promises';
import path from 'path';

export default async function (context, req) {
    let result = "";
    let htmlContent;

    try {
        context.log("Policy API START");

        const functionDirectory = context.executionContext.functionDirectory;
        htmlContent = await fs.readFile(path.resolve(functionDirectory, 'tnc.html'), 'utf-8');
        result = successResponse(htmlContent, StatusCodes.OK);

    } catch (error) {
        context.log("Policy- API Error. Details:", error);
        result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        headers: {
            'Content-Type': 'text/html',
        },
        status: result.statusCode,
        body: htmlContent,
    }
}
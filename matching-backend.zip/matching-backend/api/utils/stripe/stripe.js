import Stripe from 'stripe';
const stripe = new Stripe(process.env["STRIPE_KEY"], { maxNetworkRetries: 2 });
import createError from 'http-errors';
import stripeSubscription from '../../models/custSubscription.model.js';

async function createCustomer(customer) {
    return await stripe.customers.create({
        name: customer.firstName + " " + customer.lastName,
        email: customer.email
    });
}

async function getSubscriptionList(planId) {
    let subscriptions = {};

    if (planId) {
        subscriptions = await stripe.subscriptions.list({ plan: planId });
    } else {
        subscriptions = await stripe.subscriptions.list({});
    }

    return subscriptions;
}

async function createPaymentMethod(payment_method) {
    return await stripe.paymentMethods.create({
        type: 'card',
        card: {
            number: payment_method.cardNumber,
            exp_month: payment_method.expMonth,
            exp_year: payment_method.expYear,
            cvc: payment_method.cvc,
        },
    });
}

async function attachAndUpdateCustomerPaymentMethod(payment_method, customerId) {
    await stripe.paymentMethods.attach(payment_method, { customer: customerId });
    return await stripe.customers.update(
        customerId, {
        invoice_settings: {
            default_payment_method: payment_method
        }
    });
}

async function createSubscription(customerId, priceId, coupon) {
    let subscriptionPayload = {
        customer: customerId,
        items: [{ price: priceId }],
        payment_settings: {
            payment_method_options: {
                card: {
                    request_three_d_secure: 'any',
                },
            },
            payment_method_types: ['card'],
            save_default_payment_method: 'on_subscription',
        },
        expand: ['latest_invoice.payment_intent'],
    };

    if (coupon) {
        subscriptionPayload.coupon = coupon;
    }
    return await stripe.subscriptions.create(subscriptionPayload);
}

async function cancelSubscription(subscriptionId) {
    return await stripe.subscriptions.cancel(subscriptionId);
}

async function getProductList() {
    const products = await stripe.products.list({ active: true });
    return products.data;
}

async function getCouponList() {
    let couponList = await stripe.promotionCodes.list({ active: true });
    // Filter out coupons whoes name starts with Influencer_
    if (couponList.data.length > 0) {
        couponList.data = couponList.data.filter(obj => {
            if (!obj.coupon.name.startsWith("Influencer_")) {
                return obj;
            }
        });
    }
    return couponList;
}

async function getCouponDetailsByCode(couponCode) {
    return await stripe.promotionCodes.list({ code: couponCode });
}

async function getActiveSubscription(context, customerId) {
    try {
        const customer = await stripe.customers.retrieve(customerId, {
            expand: ['subscriptions'],
        });

        // Check if the customer has any subscriptions
        if (customer.subscriptions && customer.subscriptions.data.length > 0) {
            // Find the active subscription, if any
            return customer.subscriptions.data.find(
                subscription => subscription.status === 'active'
            );
        }

        return null; // Customer has no subscriptions
    } catch (error) {
        context.log('Error while getting active subscription:', error);
        throw createError[500]('Error while getting active subscription');
    }
}
async function getAllActiveSubscription(context) {
    try {
        return await stripe.subscriptions.list({ status: 'active' });
    } catch (error) {
        context.log('Error while getting active subscription:', error);
        throw createError[500]('Error while getting active subscription');
    }
}

async function getProductInfoByActiveSubscription(context, customerId) {
    try {
        const customer = await stripe.customers.retrieve(customerId, {
            expand: ['subscriptions'],
        });

        // Check if the customer has any subscriptions
        if (customer.subscriptions && customer.subscriptions.data.length > 0) {
            // Find the active subscription, if any
            let subscriptions = customer.subscriptions.data.find(
                subscription => subscription.status === 'active'
            );
            if (subscriptions) {
                const productId = subscriptions.plan.product;
                // Retrieve product information for productId using the Stripe Products API
                let productInfo = await stripe.products.retrieve(productId);
                return productInfo;

            }
        }
        return null; // Customer has no subscriptions
    } catch (error) {
        context.log('Error in getProductInfoByActiveSubscription:', error);
        throw createError[500]('Error while getting Product information by active subscription');
    }
}

async function getSubscriptionInfo(context, customerId) {
    try {
        const customer = await stripe.customers.retrieve(customerId, {
            expand: ['subscriptions'],
        });
        let obj = {}
        // Check if the customer has any subscriptions
        if (customer.subscriptions && customer.subscriptions.data.length > 0) {
            // Find the active subscription, if any
            let subscriptions = customer.subscriptions.data.find(
                subscription => subscription.status === 'active'
            );
            if (subscriptions) {
                const productId = subscriptions.plan.product;
                // Retrieve product information for productId using the Stripe Products API
                let productInfo = await stripe.products.retrieve(productId);
                obj = {
                    productInformation: productInfo,
                    subscription: subscriptions
                }
                return obj;

            }
        }
        return null; // Customer has no subscriptions
    } catch (error) {
        context.log('Error in getProductInfoByActiveSubscription:', error);
        throw createError[500]('Error while getting Product information by active subscription');
    }
}

async function getProductPrice(productId) {
    return await stripe.prices.list({ product: productId });
}

async function upgradeSubscription(context, data) {
    try {
        // Retrieve the subscription from Stripe
        const subscription = await stripe.subscriptions.retrieve(data.subscriptionId);

        // Build the new items object with the updated product ID and quantity
        const newItems = [
            {
                id: subscription.items.data[0].id, // Existing item ID
                price: data.newProductId,
                quantity: data.quantity
            }
        ];

        // Update the subscription with the new items object
        return await stripe.subscriptions.update(data.subscriptionId, {
            items: newItems,
        });
    } catch (error) {
        context.log('Error upgrading subscription:', error);
        throw createError[500]('Error upgrading subscription');
    }
}

const getPaymentMethodsForCustomer = async (customerId) => {
    return await stripe.paymentMethods.list({
        customer: customerId,
        type: 'card',
    });
}

async function retrieveCustomer(customerId) {
    return await stripe.customers.retrieve(customerId);
}


async function retrieveProduct(priceId) {
    return await stripe.prices.retrieve(priceId, {
        expand: ['product'],
    });
}

async function getUnusedCouponList(userId, couponList) {
    let unusedCoupons = { data: [] };
    const subscriptions = await stripeSubscription.findAll({ where: { userId: userId } });
    if (subscriptions && subscriptions.length > 0 && couponList.data.length > 0) {
        //Find values that are in unusedCoupons but not in subscriptions
        unusedCoupons.data = couponList.data.filter(obj => {
            return !subscriptions.some(obj2 => {
                return obj.code == obj2.couponCode;
            });
        });
    } else {
        unusedCoupons = couponList;
    }
    return unusedCoupons;
}

export {
    createCustomer, getSubscriptionList, createPaymentMethod, attachAndUpdateCustomerPaymentMethod, createSubscription,
    cancelSubscription, getProductList, getCouponList, getActiveSubscription, getProductPrice, upgradeSubscription, getPaymentMethodsForCustomer,
    retrieveCustomer, getCouponDetailsByCode, retrieveProduct, getUnusedCouponList, getProductInfoByActiveSubscription, getAllActiveSubscription,getSubscriptionInfo
};
import User from '../models/user.model.js';
import ChatHistory from '../models/chatHistory.model.js';
import * as azureApi from './azureCommunication.js';
import createError from 'http-errors';
import { StatusCodes } from 'http-status-codes';
import { Op, QueryTypes } from 'sequelize';
import moment from 'moment';
import sequelize from "../db/db.connect.js";
import { rules } from '../core/constants.js';
import { sendPushNotification } from '../utils/fcm.js'
import * as clickSend from '../utils/clickSend.util.js';
import { messages } from '../templates/SMSEmailTemplates.js';

export async function getChatIdentity(context, userId) {

    const user = await User.findOne({ where: { id: userId } });
    let chatIdentityData = {
        "chatUserToken": user.chatUserToken,
        "chatUserId": user.chatUserId,
        "userId": userId,
        "userName": user.firstName
    };

    if (user.chatUserId && user.chatUserToken) {
        const tokenCreatedAt = moment(user.chatUserTokenUpdatedAt).utc().format(rules.DATE_TIME_FORMAT);
        const datetimeNow = moment().utc().format(rules.DATE_TIME_FORMAT);
        const timeDifference = moment(datetimeNow).diff(tokenCreatedAt, 'seconds');

        if (timeDifference > user.chatUserTokenExpireAt) {
            //REFRESH THE ACCESS TOKEN USING AZURE USER ID
            const azureAccessDetails = await azureApi.refreshAzureChatToken(user.chatUserId);

            if (azureAccessDetails.data.chatUserToken !== "") {
                chatIdentityData.chatUserToken = azureAccessDetails.data.chatUserToken;
                chatIdentityData.chatUserId = azureAccessDetails.data.chatUserId;
                await updateUserForAzureChatDetails(chatIdentityData);

                context.log("Successfully refreshed new chat token for user:", userId);
                return chatIdentityData;
            } else {
                context.log("Error while refreshing chat token for user:", userId, " Details:", azureAccessDetails);
                throw createError[500]("Error in refreshing the chat token");
            }
        } else {
            return chatIdentityData;
        }
    } else {
        const azureAccessDetailsNew = await azureApi.generateIdentityToken();

        if (azureAccessDetailsNew.data.chatUserToken !== "") {
            chatIdentityData.chatUserToken = azureAccessDetailsNew.data.chatUserToken;
            chatIdentityData.chatUserId = azureAccessDetailsNew.data.chatUserId;

            await updateUserForAzureChatDetails(chatIdentityData);
            context.log("Successfully generated new chat token for user:", userId);
            return chatIdentityData;
        } else {
            context.log("Error while generating chat token for user:", userId, " Details:", azureAccessDetailsNew);
            throw createError[500]("Error in token generation");
        }
    }
}

export async function getChatThreadId(context, chatIdentityObj) {
    const chatHistoryData = await ChatHistory.findOne({
        where: {
            [Op.or]: [
                { participant1UserId: chatIdentityObj.participant1.userId, participant2UserId: chatIdentityObj.participant2.userId },
                { participant1UserId: chatIdentityObj.participant2.userId, participant2UserId: chatIdentityObj.participant1.userId }]
        }
    });

    if (chatHistoryData && chatHistoryData.threadId) {
        return chatHistoryData.threadId;
    } else {
        let threadResp = await azureApi.createThread(chatIdentityObj);
        if (threadResp.statusCode = StatusCodes.OK) {
            const threadId = threadResp.data;
            const chatHistoryPayload = {
                participant1UserId: chatIdentityObj.participant1.userId,
                participant2UserId: chatIdentityObj.participant2.userId,
                threadId
            }
            await ChatHistory.create(chatHistoryPayload);
            context.log("Created chat thread successfully for : ", chatHistoryPayload.participant1UserId, " and ", chatHistoryPayload.participant2UserId);
            return threadId;
        }
        else {
            context.log("Error while creating chat thread for : ", chatIdentityObj, " Details: ", threadResp);
            throw createError[500]("Error in chat thread creation.");
        }
    }
}

async function updateUserForAzureChatDetails(chatIdentityData) {
    const datetime = moment().utc().format(rules.DATE_TIME_FORMAT);
    const expires_in = 86400; //24 Hours

    return await User.update({
        chatUserId: chatIdentityData.chatUserId
        , chatUserToken: chatIdentityData.chatUserToken
        , chatUserTokenUpdatedAt: datetime
        , chatUserTokenExpireAt: expires_in
    }, { where: { id: chatIdentityData.userId } });
}

export async function getChatHistory(context, userId) {
    try {
        let participantsData = [], chatUsers = {};
        const aphrodite = await getChatBotHistory(userId);
        const chatParticipantList = await sequelize.query(`select CASE when ("participant1UserId" = '${userId}') then "participant2UserId" 
          else "participant1UserId" end as "participantUserId", "threadId", "lastMsg", "lastMsgAt", "conversationId", watermark, "createdAt" from "chatHistory"
          WHERE "participant1UserId" = '${userId}' or "participant2UserId" = '${userId}' order by "lastMsgAt" desc`, { type: QueryTypes.SELECT });
          
        if (chatParticipantList.length > 0) {
            await Promise.all(chatParticipantList.map(async (participant) => {
                let partcipantDetails = await getUserDetailsForChatHistory(participant.participantUserId, true);
                if(partcipantDetails.userStatus != 'inactive' && partcipantDetails.userStatus != 'delete'){
                    partcipantDetails.threadId = participant.threadId;
                    partcipantDetails.lastMsg = participant.lastMsg;
                    partcipantDetails.lastMsgAt = participant.lastMsgAt;
                    partcipantDetails.conversationId = participant.conversationId;
                    partcipantDetails.watermark = participant.watermark;
                    partcipantDetails.createdAt = participant.createdAt;
                    participantsData.push(partcipantDetails);
                }
            }));
            const sortedParticipantsData = participantsData.sort((p1, p2) => p2.lastMsgAt - p1.lastMsgAt);

            // Move chatbot record at first of the list
            const index = sortedParticipantsData.findIndex(obj => obj.threadId == 'CHATBOT');
            // Check if the object exists in the array
            if (index !== -1) {
                // Remove the object from its current position
                const removedChatBotObject = sortedParticipantsData.splice(index, 1)[0];

                // Add the removed object to the first position
                sortedParticipantsData.unshift(removedChatBotObject);
            }


            chatUsers.loggedInUser = await getUserDetailsForChatHistory(userId, true);
            chatUsers.partnerUsers = sortedParticipantsData;
        }
        context.log(`Chat history fetched successfully for UserId: ${userId}`);
        return chatUsers;
    } catch (err) {
        
        context.log(`Error while getting chat history for UserId: ${userId}. Details: ${err}`);
        throw createError[500]("Error while getting chat history");
    }
}

export async function getUserDetailsForChatHistory(userId, firstNameOnly = false) {
    const userDetailsForChat = await sequelize.query(`SELECT pa."imageUrl", pa."imageName", "firstName", "lastName", "chatUserId", 
    "chatUserToken", "profileCompleted", "userStatus" FROM users u LEFT JOIN "photoAlbum" pa ON u.id = pa."userId" where u.id = '${userId}';`, { type: QueryTypes.SELECT });
    
    if (userDetailsForChat.length > 0) {
        return {
            userId,
            chatUserToken: userDetailsForChat[0].chatUserToken,
            chatUserId: userDetailsForChat[0].chatUserId,
            userName: firstNameOnly ? userDetailsForChat[0].firstName : userDetailsForChat[0].firstName + " " + userDetailsForChat[0].lastName,
            profileImage: userDetailsForChat[0].imageUrl,
            imageName: userDetailsForChat[0].imageName,
            profileCompleted: userDetailsForChat[0].profileCompleted,
            userStatus: userDetailsForChat[0].userStatus
        }
    } else {
        throw createError[500]("Error while getting user details for chat history");
    }
}

export async function updateChatHistory(data, context, loggedInUser) {
    if (data.conversationId) {
        const recordExists = await ChatHistory.findOne({
            where: {
                [Op.or]: [
                    { participant1UserId: data.participant1UserId, threadId: 'CHATBOT' },
                    { participant2UserId: data.participant1UserId, threadId: 'CHATBOT' }]
            }
        });
        if (recordExists) {
            return await ChatHistory.update({ conversationId: data.conversationId, watermark: data.watermark }, {
                where: {
                    [Op.or]: [
                        { participant1UserId: data.participant1UserId, threadId: 'CHATBOT' },
                        { participant2UserId: data.participant1UserId, threadId: 'CHATBOT' }]
                }
            });
        } else {
            const chatbotUser = await User.findOne({ where: { userStatus: 'Aphrodite_chatbot' } });
            const chatHistoryInsertPayload = {
                participant1UserId: data.participant1UserId,
                participant2UserId: chatbotUser.id,
                threadId: 'CHATBOT',
                conversationId: data.conversationId,
                watermark: data.watermark
            }
            return await ChatHistory.create(chatHistoryInsertPayload);
        }
    } else {
        const chatHistory = await ChatHistory.findOne({
            where: {
                [Op.or]: [
                    { participant1UserId: data.participant1UserId, participant2UserId: data.participant2UserId },
                    { participant1UserId: data.participant2UserId, participant2UserId: data.participant1UserId }]
            }
        });

        // for first msg only send notification
        if (chatHistory && !chatHistory.lastMsg && data.lastMsg) {
            const partnerUserId = loggedInUser.id == data.participant1UserId ? data.participant2UserId : data.participant1UserId;
            // get partner user details
            const partnerDetails = await User.findOne({ where: { id: partnerUserId } });
            let userDetails = { screen: 'chat', partnerUserId: partnerUserId };

            const pushMotificationBody = {
                fcmDeviceToken: partnerDetails.fcmDeviceToken,
                userDetails,
                title: messages.chatPNTitle,
                body: messages.chatPNMsg.replace('{{userName}}', loggedInUser.firstName)
            };
            sendPushNotification(context, pushMotificationBody);

            //send sms
            let sendSMSObj = {
                to: process.env["COUNTRY_CODE"] + partnerDetails.phone,
                body: messages.chatTxtMsg.replace('{{userName}}', loggedInUser.firstName)
            }
            clickSend.SendSMS(context, sendSMSObj);
        }
        return await ChatHistory.update({ lastMsg: data.lastMsg, lastMsgAt: data.lastMsgAt },
            {
                where: {
                    [Op.or]: [
                        { participant1UserId: data.participant1UserId, participant2UserId: data.participant2UserId },
                        { participant1UserId: data.participant2UserId, participant2UserId: data.participant1UserId }]
                }
            });
    }
}

export async function getChatBotHistory(userId) {
    let aphrodite = {};
    aphrodite = await ChatHistory.findOne({
        where: {
            [Op.or]: [
                { participant1UserId: userId, threadId: 'CHATBOT' },
                { participant2UserId: userId, threadId: 'CHATBOT' }]
        }
    });

    if (!aphrodite) {
        const chatbotUser = await User.findOne({ where: { userStatus: 'Aphrodite_chatbot' } });
        const chatHistoryInsertPayload = {
            participant1UserId: userId,
            participant2UserId: chatbotUser.id,
            threadId: 'CHATBOT'
        }
        aphrodite = await ChatHistory.create(chatHistoryInsertPayload);
    }
    return aphrodite;
}
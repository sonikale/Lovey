import sequelize from "../db/db.connect.js";
import { getMatchDateSchedule } from './matchDateSchedule.js';
import { getMyFeedback, getPartnerFeedback } from './common.util.js';
import servedMatches from '../models/matches.model.js';
import generateMatches from '../models/generateMatches.model.js';
import { Op, QueryTypes } from 'sequelize';
import { getUserProfile } from "./common.util.js";
import * as stripe from '../utils/stripe/stripe.js';
import stripeCustomerModel from '../models/stripeCustomer.model.js';
import { verifyPurchaseWithApple } from '../utils/getInPurchaseReceipt.js';

async function getMatches(context, loggedInUser) {
    // To do: servedMatches -> subscription active ->  pick 3 /5  pick records with opposite gender with limit order by createdAt desc where user id = logged 


    // TO DO: when moving generatedMatches to servedMatches - use filter highest percentage, how many miles,
    // servedMatches- sep - 3 
    // servedMatches - oct - 3
    // servedMatches - nov - 3


    //Get user gender and on the basis of gender add condition 
    // TO DO: uncomment below lines once rule engine completes- not tested written by shubham
    // let checkUser = await sequelize.query(`select gender from "users" where "id"='${loggedInUserId}'`)
    // if (checkUser[0].gender === "Female" && myMatchesDetails.length >= 5) {
    //     myMatchesDetails.push(match);
    // } else if (checkUser[0].gender === "Male" && myMatchesDetails.length >= 3) {
    //     myMatchesDetails.push(match);
    // }
    //we are using calculated matches key flag for handle loader
    const stripeCustomer = await stripeCustomerModel.findOne({ where: { userId: loggedInUser.id } });
    //self data pass in customer id
    //dataValues.customerId

    let productInfo = '';
    let userSubscription = '';
    if (stripeCustomer) {
        productInfo = await stripe.getProductInfoByActiveSubscription(context, stripeCustomer.dataValues.customerId);
        userSubscription = await stripe.getSubscriptionInfo(context, stripeCustomer.dataValues.customerId)

    }
    // const date = new Date(userSubscription.subscription.created * 1000);
    // Format the date in the desired format
    // const formattedDate = date.toISOString().replace('T', ' ').replace('Z', '');
    let matchData;
    let count;
    if (loggedInUser.gender == "Male") {
        if (productInfo.name === 'Basic Subscription' || productInfo.name === 'Daily Subscription Plan for Testing'
        ) {
            count = 3
        } else {
            count = 5
        }
        let matchQueryFromServe = await sequelize.query(`select * from "servedMatches" where "userId"='${loggedInUser.id}' and "matchPercentage"!='undefined' and "matchPercentage"!='0' order by  "matchPercentage" desc limit ${count};`, { type: QueryTypes.SELECT })
        matchData = matchQueryFromServe
    } else {
        //- Women get matches based on highest matched percentages (pick 3 out ot 5) etc.
        if (productInfo.name === 'Basic Subscription' || productInfo.name === 'Daily Subscription Plan for Testing') {
            count = 5
        } else {
            count = 10
        }
        console.log("count in else block ", count)
        let matchQueryFromServe = await sequelize.query(`select * from "servedMatches" where "userId"='${loggedInUser.id}' and "matchPercentage"!='0'  order by  "matchPercentage" desc limit ${count};`, { type: QueryTypes.SELECT })
        if (count == 10 && matchQueryFromServe.length <= 10) {
            let matchQuery = await sequelize.query(`select * from "generatedMatches" where "userId"='${loggedInUser.id}' and "matchPercentage"!='0'  order by  "matchPercentage" desc limit ${count};`, { type: QueryTypes.SELECT });
            if (matchQuery && matchQuery.length) {
                await insertMatches(matchQuery, loggedInUser);
            }
            matchData = matchQuery
        }
        if (matchQueryFromServe.length) {
            matchData = matchQueryFromServe
        } else {
            let matchQuery = await sequelize.query(`select * from "generatedMatches" where "userId"='${loggedInUser.id}' and "matchPercentage"!='0'  order by  "matchPercentage" desc limit ${count};`, { type: QueryTypes.SELECT });
            if (matchQuery && matchQuery.length) {
                await insertMatches(matchQuery, loggedInUser);
            }
            matchData = matchQuery
        }
        //- Men get only 3 that month. Once they get three matches they will not appear as options for other women until next month. 


        //delete existing entry for serve table of logged in user
        // let deleteMatchData = await sequelize.query(`DELETE FROM "servedMatches" WHERE "userId"='${loggedInUser.id}'`, { type: QueryTypes.DELETE })

        //AND "createdAt" >= '${formattedDate}'
        //check subscription start date and end date male only 
        //match meta data(selectFeMale) count with the accepted count
        //fetch how many have accepted this male in date range of subscription start and end date
        //if ias accepted count is less than meta count then add user 
    }

    return matchData;
}

async function insertMatches(matchQuery, loggedInUser) {
    Promise.all(matchQuery && matchQuery.length && matchQuery.map(async item => {
        let percent
        if (item.matchPercentage === null || item.matchPercentage === undefined) {
            percent = 0
        } else {
            percent = item.matchPercentage
            const inputTimeString = item.createdAt;

            // Create a Date object from the input string
            const inputDate = new Date(inputTimeString);

            // Extract individual components of the date
            const year = inputDate.getFullYear();
            const month = String(inputDate.getMonth() + 1).padStart(2, '0'); // Months are zero-based
            const day = String(inputDate.getDate()).padStart(2, '0');
            const hours = String(inputDate.getHours()).padStart(2, '0');
            const minutes = String(inputDate.getMinutes()).padStart(2, '0');
            const seconds = String(inputDate.getSeconds()).padStart(2, '0');
            const milliseconds = String(inputDate.getMilliseconds()).padStart(3, '0');

            // Construct the desired output format
            const outputTimeString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
            let checkDataExist = await sequelize.query(`select * from "servedMatches" where "userId"='${loggedInUser.id}' and "partnerUserId"='${item.partnerUserId}'`, { type: QueryTypes.SELECT })
            if (checkDataExist.length == 0) {
                const saveServeData = await sequelize.query(`Insert into "servedMatches" ("userId","partnerUserId","matchPercentage","matchStatus","createdAt") VALUES ('${loggedInUser.id}','${item.partnerUserId}','${percent}','Pending','${outputTimeString}')`, { type: QueryTypes.INSERT });
            }
        }
    }));
}

async function getMyMatches(context, loggedInUser) {
    let myMatchesDetails = [];
    const matcheslist = await getMatches(context, loggedInUser);
    const stripeCustomer = await stripeCustomerModel.findOne({ where: { userId: loggedInUser.id } });
    let productInfo = '';
    if (stripeCustomer) {
        productInfo = await stripe.getProductInfoByActiveSubscription(context, stripeCustomer.dataValues.customerId);
    } else {
        if (loggedInUser && loggedInUser.id) {
            let iosdata = await sequelize.query(`SELECT "userId","receipt" FROM "appleReceipt" where "userId" = '${loggedInUser.id}';`, { type: QueryTypes.SELECT });
            console.log('isodata', iosdata)
            if (iosdata && iosdata.length > 0) {
                let getReceiptData = await verifyPurchaseWithApple(iosdata[0].receipt, loggedInUser.id, 'ios');
                productInfo = getReceiptData.latest_receipt_info.length > 0 ? getReceiptData.latest_receipt_info[0] : '';
            }
        }
    }
    // to do : this logic will change after rule engine builds
    const calculateMatch = await sequelize.query(`select "calculatedMatches" from users where id='${loggedInUser.id}'`, { type: QueryTypes.SELECT })
    let uniqueMatchList = matcheslist && matcheslist.length && matcheslist.filter((obj, index, array) => {
        // Check if there is no previous object with the same matchId and partnerUserId
        return (
            array.findIndex(
                (item) =>
                    item.partnerUserId === obj.partnerUserId && item.userId === obj.userId
            ) === index
        );
    });
    if (uniqueMatchList && uniqueMatchList.length) {
        await Promise.all(uniqueMatchList.map(async partner => {
            let user = await getUserProfile(partner.partnerUserId);
            let dateSchedule = await getMatchDateSchedule(loggedInUser.id, partner.partnerUserId);
            // TO DO: Update match percentage once Rule engine builds
            let givenFeedback = await getMyFeedback('given', loggedInUser.id, partner.partnerUserId);
            let partnerFeedbackRes = await getPartnerFeedback(partner.partnerUserId, loggedInUser.id);
            let match = { partnerStatus: partner.partnerStatus ? partner.partnerStatus : "Pending", matchStatus: partner.matchStatus, matchPercent: partner.matchPercentage, userDetails: user, dateSchedule, givenFeedback, partnerFeedback: partnerFeedbackRes[0] ?? {}, matchId: partner.id, partnerUserId: partner.partnerUserId, userId: loggedInUser.id };
            myMatchesDetails.push(match);

        }));
    }

    let resultObj = {
        productInfo: productInfo,
        calculatedMatches: calculateMatch[0].calculatedMatches,
        data: myMatchesDetails

    }
    return resultObj;
}

async function postMatchAcceptDeclineStatus(data) {
    let checkGender = await sequelize.query(`select gender from users where id='${data.userId}'`, { type: QueryTypes.SELECT })
    let partnerStatusValue = "Pending"
    let checkSelfStatus = await sequelize.query(`select "matchStatus",id,"matchPercentage" from "servedMatches" where "userId"='${data.userId}' and "partnerUserId"='${data.partnerUserId}'`, { type: QueryTypes.SELECT })
    console.log("checkSelfStatus", checkSelfStatus)
    if (checkGender[0].gender === "Female" && data.status == "accept") {
        const saveServeData = await sequelize.query(`Insert into "servedMatches" ("userId","partnerUserId","matchStatus","partnerStatus","createdAt","matchPercentage") VALUES ('${data.partnerUserId}','${data.userId}','Pending','${data.status}',current_timestamp,'${checkSelfStatus[0].matchPercentage}')`, { type: QueryTypes.INSERT });
    }

    let checkPartnerStatus = await sequelize.query(`select "matchStatus",id from "servedMatches" where "userId"='${data.partnerUserId}' and "partnerUserId"='${data.userId}'`, { type: QueryTypes.SELECT })
    console.log("checkPartnerStatus", checkPartnerStatus)
    if (checkPartnerStatus && checkPartnerStatus.length && checkPartnerStatus[0].matchStatus) {
        partnerStatusValue = checkPartnerStatus[0].matchStatus
    }

    let updateServeStatusSelfQuery = `UPDATE "servedMatches" SET "matchStatus"='${data.status}',reason='${data.reason}',"partnerStatus"='${partnerStatusValue}' where "partnerUserId"= '${data.partnerUserId}' and "userId"= '${data.userId}'`;
    let updateServeStatusOtherQuery = `UPDATE "servedMatches" SET "matchStatus"='${partnerStatusValue}',"partnerStatus"='${data.status}' where "partnerUserId"= '${data.userId}' and "userId"= '${data.partnerUserId}'`
    if (data.status == "accept") {
        await sequelize.query(`${updateServeStatusSelfQuery} and id='${checkSelfStatus[0].id}' ;`, { type: QueryTypes.UPDATE });
        await sequelize.query(`${updateServeStatusOtherQuery} and id='${checkPartnerStatus[0].id}' ;`, { type: QueryTypes.UPDATE });
        return await sequelize.query(`UPDATE "generatedMatches" SET "matchStatus"='${data.status}',reason='${data.reason}',"partnerStatus"='${partnerStatusValue}' where "partnerUserId"= '${data.partnerUserId}' and "userId"= '${data.userId}' ;`, { type: QueryTypes.UPDATE });
    } else {
        await sequelize.query(`${updateServeStatusSelfQuery} ;`, { type: QueryTypes.UPDATE });
        await sequelize.query(`${updateServeStatusOtherQuery} ;`, { type: QueryTypes.UPDATE });
        return await sequelize.query(`UPDATE "generatedMatches" SET "matchStatus"='${data.status}',reason='${data.reason}',"partnerStatus"='reject' where "partnerUserId"= '${data.partnerUserId}' and "userId"= '${data.userId}' ;`, { type: QueryTypes.UPDATE });
    }

}
export { getMyMatches, postMatchAcceptDeclineStatus }
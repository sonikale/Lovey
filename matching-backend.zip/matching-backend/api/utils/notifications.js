import Notifications from '../models/notifications.model.js';

async function getNotifications(userId, notificationType) {
    return await Notifications.findAll({
        where: { toUserId: userId, notificationType: notificationType },
        order: [['createdAt', 'DESC']]
    });
}

async function updateNotificationReadFlag(notificationId) {
    return await Notifications.update({ isRead: true }, { where: { id: notificationId } })
}

async function createInAppNotification(data) {
    const insertPayload = {
        fromUserId: data.fromUserId,
        toUserId: data.toUserId,
        isRead: false,
        notificationType: 'InApp',
        notificationTitle: data.notificationTitle,
        notificationText: data.notificationText
    }
    return await Notifications.create(insertPayload);
}

async function deleteNotifications(userId, notificationType, notificationId) {
    let searchCriteria = { toUserId: userId, notificationType: notificationType };
    if (notificationId) {
        searchCriteria.id = notificationId;
    }
    return await Notifications.destroy({ where: searchCriteria });
}

export { getNotifications, updateNotificationReadFlag, createInAppNotification, deleteNotifications }
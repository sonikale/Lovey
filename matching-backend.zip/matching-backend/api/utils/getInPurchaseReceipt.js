import axois from "axios";
import sequelize from "../db/db.connect.js";
import { Op, QueryTypes } from 'sequelize';

// Function to verify the purchase with the Apple App Store Receipt Validation API
async function verifyPurchaseWithApple(receiptData, userId, deviceType) {
    const url = process.env['APPLE_SANDBOX_URL'];

    const requestData = {
        "receipt-data": receiptData,
        "password": process.env['APPLE_SHARED_SECRET'],
        "exclude-old-transactions": true

    };
    try {
        const result = await axois.post(url, requestData);
        if (receiptData && userId) {
            if (deviceType === 'ios') {
                // let updatereceipt = `UPDATE "appleReceipt" SET "receipt"='${receiptData}' where "userId"= '${userId}'`;
                let updateCount = await sequelize.query(`UPDATE "appleReceipt" SET "receipt"='${receiptData}' where "userId"= '${userId}'`, { type: QueryTypes.UPDATE });
            } else {
                const insertreceipt = await sequelize.query(`Insert into "appleReceipt" ("userId","receipt") VALUES ('${userId}','${receiptData}')`, { type: QueryTypes.INSERT });
            }
        }
        return result.data
    } catch (error) {
        // Handle error (e.g., network error, invalid response)
        console.error('Error verifying purchase with Apple:', error);
        return {};
    }
}

export { verifyPurchaseWithApple }
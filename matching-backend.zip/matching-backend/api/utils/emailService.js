import { EmailClient } from '@azure/communication-email';
import { StatusCodes } from 'http-status-codes';
import { successResponse, errorResponse } from '../core/responseApi.js';

export async function sendMail(context, emailObj) {
  const connectionString = process.env['AZURE_COMMUNICATION_CONNECTION_STRING'];
  const emailClient = new EmailClient(connectionString);
  const POLLER_WAIT_TIME = 10;

  try {
    const message = {
      senderAddress: process.env['AZURE_SENDER_ADDRESS'],
      content: {
        subject: emailObj.subject,
        plainText: emailObj.mailBody
      },
      recipients: {
        to: [
          {
            address: emailObj.toEmail,
            displayName: emailObj.toName || emailObj.toEmail
          },
        ],
      },
    };

    const poller = await emailClient.beginSend(message);

    if (!poller.getOperationState().isStarted) {
      context.log("Poller was not started.")
      return errorResponse("Poller was not started.", StatusCodes.BAD_REQUEST);
    }

    let timeElapsed = 0;
    while (!poller.isDone()) {
      poller.poll();
      context.log("Email send polling in progress");

      await new Promise(resolve => setTimeout(resolve, POLLER_WAIT_TIME * 1000));
      timeElapsed += 10;

      if (timeElapsed > 18 * POLLER_WAIT_TIME) {
        context.log("Polling timed out.");
        return errorResponse("Timed out. Please try again", StatusCodes.BAD_REQUEST);
      }
    }

    if (poller.getResult().status === "Succeeded") {
      context.log(`Successfully sent the email (operation id: ${poller.getResult().id})`);
      return successResponse("Successfully sent the email", `${poller.getResult().id}`, StatusCodes.OK)
    } else {
      return errorResponse(poller.getResult().error, StatusCodes.BAD_REQUEST);
    }
  } catch (e) {
    context.log(`Error while sending email to ${emailObj.toEmail}. Details: ${e}`);
    return errorResponse(`Error while sending email to ${emailObj.toEmail}`, StatusCodes.BAD_REQUEST);
  }
}

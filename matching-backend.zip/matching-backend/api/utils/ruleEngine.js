import sequelize from "../db/db.connect.js";
import { QueryTypes } from 'sequelize';
import { chatbotQuestionIds, personalityAssessmentLogic } from "../core/constants.js";
import { calculateAge } from "./common.util.js";
import stripeCustomerModel from '../models/stripeCustomer.model.js';
import * as stripe from '../utils/stripe/stripe.js';

async function findLoveLanguage(context, userId) {
    try {
        const combinedQuery = await sequelize.query(`SELECT * FROM "option" WHERE "id" IN (SELECT "optionid" FROM "questionOptionMapping"
            WHERE "questionid" IN (
                SELECT "id"
                FROM "question"
                WHERE "section" = 'Love Language' and "answertype" != 'info'
            ));`, { type: QueryTypes.SELECT });

        const idsByCategory = {};
        // Iterate through the data array and populate the idsByCategory object
        combinedQuery.forEach(item => {
            const { id, categories } = item;
            if (!idsByCategory[categories]) {
                idsByCategory[categories] = [];
            }
            idsByCategory[categories].push(id);
        });
        const togethernessArray = idsByCategory['Togetherness']
        const verbalArray = idsByCategory['Verbal Affirmation']
        const physicalArray = idsByCategory['Physical Intimacy']
        const PresentsArray = idsByCategory['Presents']
        const serviceArray = idsByCategory['Acts of service']

        const togetherQuery = await sequelize.query(`
            SELECT COUNT(*) AS count
            FROM "answer"
            WHERE "userId" = '${userId}' 
            AND "questionId" IN (
            SELECT "id"
            FROM "question"
            WHERE "section" = 'Love Language' 
            AND "optionId" IN (${togethernessArray.map(id => `'${id}'`).join(',')})
            );`, { type: QueryTypes.SELECT });

        const verbalQuery = await sequelize.query(`
            SELECT COUNT(*) AS count
            FROM "answer"
            WHERE "userId" = '${userId}' 
            AND "questionId" IN (
            SELECT "id"
            FROM "question"
            WHERE "section" = 'Love Language' 
            AND "optionId" IN (${verbalArray.map(id => `'${id}'`).join(',')})
            );`, { type: QueryTypes.SELECT });

        const physicalQuery = await sequelize.query(`
            SELECT COUNT(*) AS count
            FROM "answer"
            WHERE "userId" = '${userId}' 
            AND "questionId" IN (
            SELECT "id"
            FROM "question"
            WHERE "section" = 'Love Language' 
            AND "optionId" IN (${physicalArray.map(id => `'${id}'`).join(',')})
            );
            `, { type: QueryTypes.SELECT });

        const presentQuery = await sequelize.query(`
            SELECT COUNT(*) AS count
            FROM "answer"
            WHERE "userId" = '${userId}' 
            AND "questionId" IN (
            SELECT "id"
            FROM "question"
            WHERE "section" = 'Love Language' 
            AND "optionId" IN (${PresentsArray.map(id => `'${id}'`).join(',')})
            );
            `, { type: QueryTypes.SELECT });

        const serviceQuery = await sequelize.query(`
            SELECT COUNT(*) AS count
            FROM "answer"
            WHERE "userId" = '${userId}' 
            AND "questionId" IN (
            SELECT "id"
            FROM "question"
            WHERE "section" = 'Love Language' 
            AND "optionId" IN (${serviceArray.map(id => `'${id}'`).join(',')})
            );
            `, { type: QueryTypes.SELECT });

        // Now, you have a separate array of IDs for each category
        let obj = {
            'Togetherness': togetherQuery,
            'VerbalAffirmation': verbalQuery,
            'PhysicalIntimacy': physicalQuery,
            'Presents': presentQuery,
            'ActsOfService': serviceQuery
        }

        let maxKeys = [];
        let maxCount = -1;

        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                const count = parseInt(obj[key][0].count);

                if (count > maxCount) {
                    maxCount = count;
                    maxKeys = [key];
                } else if (count === maxCount) {
                    maxKeys.push(key);
                }
            }
        }
        let resultString = maxKeys.join(', ');
        const updateCount = await sequelize.query(`UPDATE users SET "loveLanguage" = '${resultString}', "updatedAt"=current_timestamp  WHERE "id" = '${userId}'`, { type: QueryTypes.UPDATE });
        context.log(`Love language calculated Successfully for user: ${userId}. resultString: ${resultString}`);
    } catch (error) {
        context.log(`Error while calculating love language for user: ${userId}. Details: ${error}`);
    }
}


async function findAttachmentStyle(context, userId) {
    try {
        let optionTrueId = '763d5ab8-2eb4-43ba-a679-63e4db39ebc5';
        const anxiousQuery = await sequelize.query(`SELECT COUNT(*) AS count FROM answer 
            WHERE "userId"='${userId}' 
            AND "questionId" IN (SELECT id FROM question WHERE "sectionresulttype"='Anxious')
            AND "optionId"='${optionTrueId}'`, { type: QueryTypes.SELECT });

        const secureQuery = await sequelize.query(`SELECT COUNT(*) AS count FROM answer
            WHERE "userId"='${userId}' 
            AND "questionId" IN (SELECT id FROM question WHERE "sectionresulttype"='Secure')
            AND "optionId"='${optionTrueId}'`, { type: QueryTypes.SELECT });

        const avoidantQuery = await sequelize.query(`SELECT COUNT(*) AS count FROM answer
            WHERE "userId"='${userId}' 
            AND "questionId" IN (SELECT id FROM question WHERE "sectionresulttype"='Avoidant')
            AND "optionId"='${optionTrueId}'`, { type: QueryTypes.SELECT });

        let obj = {
            Anxious: anxiousQuery,
            Secure: secureQuery,
            Avoidant: avoidantQuery
        }
        let maxKeys = [];
        let maxCount = -1;

        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                const count = parseInt(obj[key][0].count);

                if (count > maxCount) {
                    maxCount = count;
                    maxKeys = [key];
                } else if (count === maxCount) {
                    maxKeys.push(key);
                }
            }
        }
        let resultString = maxKeys.join(', ');

        const updateCount = await sequelize.query(`UPDATE users SET "attachmentStyle" = '${resultString}', "updatedAt"=current_timestamp  WHERE "id" = '${userId}'`, { type: QueryTypes.UPDATE });
        context.log(`Attachment Style calculated Successfully for user: ${userId}, resultString: ${resultString}`);
    } catch (error) {
        context.log(`Error while calculating attachment style for user: ${userId}. Details: ${error}`);
    }
}

async function calculatePersonalityAssessmentScore(context, userId) {
    try {
        const getQuestionData = await sequelize.query(`select * from answer where "userId"='${userId}'`, { type: QueryTypes.SELECT })
        let extraversionCount = 0
        let agreeablenessCount = 0
        let conscientiousnessCount = 0
        let emotionalCount = 0
        let imaginationCount = 0
        let personalityAssessmentData = personalityAssessmentLogic;

        getQuestionData.map(item => {
            personalityAssessmentData.map(newItem => {
                if ((item.questionId).toString() === newItem.id) {
                    if (newItem.optionScoringScale[item.optionId] !== undefined) {
                        let value = newItem.optionScoringScale[item.optionId];
                        if (newItem.category == "Intellect/Imagination") {
                            imaginationCount = imaginationCount + value;
                        }
                        if (newItem.category == "Emotional Stability") {
                            emotionalCount = emotionalCount + value;
                        }
                        if (newItem.category == "Conscientiousness") {
                            conscientiousnessCount = conscientiousnessCount + value;
                        }
                        if (newItem.category == "Agreeableness") {
                            agreeablenessCount = agreeablenessCount + value;
                        }
                        if (newItem.category == "Extraversion") {
                            extraversionCount = extraversionCount + value;
                        }
                    }
                }
            });
        });

        let obj = {
            Extraversion: extraversionCount,
            Agreeableness: agreeablenessCount,
            Conscientiousness: conscientiousnessCount,
            EmotionalStability: emotionalCount,
            Imagination: imaginationCount
        }

        const insertCountRecord = await sequelize.query(`Insert into "personalityAssessmentScore" ("extraVersion","agreeAbleness","conscientiousness","emotionalStability","imagination","userId","createdAt","updatedAt") VALUES ('${obj.Extraversion}','${obj.Agreeableness}','${obj.Conscientiousness}','${obj.EmotionalStability}','${obj.Imagination}','${userId}',current_timestamp,current_timestamp)`, { type: QueryTypes.INSERT });
        context.log(`Personality Assessment score calculated Successfully for user: ${userId}, score: ${obj}`);
    } catch (error) {
        context.log(`Error while calculating personality Assessment score for user: ${userId}. Details: ${error}`);
    }
}

//get how many miles calculate on the basis of lat long
async function calculateDistanceInMiles(lat1, lon1, lat2, lon2) {
    // Convert latitude and longitude from degrees to radians
    const radlat1 = Math.PI * lat1 / 180;
    const radlon1 = Math.PI * lon1 / 180;
    const radlat2 = Math.PI * lat2 / 180;
    const radlon2 = Math.PI * lon2 / 180;

    // Radius of the Earth in miles
    const R = 3959; // Earth's radius in miles

    // Haversine formula
    const dlat = radlat2 - radlat1;
    const dlon = radlon2 - radlon1;
    const a = Math.sin(dlat / 2) * Math.sin(dlat / 2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.sin(dlon / 2) * Math.sin(dlon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in miles

    return distance;
}

//function for get percentage of attachment style
async function calculateAttachmentStylePercentage(userAAttachmentStyle, userBAttachmentStyle) {
    //comparingWith will have whom we are comparing with user A to B     OR     B to A
    let cases = {
        'Secure,Secure': 100,
        'Secure,Anxious': 80,
        'Secure,Avoidant': 0,
        'Anxious,Anxious': 100,
        'Anxious,Secure': 80,
        'Anxious,Avoidant': 0,
        'Avoidant,Avoidant': 100,
        'Avoidant,Secure': 80,
        'Avoidant,Anxious': 0
    }
    let combinations = []
    if (userAAttachmentStyle && userBAttachmentStyle) {
        combinations = generateCombinations(userAAttachmentStyle.split(','), userBAttachmentStyle.split(','));
    }

    // find greatest percentage using combination array 
    let result = 0
    combinations && combinations.length && combinations.map(item => {
        let percentage = cases[`${item}`];
        if (percentage >= result) {
            return result = percentage
        }
    })

    if (result === undefined || result == 0) {
        return 0;
    } else {
        let percentageEarned = (result / 100) * 15 //(percentage / 100) * percent allocated; // here out of 20 is what we are going to finally represent it as
        return Math.round(percentageEarned)
    }
}

//function for get love language percentage
async function calculateLoveLanguagePercentage(userALoveLang, userBLoveLang) {
    console.log(userALoveLang, userBLoveLang)
    //comparingWith will have whom we are comparing with user A to B     OR     B to A
    let cases = {
        'Togetherness,VerbalAffirmation': 0,
        'Togetherness,PhysicalIntimacy': 40,
        'Togetherness,Presents': 0,
        'Togetherness,ActsOfService': 80,
        'Togetherness,Togetherness': 100,

        //=====================
        'VerbalAffirmation,VerbalAffirmation': 100,
        'VerbalAffirmation,PhysicalIntimacy': 0,
        'VerbalAffirmation,Presents': 40,
        'VerbalAffirmation,ActsOfService': 80,
        'VerbalAffirmation,Togetherness': 80,

        //=======================
        'PhysicalIntimacy,VerbalAffirmation': 0,
        'PhysicalIntimacy,PhysicalIntimacy': 100,
        'PhysicalIntimacy,Presents': 0,
        'PhysicalIntimacy,ActsOfService': 0,
        'PhysicalIntimacy,Togetherness': 40,

        //=====================
        'Presents,VerbalAffirmation': 0,
        'Presents,PhysicalIntimacy': 0,
        'Presents,Presents': 100,
        'Presents,ActsOfService': 80,
        'Presents,Togetherness': 0,

        //=====================
        'ActsOfService,VerbalAffirmation': 0,
        'ActsOfService,PhysicalIntimacy': 80,
        'ActsOfService,Presents': 40,
        'ActsOfService,ActsOfService': 100,
        'ActsOfService,Togetherness': 80,
    }

    let combinations = []
    if (userALoveLang && userBLoveLang) {
        combinations = generateCombinations(userALoveLang.split(','), userBLoveLang.split(','));
    }

    // find greatest percentage using combination array 
    let result = 0
    combinations && combinations.length && combinations.map(item => {
        let percentage = cases[`${item}`];
        if (percentage >= result) {
            return result = percentage
        }
    })

    if (result === undefined || result == 0) {
        return 0;
    } else {
        let percentageEarned = (result / 100) * 20 //(percentage / 100) * percent allocated; // here out of 20 is what we are going to finally represent it as
        return Math.round(percentageEarned)
    }
}
function calculateQualitiesPercentage(userA_qualities, userB_qualities, numberOfQues, percent) {
    function matchingAnswers(userA_qualities, userB_qualities) {
        let splitDataA
        let splitDataB
        if (userA_qualities.includes(',')) {
            splitDataA = userA_qualities.split(',')
        } else {
            splitDataA = [userA_qualities]
        }
        if (userB_qualities.includes(',')) {
            splitDataB = userB_qualities.split(',')
        } else {
            splitDataB = [userB_qualities]
        }
        const set = new Set(splitDataA);
        let commonCount = 0;
        for (let i = 0; i < splitDataB.length; i++) {
            if (set.has(splitDataB[i])) {
                commonCount++;
            }
        }
        return commonCount;
    }
    let sameAnswers = matchingAnswers(userA_qualities, userB_qualities)
    console.log("sameAnswers", sameAnswers)
    let commonPercentage = (sameAnswers / numberOfQues) * 100
    console.log("commonPercentage", commonPercentage)
    let percentageEarned = (commonPercentage / 100) * percent;
    return Math.round(percentageEarned);
}

function calculateValuesPercentage(userA_values, userB_values, numberOfQues, percent) {
    console.log("qq", userA_values, userB_values, numberOfQues, percent)
    function matchingAnswers(userA_values, userB_values) {
        let splitDataA
        let splitDataB
        if (userA_values.includes(',')) {
            splitDataA = userA_values.split(',')
        } else {
            splitDataA = [userA_values]
        }
        if (userB_values.includes(',')) {
            splitDataB = userB_values.split(',')
        } else {
            splitDataB = [userB_values]
        }
        const set = new Set(splitDataA);
        let commonCount = 0;

        for (let i = 0; i < splitDataB.length; i++) {
            if (set.has(splitDataB[i])) {
                commonCount++;
            }
        }
        return commonCount;

    }
    //
    let sameAnswers = matchingAnswers(userA_values, userB_values)
    console.log("sameAnswers", sameAnswers)

    let commonPercentage = (sameAnswers / numberOfQues) * 100
    console.log("commonPercentage", commonPercentage)

    let percentageEarned = (commonPercentage / 100) * percent;
    return Math.round(percentageEarned);
}

function calculateLifestylePercentage(userA_lifestyle, userB_lifestyle, numberOfQues, percent) {
    function matchingAnswers(userA_lifestyle, userB_lifestyle) {
        let splitDataA
        let splitDataB
        if (userA_lifestyle.includes(',')) {
            splitDataA = userA_lifestyle.split(',')
        } else {
            splitDataA = [userA_lifestyle]
        }
        if (userB_lifestyle.includes(',')) {
            splitDataB = userB_lifestyle.split(',')
        } else {
            splitDataB = [userB_lifestyle]
        }

        const set = new Set(splitDataA);
        let commonCount = 0;
        for (let i = 0; i < splitDataB.length; i++) {
            if (set.has(splitDataB[i])) {
                commonCount++;
            }
        }
        return commonCount;
    }
    //
    let sameAnswers = matchingAnswers(userA_lifestyle, userB_lifestyle)
    let commonPercentage = (sameAnswers / numberOfQues) * 100
    let percentageEarned = (commonPercentage / 100) * percent;
    return Math.round(percentageEarned);
}


const getOptionsData = (dataId, selfData) => {
    const filteredData = selfData.filter((o) => o.questionId === dataId);
    let appendData = '';
    filteredData && filteredData.length && filteredData.map(item => {
        if (item.answerType === "multiple") {
            let optionArrayData = item.optionId.split(',')
            console.log("optionArrayData", optionArrayData)

            let optionResult = optionArrayData.map(opData => {
                return `"optionId" like '${opData}'`;
            })
            optionResult = optionResult.join(' or ')
            // if (item.questionId === "e3c0c3eb-b368-4135-98c5-a131bf1b7940") {
            //     //I do not wish condition handle here
            //     optionResult += ` or "optionId"='8573860b-6699-422c-8086-849bcb2a3f89' `
            // }
            appendData = '(' + optionResult + ')'
        } else {
            if (item.questionId === "87375b96-6381-40dd-8939-19633ac64cbb") {
                appendData = `"optionId" in (${selfData.political_affiliation_options})`;
            } else {
                appendData = `"optionId" like '${item.optionId}'`;
            }
        }
    });
    return appendData;
};

async function generateMatches(context, userData, getAllUserActive) {
    try {
        // Fetch self user data on the basis of user id
        // TO DO: remove DATE_PART('day', now() - "createdAt") > 10 condition added for testing
        // console.log("getAllUserActive", getAllUserActive)
        const userIds = getAllUserActive.map(item => item.userId);
        // console.log("userIds", userIds)
        const joinedUserIds = userIds.join("','");
        const updatedUserFlagFalse = await sequelize.query(`UPDATE users SET "calculatedMatches"='true' where id='${userData.id}'`, { type: QueryTypes.UPDATE });
        const deleteMatchData = await sequelize.query(`DELETE FROM "generatedMatches" WHERE "userId"='${userData.id}'`, { type: QueryTypes.DELETE })

        let selfData = await sequelize.query(`select * from answer where "userId"='${userData.id}';`, { type: QueryTypes.SELECT });


        let political_affiliation_options;
        let political_affiliation_mapping =
        {
            conservative: `'${chatbotQuestionIds.conservativeId}','${chatbotQuestionIds.middleRoadId}'`,
            middleRoad: `'${chatbotQuestionIds.conservativeId}','${chatbotQuestionIds.middleRoadId}','${chatbotQuestionIds.liberalId}'`,
            liberal: `'${chatbotQuestionIds.liberalId}','${chatbotQuestionIds.middleRoadId}'`,
        }
        if (selfData.filter((o) => o.optionId !== null && o.optionId === `'${chatbotQuestionIds.conservativeId}'`)) {
            political_affiliation_options = political_affiliation_mapping.conservative
        }
        else if (selfData.filter((o) => o.optionId !== null && o.optionId === `'${chatbotQuestionIds.middleRoadId}'`)) {
            political_affiliation_options = political_affiliation_mapping.middleRoad
        }
        else if (selfData.filter((o) => o.optionId !== null && o.optionId === `'${chatbotQuestionIds.liberalId}'`)) {
            political_affiliation_options = political_affiliation_mapping.liberal
        }
        selfData.political_affiliation_options = political_affiliation_options;


        // fetch other users to generate matches on - opposite gender
        const agePreferenceAnswer = selfData.find(obj => obj.questionId == chatbotQuestionIds.agePreferenceId);


        const agePreferenceCriteria = await getAgePreferenceCriteria(userData.age, agePreferenceAnswer.optionId);
        //do not fetch the rejected user from serve match table
        // and id in ('${joinedUserIds}')
        const otherUsers = await sequelize.query(`SELECT id, lattitude,longitude,"attachmentStyle","loveLanguage","travelDistanceUpto", date_part('year', age("dateOfBirth")) AS age from users where ${agePreferenceCriteria} "userStatus" = 'active' and "profileCompleted" = true and gender <> '${userData.gender}' and id != '${userData.id}'
        AND id not in(
            SELECT "partnerUserId"
            FROM "servedMatches"
            WHERE "userId" = '${userData.id}'
            AND  "matchStatus" = 'reject'
            )`, { type: QueryTypes.SELECT });
        let otherUserData
        console.log("otherUserData:", userData)
        await Promise.all(otherUsers.map(async otherUser => {
            //query for fetch other user calculate
            //e3c0 for race, 33ae for religious, 8737 for quality,e47d for child, 72c3 for physical
            const queryString = `select count(*) as count from answer where "userId" = '${otherUser.id}'
                and (("questionId" = 'e3c0c3eb-b368-4135-98c5-a131bf1b7940' and ${getOptionsData('5fd2e9f1-74f0-49f5-b809-5b2544bbc938', selfData)})
                OR ("questionId" = '33ae7832-50a3-44dc-9753-9137e7955c71' and ${getOptionsData('b3b84220-6acb-437d-a9d9-2761b28b8536', selfData)})
                OR ("questionId" = '87375b96-6381-40dd-8939-19633ac64cbb' and ${getOptionsData('87375b96-6381-40dd-8939-19633ac64cbb', selfData)})
                OR ("questionId" = 'e47d9989-01e6-4b4a-97a6-0fd9dcea626a' and ${getOptionsData('aaee5262-bdc7-4c4c-824e-c7b4a4c27d12', selfData)})
                OR ("questionId" = '72c3107b-cb6a-46ac-bd88-4ee6df22c5b9' and ${getOptionsData('9e549445-052c-4a66-a36b-516d6c4a72d5', selfData)}));`

            // const queryString = `select * from answer limit 5 ;`
            // console.log("queryString:", queryString);
            //find other user data except self id
            otherUserData = await sequelize.query(queryString, { type: QueryTypes.SELECT });
        }));

        // let finalPercentage = 0
        // AND users.distance >= ${ minDistance } 
        // AND users.distance <= ${ maxDistance };


        if (otherUserData[0].count > 0) {
            const findMatchUser = await sequelize.query(`SELECT users.*, answer.*
            FROM answer
            JOIN users ON answer."userId" = users.id where "questionId" in ('${chatbotQuestionIds.qualityId}','${chatbotQuestionIds.valueId}',
                '${chatbotQuestionIds.lifeStyleId}'
            ) AND users.gender  <> '${userData.gender}' and users."userStatus" = 'active' and users."profileCompleted" = true and  users.id in ('${joinedUserIds}')`, { type: QueryTypes.SELECT });
            await Promise.all(findMatchUser && findMatchUser.length && findMatchUser.map(async item => {
                console.log("item", item)
                let l1 = 0
                let l2 = 0
                let l3 = 0
                //qualities percentage
                // console.log("selfData", selfData)

                // q1||q2}}q3
                //selfdata
                //l1
                //110
                if (item.questionId === 'c4358256-23d4-48ed-8898-dd773fd34f6d' || item.questionId === '4c856940-5b7e-4cf7-8884-e6ecbe05f39a' || item.questionId === '401ecb08-35ee-4dd4-a495-90ab8a79baf2') {
                    const selfQualities = selfData.find(obj => obj.questionId == item.questionId);
                    const selfValues = selfData.find(obj => obj.questionId == item.questionId);
                    const selfLifeStyle = selfData.find(obj => obj.questionId == item.questionId);
                     l1 = calculateQualitiesPercentage(selfQualities.optionId, item.optionId, 10, 20)
                     l2 = calculateValuesPercentage(selfValues.optionId, item.optionId, 10, 25)
                     l3 = calculateLifestylePercentage(selfLifeStyle.optionId, item.optionId, 10, 20)
                }

                // if (item.questionId === 'c4358256-23d4-48ed-8898-dd773fd34f6d') {
                //     const selfQualities = selfData.find(obj => obj.questionId == item.questionId);
                //     if (selfQualities) {
                //         let percentageResult = calculateQualitiesPercentage(selfQualities.optionId, item.optionId, 10, 20)
                //         l1 = percentageResult;
                //     }
                // }
                // //values percentage
                // if (item.questionId === '4c856940-5b7e-4cf7-8884-e6ecbe05f39a') {
                //     const selfValues = selfData.find(obj => obj.questionId == item.questionId);
                //     if (selfValues) {
                //         let percentageResult = calculateValuesPercentage(selfValues.optionId, item.optionId, 10, 25)
                //         l2 = percentageResult;
                //     }
                // }
                // //life style percentage
                // if (item.questionId === '401ecb08-35ee-4dd4-a495-90ab8a79baf2') {
                //     const selfLifeStyle = selfData.find(obj => obj.questionId == item.questionId);
                //     if (selfLifeStyle) {
                //         let percentageResult = calculateLifestylePercentage(selfLifeStyle.optionId, item.optionId, 10, 20)
                //         l3 = percentageResult;
                //     }
                // }
                //for Attachment style calculate
                let percentageAttachResult = await calculateAttachmentStylePercentage(userData.attachmentStyle, item.attachmentStyle)

                //for love language calculate
                let percentageLoveResult = await calculateLoveLanguagePercentage(userData.loveLanguage, item.loveLanguage)


                //for get how many miles distance bet self and other user
                let calculateUserMiles = await calculateDistanceInMiles(userData.lattitude, userData.longitude, item.lattitude, item.longitude)

                //for calculate final percentage of user
                // console.log("==============", l1, l2, l3, percentageAttachResult, percentageLoveResult)
                let finalPercentage = l1 + l2 + l3 + percentageAttachResult + percentageLoveResult

                // console.log("finalPercentage", finalPercentage, calculateUserMiles)

                // console.log("========", customer, userData.id, item.id, calculateUserMiles, finalPercentage)
                // let checkDataExist = await sequelize.query(`select count(*) from "generatedMatches" where "userId"='${userData.id}' and "partnerUserId"='${item.userId}'`, { type: QueryTypes.SELECT })
                // console.log("checkDataExist,checkDataExist",checkDataExist)
                // if (checkDataExist[0].count === '0') {
                console.log("==============================")
                // const saveFinalUserInfo = await sequelize.query(`Insert into "generatedMatches" ("userId","partnerUserId","distanceUserToPartner","matchPercentage","createdAt","updatedAt") VALUES ('${userData.id}','${item.userId}','${calculateUserMiles}','${finalPercentage}',current_timestamp,current_timestamp)`, { type: QueryTypes.INSERT });
                const insertQuery = `Insert into "generatedMatches" ("userId","partnerUserId","distanceUserToPartner","matchPercentage","createdAt","updatedAt") VALUES ('${userData.id}','${item.userId}','${calculateUserMiles}','${finalPercentage}',current_timestamp,current_timestamp)  ON CONFLICT ON CONSTRAINT "userId_partnerUserId" DO NOTHING;`;
                const saveFinalUserInfo = await sequelize.query(insertQuery, { type: QueryTypes.INSERT });
                // }
                // const saveFinalUserInfo = await sequelize.query(
                //     `Insert into "generatedMatches" ("userId","partnerUserId","distanceUserToPartner","matchPercentage","createdAt","updatedAt")
                //         SELECT '${userData.id}','${item.userId}','${calculateUserMiles}','${finalPercentage}',current_timestamp,current_timestamp
                //     WHERE NOT EXISTS (
                //         SELECT * FROM "generatedMatches" WHERE "userId"='${userData.id}' and "partnerUserId"='${item.userId}'
                //     );`,
                //     { type: QueryTypes.INSERT }
                // );
                console.log("saveFinalUserInfo", saveFinalUserInfo)
            }));
        }
        const updatedUserFlag = await sequelize.query(`UPDATE users SET "calculatedMatches"='false' where id='${userData.id}'`, { type: QueryTypes.UPDATE });
        context.log('Generated matches successfully for user id:', userData.id);
    } catch (err) {
        context.log('Error while generating matches for user id:', userData.id, ' Error:', err);
    }
}

async function runAlgorithm(context, userId) {
    // let userId = context.req.body.userId

    let query = `SELECT id, gender, lattitude,longitude,"attachmentStyle","travelDistanceUpto","loveLanguage", date_part('year', age("dateOfBirth")) AS age from users where "profileCompleted" = true and "userStatus" = 'active' and "attachmentStyle" IS NOT NULL and "loveLanguage" IS NOT NULL `;
    if (userId) {
        query += ` and id ='${userId}' `;
    }
    const users = await sequelize.query(query, { type: QueryTypes.SELECT });
    const getAllActiveUser = await stripe.getAllActiveSubscription(context);
    const customerIds = Array.from(new Set(getAllActiveUser.data.map(subscription => subscription.customer))).join("','");
    const getAllUserActive = await sequelize.query(`select "userId","customerId" from "stripeCustomer" where "customerId" in ('${customerIds}')`, { type: QueryTypes.SELECT })
    // select * from "stripeSubscription" where "subscriptionId"='SUBS_IOS';
    const getAllUserActiveIos = await sequelize.query(`select "userId","customerId" from "stripeSubscription" where "subscriptionId"='SUBS_IOS'`, { type: QueryTypes.SELECT })

    let concatActiveUser = getAllUserActive.concat(getAllUserActiveIos);
    console.log("concatActiveUser", concatActiveUser)

    await Promise.all(users.map(async user => {
        await generateMatches(context, user, concatActiveUser);
    }));
}


// Function to generate combinations of two arrays

function generateCombinations(arr1, arr2) {
    const result = [];
    for (const item1 of arr1) {
        for (const item2 of arr2) {
            result.push([item1.trim(), item2.trim()]); // removed white spaces before pushing
        }
    }
    return result;
}

// fetch other users to generate matches on - opposite gender
async function getAgePreferenceCriteria(selfAge, preferenceId) {
    let criteria = '';
    if (preferenceId == '6048bacc-05a7-4eb4-b958-37a300b19e8d') { //'Within a 5-year age range.'
        criteria = `  (date_part('year', age("dateOfBirth")) between ${selfAge} and ${selfAge + 5}) and `;
    } else if (preferenceId == '76b71e93-2f27-42c9-ba60-2dde6cadf301') { //'Within a 10-year age range.'
        criteria = `  (date_part('year', age("dateOfBirth")) between ${selfAge} and ${selfAge + 10}) and `;
    } else if (preferenceId == '68229f1a-172b-4412-9798-38e75ef4cdc9') { //'More than 10 years'' age difference in either direction.'
        criteria = `  (date_part('year', age("dateOfBirth")) between ${selfAge - 10} and ${selfAge + 10}) and `;
    }
    return criteria;
}
export { runAlgorithm, findLoveLanguage, findAttachmentStyle, calculatePersonalityAssessmentScore }



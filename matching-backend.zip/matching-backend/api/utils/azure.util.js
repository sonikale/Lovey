
import { BlobServiceClient } from '@azure/storage-blob';

export async function getAzureBlobClient(imageName) {
    const blobServiceClient = BlobServiceClient.fromConnectionString(process.env["AZURE_STORAGE_CONNECTION_STRING"]);
    const containerClient = blobServiceClient.getContainerClient(process.env["AZURE_BLOB_CONTAINER_NAME"]);
    return containerClient.getBlockBlobClient(imageName);
}
import jwt from "jsonwebtoken";
import User from '../models/user.model.js';
import { StatusCodes } from 'http-status-codes';
import { errorResponse, invalidRequestResponse } from '../core/responseApi.js';
import * as constants from '../core/constants.js';

export function createJwtToken(payload) {
  return jwt.sign(payload, process.env['JWT_SECRET'], { expiresIn: "20days" });
}

export function verifyJwtToken(token) {
  try {
    return jwt.verify(token, process.env['JWT_SECRET']);
  } catch (err) {
    return err;
  }
}

export async function validateToken(context, req) {
  let result = {};
  try {
    const userDetails = await User.findOne({ where: { jwttoken: req.headers.authorization.split(" ")[1] } });  // check token present in DB
    if (userDetails) {
      const jwtVerifyResult = verifyJwtToken(userDetails.jwttoken);
      if (jwtVerifyResult.email) {
        result = { error: false, userDetails };
      } else {
        context.log('Invalid Request for userId:', userDetails.id, ' Details:', jwtVerifyResult);
        result = invalidRequestResponse(constants.messages.INVALID_TOKEN);
      }
    } else {
      context.log('Invalid Request. Database entry not found for Token:', req.headers.authorization.split(" ")[1]);
      result = invalidRequestResponse(constants.messages.USER_NOT_EXIST);
    }
  } catch (err) {
    context.log('API Error. Details:', err);
    result = errorResponse('Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
  }
  return result;
}
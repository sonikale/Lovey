import { QueryTypes } from 'sequelize';
import sequelize from "../db/db.connect.js";

export async function getQuestions() {
    const questions = await sequelize.query("SELECT id, sequence, section, question, parentque, haschild, answertype, sectionresulttype FROM question where parentque = true", { type: QueryTypes.SELECT });
    
    return questions;
}

export async function getQuestionOption(questionId) {
    const questionOptionMap = await sequelize.query("SELECT op.option as \"optionTxt\", qom.optionid as \"optionId\" FROM question que \
    INNER JOIN \"questionOptionMapping\" qom on qom.questionid = que.id \
    INNER JOIN option op ON op.id = qom.optionid where que.id = '"+ questionId + "'", { type: QueryTypes.SELECT });
    
    return questionOptionMap;
}

export async function getSubQuestions(parentQuesId) {
    const subQuestion = await sequelize.query("SELECT q.id, q.sequence, q.section, q.question, q.parentque, q.haschild, q.answertype, q.sectionresulttype, sq.\"parentOptionId\" FROM question q \
	INNER JOIN subquestion sq ON sq.\"childQuesId\" = q.id where sq.\"parentQuesId\" = '"+ parentQuesId + "'", { type: QueryTypes.SELECT });
    
    return subQuestion;
}

export async function getAnswersByUser(userId) {
    const answer = await sequelize.query(`SELECT id, "userId", "questionId", "answerType", answer, "optionId"
	FROM answer where "userId" = '${userId}';`, { type: QueryTypes.SELECT });
    
    return answer;
}

export async function formatQuestion(ques, answerData) {
    let quesObject = {
        sequence: ques.sequence,
        questionTxt: ques.question,
        questionId: ques.id,
        answerType: ques.answertype,
        givenAnswer: '',
        section: ques.section,
        options: [],
        subquestions: {}
    };

    if (ques.answertype != 'text' && ques.answertype != 'info') {
        quesObject.options = await getQuestionOption(ques.id);
        if (answerData && answerData.optionId) {
            let answerOptions = JSON.parse(answerData.optionId);
            const givenAnswerArray = answerOptions.map(answerId => {
                const matchingItem = quesObject.options.find(option => option.optionId == answerId);
                return matchingItem.optionTxt;
            });
            quesObject.givenAnswer = givenAnswerArray.join(', ');
        }
    }
    else {
        quesObject.givenAnswer = answerData && answerData.answer ? answerData.answer : '';
    }
    return quesObject;
}

export async function getQuestionById(quesId) {
    const question = await sequelize.query(`SELECT id, sequence, section, question, parentque, haschild, answertype,
     sectionresulttype, imageurl, validation FROM question where id = '${quesId}'`, { type: QueryTypes.SELECT });
    
    return question;
}
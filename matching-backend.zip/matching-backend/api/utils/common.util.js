import CryptoJS from 'crypto-js';
import Users from '../models/user.model.js';
import imageModel from '../models/image.model.js';
import { Op, QueryTypes, where } from 'sequelize';
import httpError from "http-errors";
import sequelize from "../db/db.connect.js";
import custSubscriptionModel from '../models/custSubscription.model.js';
import { retrieveProduct } from './stripe/stripe.js';
import { getChatBotHistory } from './chat.util.js';
import { chatbotConstants } from '../core/constants.js';

// Function to decrypt data using AES decryption
const decryptData = (encryptedData, secretKey) => {
    const bytes = CryptoJS.AES.decrypt(encryptedData, secretKey);
    return bytes.toString(CryptoJS.enc.Utf8);
};

const getUserProfile = async (userId, firstNameOnly = false) => {
    const user = await Users.findOne({ where: { id: userId } });
    // const photoAlbum = await imageModel.findOne({ where: { isProfileImage: true, userId: userId } });
    const photoAlbum = await imageModel.findAll({ where: {  userId: userId } });
    const profileImage = photoAlbum.find(o => o.isProfileImage);
    let profile = {
        gender: '',
        userId,
        country: '',
        state: '',
        city: '',
        address: '',
        userName: '',
        firstName: '',
        profileImage: null,
        imageName: null,
        age: null,
        aboutme: '',
        profileCompleted: false,
        lattitude: '',
        langitude: '',
    };
   console.log("user",user)
    if (user) {
        profile.userId = userId;
        profile.gender = user.gender
        profile.country = user.country;
        profile.state = user.state;
        profile.city = user.city;
        profile.address = user.address;
        profile.userName = firstNameOnly ? user.firstName : user.firstName + " " + user.lastName;
        profile.firstName = user.firstName;
        profile.age = await calculateAge(user.dateOfBirth);
        profile.aboutme = user.aboutme;
        profile.profileCompleted = user.profileCompleted;
        profile.lattitude = user.lattitude;
        profile.langitude = user.langitude;
    } else {
        throw httpError.Conflict("User does not exist.");
    }

    if (photoAlbum.length > 0 && profileImage) {
        profile.profileImage = profileImage.imageUrl;
        profile.imageName = profileImage.imageName;
        profile.allImages = photoAlbum.map(i => i.imageUrl);
    }

    return profile;
}

const getFeedbackForUser = async (searchCriteria) => {
    // top 5 feedback
    const feedback = await sequelize.query(`SELECT id, "positiveFeedback", "negativeFeedback", "neutralFeedback", "partnerUserId", "userId", "tellUsMoreAboutDate", "wantToGoOnSecondDate", "createdAt", "updatedAt"
	FROM feedback ${searchCriteria} order by "updatedAt" desc limit 5;`, { type: QueryTypes.SELECT });

    return feedback;
}
const getFeedbackForPartner = async (searchCriteria) => {
    const feedback = await sequelize.query(`SELECT id, "userId","partnerUserId", "wantToGoOnSecondDate"
    FROM feedback ${searchCriteria} `, { type: QueryTypes.SELECT });
 
    return feedback;
}
const getPartnerFeedback = async(partnerUserId,userId)=>{
    let searchCriteria='';
    if (partnerUserId) {
        // checks whether loggedin user has received feedback from partner
        searchCriteria += `where "userId" = '${partnerUserId}' and "partnerUserId" = '${userId}' `;
    }
    const partnerfeedback = await getFeedbackForPartner(searchCriteria);
     return partnerfeedback;
}
const getMyFeedback = async (feedbackType, userId, partnerUserId) => {
    let response = {};
    const overallPositiveFeedback = new Set();
    const overallNegativeFeedback = new Set();
    const overallNeutralFeedback = new Set();

    let searchCriteria = '';
    if (feedbackType == 'given') {
        searchCriteria = ` where "userId" = '${userId}' `;
    } else {
        searchCriteria = ` where "partnerUserId" = '${userId}' `;
    }

    if (feedbackType == 'given' && partnerUserId) {
        searchCriteria += ` and "partnerUserId" = '${partnerUserId}'`;
    }

    const feedback = await getFeedbackForUser(searchCriteria);

    response.feedback = await Promise.all(feedback.map(async item => {
        formatOverallFeedbackArray(overallPositiveFeedback, item.positiveFeedback);
        formatOverallFeedbackArray(overallNegativeFeedback, item.negativeFeedback);
        formatOverallFeedbackArray(overallNeutralFeedback, item.neutralFeedback);
        if (feedbackType == 'given') {
            item.profile = await getUserProfile(item.partnerUserId, true);
            item.profile.matchPercent = '' // TO DO:  add match percentage
        } else {
            item.profile = await getUserProfile(item.userId, true);
            item.profile.matchPercent = '' // TO DO:  add match percentage
        }
        return item;
    }));

    response.overallPositiveFeedback = Array.from(overallPositiveFeedback);
    response.overallNegativeFeedback = Array.from(overallNegativeFeedback);
    response.overallNeutralFeedback = Array.from(overallNeutralFeedback);
    return response;
}

const formatOverallFeedbackArray = (tempSet, feedback) => {
    const feedbackArray = JSON.parse(feedback);
    feedbackArray.forEach(item => {
        tempSet.add(item);
    });
}

async function calculateAge(dateOfBirth) {
    const dob = new Date(dateOfBirth);
    const today = new Date();

    let age = today.getFullYear() - dob.getFullYear();

    if (today.getMonth() < dob.getMonth() ||
        (today.getMonth() === dob.getMonth() && today.getDate() < dob.getDate())) {
        age--;
    }

    return age;
}

async function getUserListForAdmin(filterBy) {
    let searchCriteria = '';
    let page = filterBy.page;
    let pageSize = filterBy.pageSize;

    if (isNaN(page) || isNaN(pageSize) || page <= 0 || pageSize <= 0) {
        page = 1;
        pageSize = 10;
    }

    const offset = (page - 1) * pageSize;

    if (filterBy.name) {
        searchCriteria += ` and ((CONCAT("firstName", ' ', "lastName") like '${filterBy.name}%') 
        or (CONCAT("lastName", ' ', "firstName") like '${filterBy.name}%' ))`;
    }
    if (filterBy.email) {
        searchCriteria += ` and email='${filterBy.email}'`;
    }
    if (filterBy.userStatus) {
        searchCriteria += ` and "userStatus"='${filterBy.userStatus}'`;
    }
    if (filterBy.gender) {
        searchCriteria += ` and gender='${filterBy.gender}'`;
    }

    let finalResult = { userList: [] };
    finalResult.maleCount = await Users.count({ where: { userStatus: { [Op.notIn]: ['deleted', 'admin', 'Aphrodite_chatbot'] }, gender: "Male" } });
    finalResult.femaleCount = await Users.count({ where: { userStatus: { [Op.notIn]: ['deleted', 'admin', 'Aphrodite_chatbot'] }, gender: "Female" } });
    const users = await sequelize.query(`SELECT id, "firstName", "lastName", "userName", email, phone, city, state, address, country, gender, "dateOfBirth", "userStatus"  
	FROM users where "userStatus" NOT IN('deleted','admin','Aphrodite_chatbot') ${searchCriteria} order by "updatedAt" desc  LIMIT ${pageSize} OFFSET ${offset};`, { type: QueryTypes.SELECT });

    // get count for pagination
    const usersCnt = await sequelize.query(`SELECT count(*) as count FROM users where "userStatus" NOT IN('deleted','admin','Aphrodite_chatbot') ${searchCriteria}`, { type: QueryTypes.SELECT });
    finalResult.usersCount = usersCnt.length > 0 ? usersCnt[0].count : 0;
    await Promise.all(users.map(async user => {
        user.age = await calculateAge(user.dateOfBirth);

        const photoAlbum = await imageModel.findOne({ where: { isProfileImage: true, userId: user.id } });
        if (photoAlbum) {
            user.profileImage = photoAlbum.imageUrl;
            user.imageName = photoAlbum.imageName;
        } else {
            user.profileImage = null;
            user.imageName = null;
        }

        const subscription = await custSubscriptionModel.findOne({ where: { subscriptionStatus: "active" } });
        user.subscription = {};
        if (subscription) {
            const getProductDetails = await retrieveProduct(subscription.productId);
            user.subscription.name = getProductDetails.product.name;
            user.subscription.couponCode = subscription.couponCode;
            user.subscription.subscriptionStatus = subscription.subscriptionStatus;
            user.subscription.createdAt = subscription.createdAt;
        }
        user.dateCompletedUsers = await getdateCompletedUsers(user.id);
        // TO DO: Change logic for Recommended matches after rule engine
        user.recommendedMatches = await getRecommendedMatchesForUser(user.gender);
        finalResult.userList.push(user);
    }));

    return finalResult;
}

async function updateUserInfoByAdmin(userData) {
    if (userData.userStatus == "delete") {

        const userDetails = await Users.findOne({ where: { id: userData.userId } });
        if (userDetails) {
            const userPayload = {
                firstName: 'deleted_firstName',
                lastName: 'deleted_lastName',
                email: 'deleted_email',
                userName: 'deleted_userName',
                phone: '-1',
                country: 'deleted_country',
                state: 'deleted_state',
                city: 'deleted_city',
                address: 'deleted_address',
                jwttoken: '',
                aboutme: 'deleted_aboutMe',
                chatUserId: 'deleted_chatUserId',
                chatUserToken: 'deleted_chatUserToken',
                fcmDeviceToken: '',
                dateOfBirth: '1800-12-12',
                userStatus: 'deleted',
                age: await calculateAge(userDetails.dateOfBirth)
            };
            return await Users.update(userPayload, { where: { id: userData.userId } });
        }
        return {};
    } else {
        return await Users.update({ userStatus: userData.userStatus }, { where: { id: userData.userId } });
    }
}

async function getAdminDashboard(loggedInUser) {
    let response = { activeUserCount: 0, activeSubscriptionCount: 0, matchesCount: 0, name: '' };
    const adminUser = await sequelize.query(`SELECT "firstName", "lastName" from users where "userStatus" = 'admin' and id = '${loggedInUser}'`, { type: QueryTypes.SELECT });
    const activeUsersCountRes = await sequelize.query(`SELECT count(id) as "userCnt" from users where "userStatus" NOT IN('deleted', 'admin', 'Aphrodite_chatbot')`, { type: QueryTypes.SELECT });
    const activeSubscriptionCountRes = await sequelize.query(`SELECT count(id) "subscriptionCnt" from "stripeSubscription" where "subscriptionStatus" = 'active' `, { type: QueryTypes.SELECT });

    if (activeUsersCountRes && activeUsersCountRes.length > 0) {
        response.activeUserCount = activeUsersCountRes[0].userCnt;
    }

    if (activeSubscriptionCountRes && activeSubscriptionCountRes.length > 0) {
        response.activeSubscriptionCount = activeUsersCountRes[0].userCnt;
    }
    response.name = adminUser && adminUser.length > 0 ? adminUser[0].firstName + " " + adminUser[0].lastName : '';
    return response;
}

async function getHomeScreenDetails(userId) {
    let response = { imagesCnt: 0, userDetails: {}, aphroditeProfile: { consistency: [], values: [], qualities: [] }, aphroditeChatHistory: {} };

    response.aphroditeChatHistory = await getChatBotHistory(userId);
    response.userDetails = await getUserProfile(userId, true);
    if (response.userDetails.profileCompleted == true) {
        response.aphroditeProfile.consistency = await getConsistencyForUser(userId);
        response.aphroditeProfile.values = await getValuesForUser(userId);
        response.aphroditeProfile.qualities = await getQualitiesForUser(userId);
        const chatbotDataForHomeScreen = await getChatbotDataForHomeScreen(userId);
        response.aphroditeProfile.nonNegotiables = chatbotDataForHomeScreen.nonNegotiables;
        response.aphroditeProfile.mustHaves = chatbotDataForHomeScreen.mustHaves;
    }
    response.imagesCnt = await imageModel.count({ where: { userId: userId } });
    return response;
}

async function getConsistencyForUser(userId) {
    let consistency = { consistencyPercentage: 0, consistencyMsg: '' };

    // find consistency with true answer and calculate percenatge
    const result = await sequelize.query(`SELECT CASE WHEN count(*) > 0 THEN (COUNT(*) FILTER (WHERE "optionId" = '763d5ab8-2eb4-43ba-a679-63e4db39ebc5') * 100.0 / COUNT(*)) ELSE 0 END AS percentage
	FROM answer where "questionId" in(select id from question where section = 'Consistency') and "userId" = '${userId}';`, { type: QueryTypes.SELECT });

    if (result.length > 0) {
        consistency.consistencyPercentage = result[0].percentage;
        if (result[0].percentage >= 50) {
            consistency.consistencyMsg = chatbotConstants.consistencyHighMsg;
        } else {
            consistency.consistencyMsg = chatbotConstants.consistencyLowMsg;
        }
    }
    return consistency;
}

async function getValuesForUser(userId) {
    let values = [];
    const valuesAnswer = await sequelize.query(`SELECT "userId", "questionId", "answerType", answer, "optionId"
	FROM answer where "questionId" = '4c856940-5b7e-4cf7-8884-e6ecbe05f39a' and "userId" = '${userId}';`, { type: QueryTypes.SELECT });

    if (valuesAnswer.length > 0) {
        const answerOptionIds = valuesAnswer[0].optionId.split(',');
        // add single quotes to every element to get data from DB
        const convertedOptionIds = answerOptionIds.map(ele => { return `'${ele}'`; });
        const searchOptionIds = convertedOptionIds.join(',')
        values = await sequelize.query(`select "shortDesc","longDesc" from constants where section = 'Values' and "shortDesc" in(select option from option where id in (${searchOptionIds}))`, { type: QueryTypes.SELECT });
    }

    return values;
}

async function getQualitiesForUser(userId) {
    let qualities = [];
    const qualitiesAnswer = await sequelize.query(`SELECT "userId", "questionId", "answerType", answer, "optionId"
	FROM answer where "questionId" = 'c4358256-23d4-48ed-8898-dd773fd34f6d' and "userId" = '${userId}';`, { type: QueryTypes.SELECT });

    if (qualitiesAnswer.length > 0) {
        const answerOptionIds = qualitiesAnswer[0].optionId.split(',');
        // add single quotes to every element to get data from DB
        const convertedOptionIds = answerOptionIds.map(ele => { return `'${ele}'`; });
        const searchOptionIds = convertedOptionIds.join(',')
        qualities = await sequelize.query(`select "shortDesc","longDesc" from constants where section = 'Qualities' and "shortDesc" in(select option from option where id in (${searchOptionIds}) limit 5)`, { type: QueryTypes.SELECT });
    }

    return qualities;
}

async function getRestaurantList() {
    const restaurantList = await sequelize.query(`SELECT id, "restaurantName", latitude, longitude, address, "gmapUrl" FROM restaurants;`, { type: QueryTypes.SELECT });

    return restaurantList;
}

async function getChatbotDataForHomeScreen(userId) {
    let result = { nonNegotiables: {}, mustHaves: {} };
    const chatbotDataForUser = await sequelize.query(`SELECT "userId", "questionId", "answerType", answer, "optionId"
	FROM answer where "questionId" in('4a94608f-9dd3-4f51-8ce9-64c5ea425e6b','f12c1d11-d0c0-4120-bf93-3fb1158185a3') and "userId" = '${userId}';`, { type: QueryTypes.SELECT });

    if (chatbotDataForUser.length > 0) {
        result.nonNegotiables = (chatbotDataForUser.find(obj => obj.questionId === '4a94608f-9dd3-4f51-8ce9-64c5ea425e6b')).answer;
        result.mustHaves = (chatbotDataForUser.find(obj => obj.questionId === 'f12c1d11-d0c0-4120-bf93-3fb1158185a3')).answer;
    }
    return result;
}

async function getdateCompletedUsers(userId) {
    let dateCompletedUsers = [];
    // Note: We are assuming that if partner accept date schedule then its a date completion
    const users = await sequelize.query(`SELECT "imageUrl", "userId" from "photoAlbum" where "isProfileImage" = true and "userId" in (SELECT CASE when ("initiatorUserId" = '${userId}') then "partnerUserId" 
    else "initiatorUserId" end as "partnerUserId"
	FROM "dateSchedule" where ("initiatorUserId" = '${userId}' or "partnerUserId" ='${userId}') and "meetStatus" like 'Accept%');`, { type: QueryTypes.SELECT });

    if (users.length > 0) {
        dateCompletedUsers = users;
    }
    return dateCompletedUsers;
}

async function getRecommendedMatchesForUser(gender) {
    let recommendedMatchesForUser = [];
    // To Do: Change this logic once rule engine builds. show recommendded matches displayed to user
    const users = await sequelize.query(`SELECT "imageUrl", "userId" from "photoAlbum" where "isProfileImage" = true and "userId" in (SELECT id FROM users where gender <> '${gender}' order by "updatedAt" desc limit 5);`, { type: QueryTypes.SELECT });

    if (users.length > 0) {
        recommendedMatchesForUser = users;
    }
    return recommendedMatchesForUser;
}

async function getMatchProfile(userId) {
    let response = { userDetails: {}, aphroditeProfile: { consistency: [], values: [], qualities: [] } };

    response.userDetails = await getUserProfile(userId, true);
    if (response.userDetails.profileCompleted == true) {
        response.aphroditeProfile.consistency = await getConsistencyForUser(userId);
        response.aphroditeProfile.values = await getValuesForUser(userId);
        response.aphroditeProfile.qualities = await getQualitiesForUser(userId);
        const chatbotDataForHomeScreen = await getChatbotDataForHomeScreen(userId);
        response.aphroditeProfile.nonNegotiables = chatbotDataForHomeScreen.nonNegotiables;
        response.aphroditeProfile.mustHaves = chatbotDataForHomeScreen.mustHaves;
    }
    return response;
}

export {
    decryptData, getUserProfile, getMyFeedback, calculateAge, getUserListForAdmin, updateUserInfoByAdmin, getAdminDashboard,
    getHomeScreenDetails, getRestaurantList, getMatchProfile,getPartnerFeedback
}
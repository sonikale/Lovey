import createError from 'http-errors';
import sequelize from "../db/db.connect.js";
import { QueryTypes } from 'sequelize';
import { messages } from '../core/constants.js';
import { createObjectCsvStringifier as createCsvWriter } from 'csv-writer';

export async function exportDataToCSV(context, filter) {
    try {
        const data = await sequelize.query(`SELECT id, "firstName", "lastName", email, "userName", country, city, address, phone, state, lastlogin, aboutme, "createdAt", "deviceType", gender, "dateOfBirth", "userStatus", age, "travelDistanceUpto", "profileCompleted"
    FROM users where DATE("createdAt") BETWEEN '${filter.startDate}' AND '${filter.endDate}'`, { type: QueryTypes.SELECT });

        const csvStringifier = createCsvWriter({
            header: [
                { id: 'firstName', title: 'First Name' },
                { id: 'lastName', title: 'Last Name' },
                { id: 'email', title: 'Email' },
                { id: 'userName', title: 'User Name' },
                { id: 'country', title: 'Country' },
                { id: 'city', title: 'City' },
                { id: 'address', title: 'Address' },
                { id: 'phone', title: 'Phone' },
                { id: 'state', title: 'State' },
                { id: 'lastlogin', title: 'Last Login' },
                { id: 'aboutme', title: 'About Me' },
                { id: 'createdAt', title: 'User Created At' },
                { id: 'deviceType', title: 'Device Type' },
                { id: 'gender', title: 'Gender' },
                { id: 'dateOfBirth', title: 'Date Of Birth' },
                { id: 'userStatus', title: 'User Status' },
                { id: 'age', title: 'Age' },
                { id: 'travelDistanceUpto', title: 'Willing To Travel Upto' },
                { id: 'profileCompleted', title: 'Profile Completed' }
            ]
        });
        const csvContent = csvStringifier.getHeaderString() + csvStringifier.stringifyRecords(data);
        return csvContent;
    } catch (err) {
        context.log('Error while downloading csv file. details:', err);
        throw createError[500](messages.DOWNLOAD_USER_REPORT_ERROR);
    }
}
import admin from 'firebase-admin';
import serviceAccount from '../core/lovey-app-firebase-adminsdk.json' assert { type: "json" };

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

export async function sendPushNotification(context, data) {
    try {
        context.log('Sending Push Notification. data:', data);

        const message = {
            notification: {
                title: data.title,
                body: data.body
            },
            data: {
                userDetails: JSON.stringify(data.userDetails)
            },
            token: data.fcmDeviceToken
        };

        const fcmResult = await admin.messaging().send(message);
        context.log('Successfully sent message:', fcmResult);
    } catch (err) {
        context.log(`Error while sending push notification. Details: ${data}. Error: ${err}`);
    }
}
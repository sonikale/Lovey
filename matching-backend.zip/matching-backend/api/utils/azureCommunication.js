import { StatusCodes } from 'http-status-codes';
import { successResponse, errorResponse } from '../core/responseApi.js';
import { CommunicationIdentityClient } from '@azure/communication-identity';
import { ChatClient } from '@azure/communication-chat';
import { AzureCommunicationTokenCredential } from '@azure/communication-common';

export async function generateIdentityToken() {
    let chatIdentityData = {};

    try {
        const connectionString = process.env['AZURE_COMMUNICATION_CONNECTION_STRING'];
        const identityClient = new CommunicationIdentityClient(connectionString);

        let identityResponse = await identityClient.createUser();
        // Issue an access token with a validity of 24 hours and the "voip" scope for an identity
        let tokenResponse = await identityClient.getToken(identityResponse, ["chat"]);

        // Get the token and its expiration date from the response
        const { token, expiresOn } = tokenResponse;
        chatIdentityData = { "chatUserToken": token, "chatUserId": identityResponse.communicationUserId }

        return successResponse(
            chatIdentityData ? "Azure Communication Access Token" : "No record found",
            chatIdentityData ? chatIdentityData : {},
            StatusCodes.OK
        )
    }
    catch (error) {
        return errorResponse(error, StatusCodes.BAD_REQUEST);
    }
}

export async function refreshAzureChatToken(identityId) {
    let chatIdentityData = {};

    try {
        let identityResponse = { 'communicationUserId': identityId }

        const connectionString = process.env['AZURE_COMMUNICATION_CONNECTION_STRING'];

        // Instantiate the identity client
        const identityClient = new CommunicationIdentityClient(connectionString);

        // Issue an access token with a validity of 24 hours and the "voip" scope for an identity
        let tokenResponse = await identityClient.getToken(identityResponse, ["chat"]);

        // Get the token and its expiration date from the response
        const { token, expiresOn } = tokenResponse;

        chatIdentityData = { "chatUserToken": token, "chatUserId": identityId }

        return successResponse(
            chatIdentityData ? "Azure Communication Access Token" : "No record found",
            chatIdentityData ? chatIdentityData : {},
            StatusCodes.OK
        )
    }
    catch (error) {
        return errorResponse(error, StatusCodes.BAD_REQUEST);
    }
}


export async function createThread(dataObj) {

    try {
        // Your unique Azure Communication service endpoint
        let endpointUrl = process.env["AZURE_COMMUNICATION_ENDPOINT"];
        // The user access token generated as part of the pre-requisites
        let userAccessToken = dataObj.participant1.chatUserToken;

        let chatClient = new ChatClient(endpointUrl, new AzureCommunicationTokenCredential(userAccessToken));
        const createChatThreadRequest = {
            topic: dataObj.participant1.userName + " and " + dataObj.participant2.userName
        };
        const createChatThreadOptions = {
            participants: [
                {
                    id: { communicationUserId: dataObj.participant1.chatUserId },
                    displayName: dataObj.participant1.userName
                },
                {
                    id: { communicationUserId: dataObj.participant2.chatUserId },
                    displayName: dataObj.participant2.userName
                }
            ]
        };
        const createChatThreadResult = await chatClient.createChatThread(createChatThreadRequest, createChatThreadOptions);
        const threadId = createChatThreadResult.chatThread.id;

        return successResponse(
            threadId ? "Chat thread id created" : "Thread id creation error",
            threadId ? threadId : [],
            StatusCodes.OK
        )
    }
    catch (error) {
        return errorResponse(error, StatusCodes.BAD_REQUEST);
    }
}

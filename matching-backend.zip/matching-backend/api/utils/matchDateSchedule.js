import { QueryTypes } from 'sequelize';
import sequelize from "../db/db.connect.js";
import dateScheduleModel from '../models/dateSchedule.model.js';
import { getUserProfile } from './common.util.js';
import { sendPushNotification } from './fcm.js';
import { messages } from '../templates/SMSEmailTemplates.js';
import Users from '../models/user.model.js';
import * as clickSend from '../utils/clickSend.util.js';

async function getMatchDateSchedule(userId, partnerUserId) {
    const dateSchedule = await getDateScheduleFromDB(userId, partnerUserId);
    let result = {};
    if (dateSchedule && dateSchedule.length > 0) {
        result.initiatorDetails = await getUserProfile(dateSchedule[0].initiatorUserId, true);
        result.partnerDetails = await getUserProfile(dateSchedule[0].partnerUserId, true);
        let getMatchPercentage = await sequelize.query(`select "matchPercentage" from "servedMatches" where "partnerUserId"='${dateSchedule[0].partnerUserId}' and "userId"='${dateSchedule[0].initiatorUserId}'`, { type: QueryTypes.SELECT })
        result.meetStatus = dateSchedule[0].meetStatus;
        result.matchPercentage = getMatchPercentage[0].matchPercentage; // TO DO: update match percentage once rule engine builds
        result.dateNumber = dateSchedule[0].dateNumber;

        switch (dateSchedule[0].meetStatus) {
            case 'Initiate':
                result.fromLocation = dateSchedule[0].initiatorMeetLocation;
                result.suggestedLocation = '';
                result.fromMeetDateTime = dateSchedule[0].initiatorMeetDateTime;
                result.suggestedMeetDateTime = null;
                break;
            case 'SuggestedByInitiator':
            case 'AcceptedByPartner':
            case 'DeclinedByPartner':
                result.fromLocation = dateSchedule[0].partnerMeetLocation;
                result.suggestedLocation = dateSchedule[0].initiatorMeetLocation;
                result.fromMeetDateTime = dateSchedule[0].partnerMeetDateTime;
                result.suggestedMeetDateTime = dateSchedule[0].initiatorMeetDateTime;
                break;
            case 'SuggestedByPartner':
            case 'AcceptedByInitiator':
            case 'DeclinedByInitiator':
                result.fromLocation = dateSchedule[0].initiatorMeetLocation;
                result.suggestedLocation = dateSchedule[0].partnerMeetLocation;
                result.fromMeetDateTime = dateSchedule[0].initiatorMeetDateTime;
                result.suggestedMeetDateTime = dateSchedule[0].partnerMeetDateTime;
                break;
        }
    }
    return result;
};

async function postMatchDateSchedule(userId, postData, context) {
    const dateSchedule = await getDateScheduleFromDB(userId, postData.partnerUserId, postData.dateNumber);
    const partnerDetails = await Users.findOne({ where: { id: postData.partnerUserId } });

    let userDetails = { screen: 'schedule', partnerUserId: userId };
    let result = {}, pushMotificationBody = { fcmDeviceToken: partnerDetails.fcmDeviceToken, userDetails };
    let sendSMSObj = {
        to: process.env["COUNTRY_CODE"] + partnerDetails.phone
    }

    if (dateSchedule && dateSchedule.length > 0) {
        if (postData.meetStatus == 'Suggest') {
            let uploadPayload = {};
            if (userId == dateSchedule[0].initiatorUserId) {
                uploadPayload = {
                    meetStatus: 'SuggestedByInitiator',
                    initiatorMeetLocation: postData.suggestedMeetLocation,
                    initiatorMeetDateTime: postData.suggestedDateTime,
                };
            } else {
                uploadPayload = {
                    meetStatus: 'SuggestedByPartner',
                    partnerMeetLocation: postData.suggestedMeetLocation,
                    partnerMeetDateTime: postData.suggestedDateTime,
                };
            }

            result = await dateScheduleModel.update(uploadPayload, { where: { id: dateSchedule[0].id } });
            // sms opayload
            sendSMSObj = { ...sendSMSObj, body: messages.suggestDateTxtMsg }

            // Prepare Push Notification Data for sugeest new date schedule
            pushMotificationBody = {
                ...pushMotificationBody,
                title: messages.fixDateInRestauSuggestPNTitle,
                body: messages.fixDateInRestauSuggestPNMsg,
            };
        } else if (postData.meetStatus == 'Accept') {
            const meetStatus = userId == dateSchedule[0].initiatorUserId ? 'AcceptedByInitiator' : 'AcceptedByPartner';
            result = await dateScheduleModel.update({ meetStatus }, { where: { id: dateSchedule[0].id } });
            // sms opayload
            sendSMSObj = { ...sendSMSObj, body: messages.acceptDateTxtMsg }

            // Prepare Push Notification Data for Accept date schedule
            pushMotificationBody.userDetails.screen = 'date_accepted';
            pushMotificationBody = {
                ...pushMotificationBody,
                title: messages.fixDateInRestauAcceptPNTitle,
                body: messages.fixDateInRestauAcceptPNMsg,
            };
        } else {
            const meetStatus = userId == dateSchedule[0].initiatorUserId ? 'DeclinedByInitiator' : 'DeclinedByPartner';
            result = await dateScheduleModel.update({ meetStatus }, { where: { id: dateSchedule[0].id } });
            // sms opayload
            sendSMSObj = { ...sendSMSObj, body: messages.declineDateTxtMsg }

            // Prepare Push Notification Data for Decline date schedule
            pushMotificationBody.userDetails.screen = 'date_declined';
            pushMotificationBody = {
                ...pushMotificationBody,
                title: messages.fixDateInRestauDeclinePNTitle,
                body: messages.fixDateInRestauDeclinePNMsg,
            };
        }
    } else {
        const insertPayload = {
            initiatorUserId: userId,
            partnerUserId: postData.partnerUserId,
            meetStatus: 'Initiate',
            initiatorMeetLocation: postData.suggestedMeetLocation,
            partnerMeetLocation: '',
            initiatorMeetDateTime: postData.suggestedDateTime,
            dateNumber: postData.dateNumber
        };
        result = await dateScheduleModel.create(insertPayload);
        // sms opayload
        sendSMSObj = { ...sendSMSObj, body: messages.initiateDateTxtMsg }

        // Prepare Push Notification Data for Initiate date schedule
        pushMotificationBody = {
            ...pushMotificationBody,
            title: messages.fixDateInRestauInitPNTitle,
            body: messages.fixDateInRestauInitPNMsg,
        };
    }

    clickSend.SendSMS(context, sendSMSObj);
    sendPushNotification(context, pushMotificationBody);
    return result;
}

async function getDateScheduleFromDB(userId, partnerUserId, dateNumber) {
    let searchCriteria = '';
    if (dateNumber) {
        searchCriteria = ` "dateNumber" = ${dateNumber} and `;
    }
    const dateSchedule = await sequelize.query(`SELECT id, "initiatorUserId", "partnerUserId", "meetStatus", "initiatorMeetLocation", "partnerMeetLocation", 
    "initiatorMeetDateTime", "partnerMeetDateTime", "createdAt", "updatedAt", "dateNumber"
	FROM "dateSchedule" where ${searchCriteria} (("initiatorUserId" = '${userId}' and "partnerUserId" = '${partnerUserId}') or ("initiatorUserId" = '${partnerUserId}' and "partnerUserId" = '${userId}')) order by "dateNumber" desc limit 1`, { type: QueryTypes.SELECT });

    return dateSchedule;
}

export { getMatchDateSchedule, postMatchDateSchedule }
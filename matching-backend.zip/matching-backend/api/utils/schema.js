import Joi from 'joi';

const validateRequest = (schema, reqBody) => {
    if (Joi.isSchema(schema)) {
        const { error } = schema.validate(reqBody);
        const valid = error == null;

        if (valid) {
            return { isValidRequest: true };
        } else {
            const { details } = error;
            const message = details.map(i => i.message).join(',');
            return { isValidRequest: false, error: message };
        }
    } else {
        return { isValidRequest: false, error: 'Invalid request.' };
    }
}

const user = Joi.object({
    firstName: Joi.string().required().trim(),
    lastName: Joi.string().required().trim(),
    email: Joi.string().email().required().trim(),
    userName: Joi.string().required().trim(),
    phone: Joi.string().regex(/^[0-9]{10}$/).messages({ 'string.pattern.base': `Phone number must have 10 digits.` }).required(),
    country: Joi.string().required(),
    state: Joi.string().required(),
    city: Joi.string().required(),
    address: Joi.string().required(),
    password: Joi.string()
        .min(8)
        .max(30)
        .label('Password')
        .regex(/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?!.* ).{8,30}$/,
            'password').required().messages({
                'string.base': `"{{#label}}" should be a type of 'string'.`,
                'string.empty': `"{{#label}}" cannot be empty.`,
                'any.required': `"{{#label}}" is a required.`
            }),
    gender: Joi.string().required().valid('Male', 'Female'),
    dateOfBirth: Joi.string().required().trim(),
    travelDistanceUpto: Joi.string().required().trim().valid('25','50','100','300','300+'),
    lattitude: Joi.string().required().trim(),
    longitude: Joi.string().required().trim(),
    fcmDeviceToken: Joi.string().optional().trim()
});

const editProfile = Joi.object({
    firstName: Joi.string().optional().trim(),
    lastName: Joi.string().optional().trim(),
    userName: Joi.string().optional().trim(),
    country: Joi.string().optional().trim(),
    state: Joi.string().optional().trim(),
    city: Joi.string().optional().trim(),
    address: Joi.string().optional().trim(),
    aboutme: Joi.string().optional().trim().min(100).max(250).label('About me').messages({
        'string.base': `"{{#label}}" should be a type of 'string'.`,
        'string.empty': `"{{#label}}" cannot be empty.`,
        'any.required': `"{{#label}}" is a required.`,
    }),
    travelDistanceUpto: Joi.string().required().trim().valid('25','50','100','300','300+'),
    lattitude: Joi.string().optional().trim(),
    longitude: Joi.string().optional().trim()
}).min(1).message("Please provide atleast one field.");

const resetPassword = Joi.object({
    oldPassword: Joi.string().required(),
    newPassword: Joi.string()
        .min(8)
        .max(30)
        .label('Password')
        .regex(/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?!.* ).{8,30}$/,
            'password').required().messages({
                'string.base': `"{{#label}}" should be a type of 'string'.`,
                'string.empty': `"{{#label}}" cannot be empty.`,
                'any.required': `"{{#label}}" is a required.`
            })
});

const uploadImage = Joi.object({
    userId: Joi.string().required().trim(),
    isProfileImage: Joi.boolean().required(),
    imageBuffer: Joi.string().required().trim(),
    imageName: Joi.string().required().trim(),
    imageType: Joi.string().required().trim()
});

const deleteImage = Joi.object({
    userId: Joi.string().required().trim(),
    imageName: Joi.string().required().trim()
});

const changeProfilePicture = Joi.object({
    imageName: Joi.string().required().trim()
});

const getSubscriptionList = Joi.object({
    planId: Joi.string().optional().trim()
});

const createSubscription = Joi.object({
    customerId: Joi.string().required().trim(),
    priceId: Joi.string().required().trim(),
    coupon: Joi.string().optional().allow('').trim(),
    couponCode: Joi.string().optional().allow('').trim()
});

const cancelSubscription = Joi.object({
    subscriptionId: Joi.string().required().trim(),
    reason: Joi.string().required().allow('').trim()
});

const attachPaymentMethod = Joi.object({
    customerId: Joi.string().required().trim(),
    paymentMethodId: Joi.string().required().trim()
});

const chatbotAnswer = Joi.object({
    userId: Joi.string().required().trim(),
    questionId: Joi.string().required().trim(),
    answerType: Joi.string().required().trim(),
    answer: Joi.string().optional().allow(''),
    optionId: Joi.string().when('answer', {
        is: "",
        then: Joi.string().required(),
        otherwise: Joi.string().optional().allow('')
    })
});

const getChatIdentity = Joi.object({
    participant1: Joi.string().required().trim(),
    participant2: Joi.string().required().trim()
});

const sendOTP = Joi.object({
    email: Joi.string().email().when('phone', {
        is: Joi.exist(),
        then: Joi.optional()
    }),
    phone: Joi.string().regex(/^[0-9]{10}$/).messages({ 'string.pattern.base': `Phone number must have 10 digits.` }),
    countryCode: Joi.string().when('phone', {
        is: Joi.exist(),
        then: Joi.required()
    }),
    fullName: Joi.string().optional(),
    reqFrom: Joi.string().optional().valid('register', 'forgotPassword')
});

const verifyOTP = Joi.object({
    email: Joi.string().email().optional().trim(),
    phone: Joi.string().optional().regex(/^[0-9]{10}$/).messages({ 'string.pattern.base': `Phone number must have 10 digits.` }),
    OTP: Joi.string().required().trim(),
    userStatus: Joi.string().optional().trim(),
    userId: Joi.string().optional().trim()
}).min(2).message("Please provide at least two fields.");

const forgotPassword = Joi.object({
    email: Joi.string().email().optional().trim(),
    phone: Joi.string().optional().regex(/^[0-9]{10}$/).messages({ 'string.pattern.base': `Phone number must have 10 digits.` }),
    newPassword: Joi.string()
        .min(8)
        .max(30)
        .label('Password')
        .regex(/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?!.* ).{8,30}$/,
            'password').required().messages({
                'string.base': `"{{#label}}" should be a type of 'string'.`,
                'string.empty': `"{{#label}}" cannot be empty.`,
                'any.required': `"{{#label}}" is a required.`
            })
}).min(2).message("Please provide at least two fields.");

const cardDetails = Joi.object({
    cardNumber: Joi.string().required().trim(),
    expMonth: Joi.number().required(),
    expYear: Joi.number().required(),
    cvc: Joi.string().required().trim()
});

const upgradeSubscription = Joi.object({
    subscriptionId: Joi.string().required().trim(),
    newProductId: Joi.string().required().trim(),
    quantity: Joi.number().required(),
    subscriptionName: Joi.string().optional().trim(),
});

const appRule = Joi.object({
    appRuleType: Joi.string().required().trim().valid('PrivacyPolicy', 'HelpAndSupport', 'AboutUs', 'TermsAndCondition', 'SecurityPolicy')
});

const updateSubscriptionInfo = Joi.object({
    subscriptionId: Joi.string().required().trim(),
    newStatus: Joi.string().required().trim(),
    prevStatus: Joi.string().required().trim(),
    subscriptionName: Joi.string().required().trim(),
    price: Joi.string().required().trim()
});

const saveChatHistory = Joi.object({
    lastMsg: Joi.string().required().trim(),
    lastMsgAt: Joi.string().isoDate().required().trim(),
    participant1UserId: Joi.string().required().trim(),
    participant2UserId: Joi.string().required().trim(),
    conversationId: Joi.string().optional().trim(),
    watermark: Joi.string().optional().trim()
});

const login = Joi.object({
    userName: Joi.string().required().trim(),
    password: Joi.string().required().trim(),
    deviceType: Joi.string().required().trim(),
    fcmDeviceToken: Joi.string().required().trim()
});

const giveFeedback = Joi.object({
    positiveFeedback: Joi.array().required(),
    negativeFeedback: Joi.array().required(),
    neutralFeedback: Joi.array().required(),
    partnerUserId: Joi.string().required().trim(),
    userId: Joi.string().required().trim(),
    tellUsMoreAboutDate: Joi.string().required().allow('').trim(),
    wantToGoOnSecondDate: Joi.boolean().required()
});

const getPartnerProfile = Joi.object({
    partnerUserId: Joi.string().required().trim()
});

const myFeedback = Joi.object({
    feedbackType: Joi.string().required().trim().valid('given', 'received')
});

const validateCoupon = Joi.object({
    couponCode: Joi.string().required().trim()
});

const getUserListForAdmin = Joi.object({
    name: Joi.string().optional().trim(),
    email: Joi.string().email().optional().trim(),
    gender: Joi.string().optional().valid('Male', 'Female'),
    userStatus: Joi.string().optional().trim().valid('active', 'inactive'),
    page: Joi.number().required(),
    pageSize: Joi.number().optional()
});

const getNextQuestionForChatbot = Joi.object({
    quesSequenceId: Joi.number().optional(),
    quesId: Joi.string().optional().trim(),
    answer: Joi.string().optional()
});

const getMatchDateDetails = Joi.object({
    partnerUserId: Joi.string().required().trim()
});

const postScheduleDateDetails = Joi.object({
    partnerUserId: Joi.string().required().trim(),
    meetStatus: Joi.string().required().trim().valid('Initiate', 'Accept', 'Suggest', 'Decline'),
    suggestedDateTime: Joi.date().iso().required(),
    suggestedMeetLocation: Joi.string().required().trim(),
    dateNumber: Joi.number().required()
});

const updateUserInfoByAdmin = Joi.object({
    userStatus: Joi.string().required().trim().valid('active', 'inactive', 'delete'),
    userId: Joi.string().required().trim()
});

const postMatchAcceptDecline = Joi.object({
    partnerUserId: Joi.string().required().trim(),
    userId: Joi.string().required().trim(),
    status: Joi.string().required().trim().valid('accept', 'reject'),
    reason: Joi.string().allow('')
});

const updateNotificationReadFlag = Joi.object({
    notificationId: Joi.string().required()
});

const deleteNotifications = Joi.object({
    notificationId: Joi.string().optional()
});

const downloadUserReport = Joi.object({
    startDate: Joi.string().required(),
    endDate: Joi.string().required()
});

const existUsername = Joi.object({
    userName: Joi.string().required().trim(),
    email: Joi.string().required().trim(),
    phone: Joi.string().required().trim()
});

export {
    validateRequest, user, editProfile, resetPassword, uploadImage, deleteImage, changeProfilePicture, chatbotAnswer, getChatIdentity,
    getSubscriptionList, createSubscription, cancelSubscription, attachPaymentMethod, sendOTP, verifyOTP, forgotPassword,
    cardDetails, upgradeSubscription, appRule, updateSubscriptionInfo, saveChatHistory, login, giveFeedback, getPartnerProfile, myFeedback, validateCoupon,
    getUserListForAdmin, getMatchDateDetails, postScheduleDateDetails, updateUserInfoByAdmin, postMatchAcceptDecline, updateNotificationReadFlag,
    deleteNotifications, downloadUserReport, existUsername
};
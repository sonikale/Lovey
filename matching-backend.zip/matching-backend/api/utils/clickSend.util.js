import api from '../node_modules/clicksend/api.js';
import createError from 'http-errors';

export async function SendSMS(context, smsDetails) {
    try {
        const smsApi = new api.SMSApi(process.env['CLICKSEND_USERNAME'], process.env['CLICKSEND_API_KEY']);
        let smsMessage = new api.SmsMessage();

        smsMessage.source = smsDetails.source
        smsMessage.to = smsDetails.to;
        smsMessage.body = smsDetails.body;

        let smsCollection = new api.SmsMessageCollection();
        smsCollection.messages = [smsMessage];

        const smsSendPostRes = await smsApi.smsSendPost(smsCollection);
        if(smsSendPostRes.body && smsSendPostRes.body.http_code == 200){
            context.log("Successfully sent SMS. Details: ", smsDetails);
        } else {
            context.log(`SMS not sent. Details: ${smsDetails}. smsSendPostRes: ${smsSendPostRes}`);
        }
        return smsSendPostRes;
    } catch (err) {
        context.log("Error while sending SMS. Details: ", smsDetails);
        throw createError[500]("Error while sending SMS. Please try again.");
    }
}

import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import imageModel from '../models/image.model.js';
import * as schema from '../utils/schema.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("ChangeProfilePicture API START");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.changeProfilePicture, req.body);
            if (validSchema.isValidRequest) {
                await imageModel.update({ isProfileImage: false }, { where: { userId: validateTokenResult.userDetails.dataValues.id, isProfileImage: true } })
                await imageModel.update({ isProfileImage: true }, { where: { userId: validateTokenResult.userDetails.dataValues.id, imageName: req.body.imageName } });
                context.log('Profile picture changed successfully for userId:', validateTokenResult.userDetails.dataValues.id, ' Image Name:', req.body.imageName);
                result = successResponse("Profile picture changed successfully.", {}, StatusCodes.OK);
            } else {
                context.log('Invalid Schema. Details:', validSchema.error);
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("ChangeProfilePicture API Error. Details:", error);
        result = errorResponse('Something went wrong while changing profile your picture. Please contact support', StatusCodes.EXPECTATION_FAILED);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
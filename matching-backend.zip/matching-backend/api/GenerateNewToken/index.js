import { StatusCodes } from 'http-status-codes';
import User from '../models/user.model.js';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { createJwtToken } from '../utils/token.util.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("GenerateNewToken API Start");
        let token = createJwtToken({ email: req.body.email });
        let tokenDetails = {
            token,
            email: req.body.email
        }
        await User.update({ jwttoken: token }, { where: { email: req.body.email } });
        context.log("Succesfully generated new token for email:", req.body.email);
        result = successResponse("Succesfully generated new token.", tokenDetails, StatusCodes.OK);
    } catch (error) {
        context.log("catch-error" + error);
        result = errorResponse('Something went wrong. Please contact admin.', StatusCodes.EXPECTATION_FAILED);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
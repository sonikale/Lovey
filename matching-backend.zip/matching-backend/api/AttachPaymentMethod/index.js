import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as stripe from '../utils/stripe/stripe.js';
import * as schema from '../utils/schema.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Attach payment method API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.attachPaymentMethod, req.body);
            if (validSchema.isValidRequest) {
                const customer = await stripe.attachAndUpdateCustomerPaymentMethod(req.body.paymentMethodId, req.body.customerId);
                context.log('Payment method attached successfully for userId:', validateTokenResult.userDetails.dataValues.id);
                result = successResponse("Payment method attached successfully.", customer, StatusCodes.OK);
            } else {
                context.log('Invalid Schema. Details:', validSchema.error);
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Attach payment method API Error: " + error);
        result = errorResponse('Something went wrong while attaching the payment method Please contact support.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as chatUtility from '../utils/chat.util.js';
import * as schema from '../utils/schema.js';
import moment from 'moment';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Save chat history API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.saveChatHistory, req.body);
            if (validSchema.isValidRequest) {
                req.body.lastMsgAt = moment(req.body.lastMsgAt).format('YYYY-MM-DD HH:mm:ss.000');
                const updateResult = await chatUtility.updateChatHistory(req.body, context, validateTokenResult.userDetails.dataValues);
                context.log('Chat history updated successfully. Details:', req.body);
                result = successResponse("Chat history updated successfully.", { updateResult }, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Save chat history API Error:" + error);
        result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong while Saving chat history. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
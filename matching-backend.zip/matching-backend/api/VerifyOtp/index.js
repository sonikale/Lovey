import { StatusCodes } from 'http-status-codes';
import OTP from '../models/otp.model.js';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import httpError from "http-errors";
import * as schema from '../utils/schema.js';
import Users from '../models/user.model.js';
import { createJwtToken } from '../utils/token.util.js';
import sequelize from 'sequelize';
import * as constants from '../core/constants.js';

export default async function (context, req) {
  let result = "";
  try {
    context.log("Verify OTP API START");
    const validSchema = schema.validateRequest(schema.verifyOTP, req.body);

    if (validSchema.isValidRequest) {
      let otpDetails;
      let searchCriteria = { otp: req.body.OTP };

      if (req.body.email) {
        searchCriteria.email = req.body.email;
      } else {
        searchCriteria.phone = req.body.phone;
      }

      otpDetails = await OTP.findOne({ where: searchCriteria });
      if (!otpDetails) {
        throw httpError.Conflict("Incorrect OTP.");
      }

      // admin 2 factor auth
      if (req.body.userStatus == 'admin' && req.body.userId) {
        const user = await Users.findOne({ where: { id: req.body.userId } });
        if (!user) {
          throw httpError.Conflict(constants.messages.LOGIN_ERROR);
        }
        let loginPayload = { userId: user.id, userStatus: 'admin', twoFactorAuth: 'success' };

        context.log("Generating new jwt token for admin in verify otp API .");
        loginPayload.token = createJwtToken({ email: user.email });

        await Users.update({ jwttoken: loginPayload.token, lastlogin: sequelize.literal('CURRENT_TIMESTAMP'), fcmDeviceToken: req.body.fcmDeviceToken, deviceType: req.body.deviceType }, { where: { id: user.id } });
        context.log("Login successful for user.userId: ", user.id);
        result = successResponse("OTP Verfied Successfully", loginPayload, StatusCodes.OK);
      } else {
        context.log("OTP Verfied Successfully for request: ", req.body);
        result = successResponse("OTP Verfied Successfully", {}, StatusCodes.OK);
      }
    } else {
      context.log('Invalid Schema. Details:', validSchema.error);
      result = validationResponse(validSchema.error);
    }
  } catch (error) {
    context.log(`Verify OTP API error for request ${req.body}. Details: ${error}`);
    result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong while verifying OTP. Please contact admin.', StatusCodes.BAD_REQUEST);
  }

  context.res = {
    status: result.statusCode,
    body: result
  }
}
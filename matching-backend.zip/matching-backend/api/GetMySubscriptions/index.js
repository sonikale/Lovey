import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as stripe from '../utils/stripe/stripe.js';
import subscriptionModel from '../models/custSubscription.model.js';
import * as constants from '../core/constants.js';
import { Op, QueryTypes } from 'sequelize';
import sequelize from "../db/db.connect.js";
import { verifyPurchaseWithApple } from '../utils/getInPurchaseReceipt.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get my subscriptions API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            let mySubscriptionObj = {
                productList: await stripe.getProductList()
            }
            await Promise.all(mySubscriptionObj.productList.map(async (product) => {
                return product.priceDetails = await stripe.getProductPrice(product.id);
            }));
            const subscriptionDetails = await subscriptionModel.findOne({ where: { userId: validateTokenResult.userDetails.dataValues.id, subscriptionStatus: 'active' } });
            if (subscriptionDetails) {
                mySubscriptionObj.activeSubscription = await stripe.getActiveSubscription(context, subscriptionDetails.customerId);
            } else {
                mySubscriptionObj.activeSubscription = {};
            }
            if(req.query.deviceType==="ios"){
                let iosdata = await sequelize.query(`SELECT "userId","receipt" FROM "appleReceipt" where "userId" = '${validateTokenResult.userDetails.dataValues.id}' ;`, { type: QueryTypes.SELECT });
                if (iosdata && iosdata.length > 0) {
                mySubscriptionObj.receiptPurchase = await verifyPurchaseWithApple(iosdata[0].receipt, validateTokenResult.userDetails.dataValues.id, req.query.deviceType);
                }
            }
            const couponList = await stripe.getCouponList();
            const finalCouponList = await stripe.getUnusedCouponList(validateTokenResult.userDetails.dataValues.id, couponList);
            mySubscriptionObj.couponList = finalCouponList;
            mySubscriptionObj.profileCompleted = validateTokenResult.userDetails.dataValues.profileCompleted;
            context.log('Fetched my subscription list successfully. Details: ', validateTokenResult.userDetails.dataValues.id);
            result = successResponse(`${constants.messages.My_SUBSCRIPTION_SUCCESS}`, mySubscriptionObj, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get my subscriptions API Error: " + error);
        result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong while getting my subscriptions. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import * as stripe from '../utils/stripe/stripe.js';
import * as constants from '../core/constants.js'
import custSubscriptionModel from '../models/custSubscription.model.js';
import { inAppMessages } from '../templates/SMSEmailTemplates.js';
import { createInAppNotification } from '../utils/notifications.js';
import { runAlgorithm } from '../utils/ruleEngine.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Upgrade Subscription  API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.upgradeSubscription, req.body);
            if (validSchema.isValidRequest) {
                const subscription = await stripe.upgradeSubscription(context, req.body);

                const upgradeMsg = `Subscription has been upgraded to product id: ${req.body.newProductId}`;
                let subscriptionPayload = {
                    userId: validateTokenResult.userDetails.dataValues.id,
                    customerId: subscription.customer,
                    subscriptionId: subscription.id,
                    productId: req.body.newProductId,
                    couponId: req.body.coupon ? req.body.coupon : '',
                    couponCode: req.body.couponCode ? req.body.couponCode : '',
                    subscriptionStatus: subscription.status,
                    subscriptionEndDate: new Date(subscription.current_period_end * 1000),
                    message: constants.messages.SUBSCRIPTION_UPGRADED
                }

                await custSubscriptionModel.update({ subscriptionStatus: 'soft_delete', message: upgradeMsg }, { where: { subscriptionId: req.body.subscriptionId } });
                await custSubscriptionModel.create(subscriptionPayload);
                // in app notification
                const inAppNotificationInsertPayload = {
                    fromUserId: validateTokenResult.userDetails.dataValues.id,
                    toUserId: validateTokenResult.userDetails.dataValues.id,
                    isRead: false,
                    notificationTitle: inAppMessages.upgradepurchaseSubscriptionTitle,
                    notificationText: inAppMessages.upgradeSubscriptionMsg.replace('{{Plan Name}}', req.body.subscriptionName)
                }
                createInAppNotification(inAppNotificationInsertPayload);
                if (validateTokenResult.userDetails.dataValues.gender === "Female") {
                    runAlgorithm(context, validateTokenResult.userDetails.dataValues.id);
                } context.log('Subscription upgraded successfully. Details:', subscription);
                result = successResponse("Subscription upgraded successfully", subscription, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Upgrade Subscription API Error: " + error);
        result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong while upgrading subscription. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
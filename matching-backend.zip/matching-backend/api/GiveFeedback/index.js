import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import feedbackModel from '../models/feedback.model.js';
import User from '../models/user.model.js';
import { sendPushNotification } from '../utils/fcm.js'
import { messages } from '../templates/SMSEmailTemplates.js';
import * as clickSend from '../utils/clickSend.util.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Give Feedback API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.giveFeedback, req.body);
            if (validSchema.isValidRequest) {
                req.body.positiveFeedback = JSON.stringify(req.body.positiveFeedback);
                req.body.negativeFeedback = JSON.stringify(req.body.negativeFeedback);
                req.body.neutralFeedback = JSON.stringify(req.body.neutralFeedback);

                const feedbackExist = await feedbackModel.findOne({ where: { userId: req.body.userId, partnerUserId: req.body.partnerUserId } });
                if (feedbackExist) {
                    await feedbackModel.update(req.body, { where: { userId: req.body.userId, partnerUserId: req.body.partnerUserId } });
                    context.log('Feedback updated successfully. Details:', req.body);
                } else {
                    await feedbackModel.create(req.body);
                    context.log('Feedback added successfully. Details:', req.body);
                }

                // send push notification to partner
                const partnerDetails = await User.findOne({ where: { id: req.body.partnerUserId } });
                let userDetails = { screen: 'feedback', partnerUserId: req.body.partnerUserId };

                const pushMotificationBody = {
                    fcmDeviceToken: partnerDetails.fcmDeviceToken,
                    userDetails,
                    title: messages.feedbackPNTitle,
                    body: messages.feedbackPNMsg.replace('{{partnerUserName}}', validateTokenResult.userDetails.dataValues.firstName)
                };
                sendPushNotification(context, pushMotificationBody);

                // Send SMS to partner
                let sendSMSObj = {
                    to: process.env["COUNTRY_CODE"] + partnerDetails.phone,
                    body: messages.feedbackTxtMsg.replace('{{partnerUserName}}', validateTokenResult.userDetails.dataValues.firstName)
                }

                await clickSend.SendSMS(context, sendSMSObj);
                result = successResponse("Feedback added successfully", {}, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Give Feedback API Error: " + error);
        result = errorResponse('Something went wrong while adding feedback. Please contact admin.', StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
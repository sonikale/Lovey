import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import * as chatUtility from '../utils/chat.util.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get chat Identity API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.getChatIdentity, req.body);
            if (validSchema.isValidRequest) {
                let chatIdentityObj = {
                    participant1: {},
                    participant2: {},
                    threadId: ''
                }

                chatIdentityObj.participant1 = await chatUtility.getChatIdentity(context, req.body.participant1);
                chatIdentityObj.participant2 = await chatUtility.getChatIdentity(context, req.body.participant2);
                chatIdentityObj.threadId = await chatUtility.getChatThreadId(context, chatIdentityObj);

                context.log('Chat identity fetched successfully for request:', req.body);
                result = successResponse("Chat identity fetched successfully.", chatIdentityObj, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get chat Identity API Error:" + error);
        result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong while getting your chat identity. Please contact support.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
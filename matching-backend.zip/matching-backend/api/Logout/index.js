import { StatusCodes } from 'http-status-codes';
import User from '../models/user.model.js';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { messages } from '../core/constants.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Logout API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            await User.update({ jwttoken: null }, { where: { id: validateTokenResult.userDetails.dataValues.id } });
            context.log("Logout successful for user id: ", validateTokenResult.userDetails.dataValues.id );
            result = successResponse(messages.LOGOUT_SUCCESS, {}, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Logout API Error:" + error);
        result = errorResponse((error.message.length > 0) ? error.message : messages.LOGOUT_ERROR, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
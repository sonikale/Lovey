import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { messages } from '../core/constants.js';
import { getMyMatches } from '../utils/matches.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get my matches API Start");
        const validateTokenResult = await validateToken(context, req);
        console.log("validateTokenResult", validateTokenResult)

        if (!validateTokenResult.error) {
            // TO DO: change logic. For testing purpose getting opposite gender list
            const matchesList = await getMyMatches(context, validateTokenResult.userDetails.dataValues);
            console.log("matchesList", matchesList)
            if (matchesList.data.length > 0) {
                context.log(`${messages.GET_MY_MATCHES_SUCCESS} for user id: ${validateTokenResult.userDetails.dataValues.id}`);
                result = successResponse(messages.GET_MY_MATCHES_SUCCESS, matchesList, StatusCodes.OK);
            } else {
                result = successResponse(messages.NO_DATA_FOUND, matchesList, StatusCodes.OK);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get my matches  API Error: " + error);
        result = errorResponse(messages.GET_MY_MATCHES_ERROR, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
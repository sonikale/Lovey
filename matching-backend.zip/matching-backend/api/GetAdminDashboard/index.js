import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { getAdminDashboard } from '../utils/common.util.js';
import { messages } from '../core/constants.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get Admin dashboard API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const adminDashboard = await getAdminDashboard(validateTokenResult.userDetails.dataValues.id);
            context.log("Fetched admin dashboard details Successfully.");
            result = successResponse(messages.GET_ADMIN_DASHBOARD_SUCCESS, adminDashboard, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get Admin dashboard API Error: " + error);
        result = errorResponse(messages.GET_ADMIN_DASHBOARD_ERROR, StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
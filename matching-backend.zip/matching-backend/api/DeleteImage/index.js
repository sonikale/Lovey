import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import imageModel from '../models/image.model.js';
import * as schema from '../utils/schema.js';
import { validateToken } from '../utils/token.util.js';
import { getAzureBlobClient } from '../utils/azure.util.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Delete Image API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.deleteImage, req.body);
            if (validSchema.isValidRequest) {
                const blockBlobClient = await getAzureBlobClient(req.body.imageName);
                await blockBlobClient.deleteIfExists({deleteSnapshots: 'include'})
                    .then(async (res) => {
                        await imageModel.destroy({ where: { imageName: req.body.imageName, userId: req.body.userId } });
                        context.log('Deleted photo:', req.body.imageName, '  for userId:', req.body.userId);
                        result = successResponse("Photo Deleted Successfully.", {}, StatusCodes.OK);
                    }).catch((err) => {
                        context.log('Error while deleting image:', req.body.imageName, ' for userId:', req.body.userId, ' Details:', err);
                        result = errorResponse('Error while deleting your photo. Please try again.', StatusCodes.EXPECTATION_FAILED);
                    });

            } else {
                context.log('Invalid Schema. Details:', validSchema.error);
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Delete Image API Error: " + error);
        result = errorResponse('Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
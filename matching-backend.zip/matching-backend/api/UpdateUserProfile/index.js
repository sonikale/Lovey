import { StatusCodes } from 'http-status-codes';
import User from '../models/user.model.js';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import createError from 'http-errors';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import { Op } from 'sequelize';
import * as emailService from '../utils/emailService.js';
import * as smsTemplate from '../templates/SMSEmailTemplates.js';
import { messages } from '../core/constants.js';

export default async function (context, req) {
  let result = "";

  try {
    context.log("Update User Profile API START");

    const validateTokenResult = await validateToken(context, req);

    if (!validateTokenResult.error) {
      const userData = validateTokenResult.userDetails.dataValues;
      const validSchema = schema.validateRequest(schema.editProfile, req.body);
      if (validSchema.isValidRequest) {
        if (req.body.userName) {
          const userNameExist = await User.findOne({ where: { userName: req.body.userName, email: { [Op.ne]: validateTokenResult.userDetails.dataValues.email } } });
          if (userNameExist) throw createError.Conflict(messages.USERNAME_EXISTS);
        }
        await User.update(req.body, { where: { email: validateTokenResult.userDetails.dataValues.email } });

        let emailPayload = {
          toEmail: validateTokenResult.userDetails.dataValues.email,
          toName: validateTokenResult.userDetails.dataValues.firstName + ' ' + validateTokenResult.userDetails.dataValues.lastName
        }

        if (req.body.userName != userData.userName) {
          emailPayload.subject = smsTemplate.messages.editUserNameSubject;
          emailPayload.mailBody = smsTemplate.messages.editUserNameBody.replace('{{Users Name}}', userData.firstName + ' ' + userData.lastName).replace('{{Old Username}}', userData.userName).replace('{{New Username}}', req.body.userName);
          emailService.sendMail(context, emailPayload);
        }

        if (req.body.address != userData.address) {
          emailPayload.subject = smsTemplate.messages.editAddressSubject;
          emailPayload.mailBody = smsTemplate.messages.editAddressBody.replace('{{Users Name}}', userData.firstName + ' ' + userData.lastName).replace('{{Old Address}}', userData.address).replace('{{New Address}}', req.body.address);
          emailService.sendMail(context, emailPayload);
        }

        if (req.body.city != userData.city) {
          emailPayload.subject = smsTemplate.messages.editCitySubject;
          emailPayload.mailBody = smsTemplate.messages.editCityBody.replace('{{Users Name}}', userData.firstName + ' ' + userData.lastName).replace('{{Old City}}', userData.city).replace('{{New City}}', req.body.city);
          emailService.sendMail(context, emailPayload);
        }

        context.log('Profile updated successfully. Email:', validateTokenResult.userDetails.dataValues.email);
        result = successResponse("Profile updated successfully.", req.body, StatusCodes.OK);
      } else {
        result = validationResponse(validSchema.error);
      }
    } else {
      result = validateTokenResult;
    }
  } catch (error) {
    context.log("Update User Profile API error: " + error);
    result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
  }

  context.res = {
    status: result.statusCode,
    body: result
  }
}
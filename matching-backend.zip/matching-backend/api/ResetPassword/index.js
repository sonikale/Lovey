import { StatusCodes } from 'http-status-codes';
import User from '../models/user.model.js';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import bcryptjs from 'bcryptjs';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';
import { messages } from '../core/constants.js';
import * as clickSend from '../utils/clickSend.util.js';
import * as smsTemplate from '../templates/SMSEmailTemplates.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Reset Password API START");

        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.resetPassword, req.body);
            if (validSchema.isValidRequest) {
                const isSame = await bcryptjs.compare(req.body.oldPassword, validateTokenResult.userDetails.dataValues.password);
                if (isSame) {
                    if (req.body.oldPassword == req.body.newPassword) {
                        result = errorResponse(messages.RESET_PASSWORD_WITH_SAME_PASSWORD_ERROR, StatusCodes.BAD_REQUEST);
                    } else {
                        let encryptedPassword = await bcryptjs.hash(req.body.newPassword, 10);
                        await User.update({ password: encryptedPassword, jwttoken: null }, { where: { email: validateTokenResult.userDetails.dataValues.email } });
                        let sendSMSObj = {
                            to: process.env["COUNTRY_CODE"] + validateTokenResult.userDetails.dataValues.phone,
                            body: smsTemplate.messages.resetPasswordTxtMsg.replace('{{Users Name}}', validateTokenResult.userDetails.dataValues.firstName)
                        }

                        clickSend.SendSMS(context, sendSMSObj);
                        context.log('Password updated successfully for email:', validateTokenResult.userDetails.dataValues.email);
                        result = successResponse(messages.RESET_PASSWORD_SUCCESS, {}, StatusCodes.OK);
                    }
                } else {
                    context.log("Reset Password-> Invalid current password for Email: ", validateTokenResult.userDetails.dataValues.email);
                    result = errorResponse(messages.RESET_PASSWORD_DOES_NOT_MATCH, StatusCodes.BAD_REQUEST);
                }
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Reset Password API error: " + error);
        result = errorResponse('Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
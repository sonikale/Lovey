import { StatusCodes } from 'http-status-codes';
import OTP from '../models/otp.model.js';
import { generateOTP } from "../utils/otp.util.js";
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import * as schema from '../utils/schema.js';
import * as clickSend from '../utils/clickSend.util.js';
import * as emailService from '../utils/emailService.js';
import * as smsTemplate from '../templates/SMSEmailTemplates.js';
import * as constants from '../core/constants.js';
import User from '../models/user.model.js';
import createError from 'http-errors';

export default async function (context, req) {
  let result = "";

  try {
    context.log("Send OTP API START");
    const validSchema = schema.validateRequest(schema.sendOTP, req.body);
    if (validSchema.isValidRequest) {
      let phoneExist;
      if ((req.body.reqFrom == "register" || req.body.reqFrom == "forgotPassword") && req.body.phone) {
        phoneExist = await User.findOne({ where: { phone: req.body.phone } });
        // TO DO: Commented below lines for testing purpose. Need to revert later
        // if (phoneExist && req.body.reqFrom == "register") throw createError.Conflict(constants.messages.PHONE_EXISTS);
        if (!phoneExist && req.body.reqFrom == "forgotPassword") throw createError.Conflict(constants.messages.USER_NOT_EXIST);
      }

      if (req.body.reqFrom = "forgotPassword" && req.body.email) {
        const emailExist = await User.findOne({ where: { email: req.body.email } });
        if (!emailExist) throw createError.Conflict(constants.messages.USER_NOT_EXIST);
      }

      let otpPayload = {
        email: req.body.email,
        phone: req.body.phone,
        otp: generateOTP()
      }

      let searchCriteria = {};
      if (otpPayload.email) {
        searchCriteria.email = otpPayload.email;
      } else {
        searchCriteria.phone = otpPayload.phone;
      }

      await OTP.destroy({ where: searchCriteria });
      await OTP.create(otpPayload);

      if (otpPayload.phone) {
        let sendSMSObj = {
          to: req.body.countryCode + otpPayload.phone,
          body: smsTemplate.messages.phoneVerifyBody.replace('{{OTPCode}}', otpPayload.otp)
        }

        if (req.body.reqFrom == "forgotPassword") {
          sendSMSObj.body = smsTemplate.messages.forgotpassTxtMsg.replace('{{OTPCode}}', otpPayload.otp).replace('{{Users Name}}', phoneExist.firstName)
        }

        const res = await clickSend.SendSMS(context, sendSMSObj);
        if (res.body.http_code == 200) {
          result = successResponse(constants.messages.OTP_SENT, {}, StatusCodes.OK);
        } else {
          result = errorResponse("OTP not sent. Please try again.", StatusCodes.INTERNAL_SERVER_ERROR);
        }
      } else {
        const emailPayload = {
          subject: smsTemplate.messages.sendOTPEmailSubject,
          mailBody: smsTemplate.messages.sendOTPEmailBody.replace('{{OTPCode}}', otpPayload.otp),
          toEmail: otpPayload.email,
          toName: req.body.fullName ? req.body.fullName : otpPayload.email
        }

        const res = await emailService.sendMail(context, emailPayload);
        if (res.statusCode == StatusCodes.OK) {
          result = successResponse(constants.messages.OTP_SENT, {}, StatusCodes.OK);
        } else {
          result = errorResponse(constants.messages.OTP_SENT_ERROR, {}, StatusCodes.INTERNAL_SERVER_ERROR);
        }
      }
    } else {
      context.log('Invalid Schema. Details:', validSchema.error);
      result = validationResponse(validSchema.error);
    }
  } catch (error) {
    context.log(`Error while sending OTP. for request: ${req.body} Details: ${error}`);
    result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
  }

  context.res = {
    status: result.statusCode,
    body: result
  }
}
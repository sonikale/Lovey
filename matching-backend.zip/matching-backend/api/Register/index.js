import { StatusCodes } from 'http-status-codes';
import bcryptjs from 'bcryptjs';
import User from '../models/user.model.js';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import createError from 'http-errors';
import * as schema from '../utils/schema.js';
import * as emailService from '../utils/emailService.js';
import * as smsTemplate from '../templates/SMSEmailTemplates.js';
import * as constants from '../core/constants.js';
import { calculateAge } from '../utils/common.util.js';
import moment from 'moment';
import { createInAppNotification } from '../utils/notifications.js';
import { sendPushNotification } from '../utils/fcm.js'

export default async function (context, req) {
  let result = "";

  try {
    context.log("Register API START");
    const validSchema = schema.validateRequest(schema.user, req.body);

    if (validSchema.isValidRequest) {
      req.body.dateOfBirth = new Date(req.body.dateOfBirth);
      const age = await calculateAge(req.body.dateOfBirth);
      if (age < 18) throw createError[StatusCodes.BAD_REQUEST](constants.messages.INVALID_AGE);

      const emailExist = await User.findOne({ where: { email: req.body.email } });
      if (emailExist) throw createError.Conflict(constants.messages.EMAIL_EXISTS);

      const userNameExist = await User.findOne({ where: { userName: req.body.userName } });
      if (userNameExist) throw createError.Conflict(constants.messages.USERNAME_EXISTS);

      // TO DO: Commented below lines for testing purpose. Need to revert later
      // const phoneExist = await User.findOne({ where: { phone: req.body.phone } });
      // if (phoneExist) throw createError.Conflict(constants.messages.PHONE_EXISTS);

      let registrationPayload = {
        ...req.body,
        age,
        password: await bcryptjs.hash(req.body.password, 10)
      }

      const user = await User.create(registrationPayload);
      delete registrationPayload.password;

      const createdDate = moment(user.createdAt).format('YYYY-MM-DD HH:mm:ss.000');

      const emailPayload = {
        subject: smsTemplate.messages.registerSuccessSubject,
        mailBody: smsTemplate.messages.registerSuccessBody.replace('{{username}}', user.userName).replace('{{email}}', user.email).replace('{{registration date}}', createdDate).replace('{{Users Name}}', user.firstName + ' ' + user.lastName),
        toEmail: req.body.email,
        toName: req.body.firstName + ' ' + req.body.lastName
      }

      emailService.sendMail(context, emailPayload);
      const inAppNotificationInsertPayload = {
        fromUserId: user.id,
        toUserId: user.id,
        isRead: false,
        notificationTitle: smsTemplate.inAppMessages.registerTitle,
        notificationText: smsTemplate.inAppMessages.registerMessage
      }
      createInAppNotification(inAppNotificationInsertPayload);

      // push notification for profile completion
      let userDetails = { screen: 'aphrodite', userId: user.id };

      let pushNotificationBody = {
        fcmDeviceToken: req.body.fcmDeviceToken,
        userDetails,
        title: smsTemplate.messages.signUpProfCompltPNTitle,
        body: smsTemplate.messages.signUpProfCompltPNMsg
      };
      sendPushNotification(context, pushNotificationBody);

      context.log('Registration Successful. Email:', registrationPayload.email);
      result = successResponse("Registration Successful.", registrationPayload, StatusCodes.OK);
    } else {
      result = validationResponse(validSchema.error);
    }
  } catch (error) {
    context.log("Register API Error. Details:", error);
    result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
  }

  context.res = {
    status: result.statusCode,
    body: result
  }
}
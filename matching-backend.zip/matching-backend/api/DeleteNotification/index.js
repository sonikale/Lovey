import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse, validationResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { deleteNotifications } from '../utils/notifications.js';
import * as schema from '../utils/schema.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("api/DeleteNotification API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.deleteNotifications, req.body);
            if (validSchema.isValidRequest) {
                await deleteNotifications(validateTokenResult.userDetails.dataValues.id, 'InApp', req.body);
                context.log('Deleted in app notifications successfully for user:', validateTokenResult.userDetails.dataValues.id);
                result = successResponse("Deleted in app notifications successfully", {}, StatusCodes.OK);
            } else {
                context.log('Invalid Schema. Details:', validSchema.error);
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("api/DeleteNotification API Error: " + error);
        result = errorResponse('Something went wrong while deleting in app notifications. Please contact admin.', StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
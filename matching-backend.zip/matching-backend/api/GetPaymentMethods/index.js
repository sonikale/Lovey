import { StatusCodes } from 'http-status-codes';
import { errorResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import stripeCustomerModel from '../models/stripeCustomer.model.js';
import { getPaymentMethodsForCustomer } from '../utils/stripe/stripe.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Get Payment Methods API Start");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            let paymentMethods = {};
            const customer = await stripeCustomerModel.findOne({ where: { userId: validateTokenResult.userDetails.dataValues.id } });
            if (customer) {
                paymentMethods = await getPaymentMethodsForCustomer(customer.customerId);
            }

            context.log('Payment methods fetched successfully. Details:', req.body);
            result = successResponse("Payment methods fetched successfully", paymentMethods, StatusCodes.OK);
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("Get Payment Methods API Error: " + error);
        result = errorResponse('Something went wrong while getting payment method. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
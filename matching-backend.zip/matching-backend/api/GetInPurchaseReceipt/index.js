import { StatusCodes } from 'http-status-codes';
import bcryptjs from 'bcryptjs';
import User from '../models/user.model.js';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import createError from 'http-errors';
import * as constants from '../core/constants.js';
import { verifyPurchaseWithApple } from '../utils/getInPurchaseReceipt.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("verify-purchase API START");

        if (req.body) {
            // const { purchaseToken, productId, platform } = req.body;
            // TODO: Verify the purchase with the respective platform's API
            const isPurchaseValid = await verifyPurchaseWithApple(req.body.receiptData,req.body.userId,req.body.deviceType);

            if (isPurchaseValid) {
                // TODO: Update user's account or grant access to the purchased content
                result = successResponse("validation Successful.", isPurchaseValid, StatusCodes.OK);
            } else {
                result = errorResponse(constants.messages.RECEIPT_ERROR, StatusCodes.BAD_REQUEST);
            }
        } else {
            result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
        }
    } catch (error) {
        context.log("verify-purchase  API Error. Details:", error);
        result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
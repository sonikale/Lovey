import { StatusCodes } from 'http-status-codes';
import chatbotAnswerModel from '../models/chatbotAnswer.model.js';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import * as schema from '../utils/schema.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("Save chatbot answers API START");

        // ------------commented authentication as request will be from chatbot----------------
        // const validateTokenResult = await validateToken(context, req);

        // if (!validateTokenResult.error) {
        const validSchema = schema.validateRequest(schema.chatbotAnswer, req.body);
        if (validSchema.isValidRequest) {
            let answerpayload = {
                ...req.body,
                optionId: req.body.optionId || null,
                answer: req.body.answer || null
            };

            context.log(`Answer Payload for userId ${req.body.userId}. Payload : ${JSON.stringify(answerpayload)}`);
            // Logic to replace saved answer in case of any failure at frontend side 
            const answerExists = await chatbotAnswerModel.findOne({ where: { userId: req.body.userId, questionId: req.body.questionId } });
            if (answerExists) {
                await chatbotAnswerModel.update({ answerpayload }, { where: { userId: req.body.userId, questionId: req.body.questionId } });
            } else {
                await chatbotAnswerModel.create(answerpayload);
            }
            context.log('Answers saved successfully. UserId:', req.body.userId);
            result = successResponse("Answers saved successfully.", req.body, StatusCodes.OK);
        } else {
            result = validationResponse(validSchema.error);
        }
        // } else {
        //     result = validateTokenResult;
        // }
    } catch (error) {
        context.log("Save chatbot answers API error: " + error);
        result = errorResponse((error.message.length > 0) ? error.message : 'Something went wrong while saving answers. Please contact admin.', StatusCodes.BAD_REQUEST);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
import { StatusCodes } from 'http-status-codes';
import { errorResponse, validationResponse, successResponse } from '../core/responseApi.js';
import { validateToken } from '../utils/token.util.js';
import { getMyFeedback } from '../utils/common.util.js';
import * as schema from '../utils/schema.js';

export default async function (context, req) {
    let result = "";

    try {
        context.log("GetMyFeedback API START");
        const validateTokenResult = await validateToken(context, req);

        if (!validateTokenResult.error) {
            const validSchema = schema.validateRequest(schema.myFeedback, req.query);
            if (validSchema.isValidRequest) {
                let myFeedback = await getMyFeedback(req.query.feedbackType, validateTokenResult.userDetails.dataValues.id);
                context.log('My feedback fetched successfully for userId:', validateTokenResult.userDetails.dataValues.id);
                result = successResponse("My feedback fetched successfully.", myFeedback, StatusCodes.OK);
            } else {
                result = validationResponse(validSchema.error);
            }
        } else {
            result = validateTokenResult;
        }
    } catch (error) {
        context.log("GetMyFeedback API Error. Details:", error);
        result = errorResponse('Something went wrong while getting the feedback. Please contact support.', StatusCodes.INTERNAL_SERVER_ERROR);
    }

    context.res = {
        status: result.statusCode,
        body: result
    }
}
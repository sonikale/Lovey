/**
 * @desc    This file contain Success and Error response for sending to client / user
 * @author  Huda Prasetyo
 * @since   2020
 */

/**
 * @desc    Send any success response
 *
 * @param   {string} message
 * @param   {object | array} results
 * @param   {number} statusCode
 */
export function successResponse(message, data, statusCode) {
  return {
    message,
    error: false,
    statusCode,
    data
  };
}

/**
 * @desc    Send any error response
 *
 * @param   {string} message
 * @param   {number} statusCode
 */
export function errorResponse(message, statusCode) {

  return {
    message,
    statusCode,
    error: true
  };
}

/**
 * @desc    Send any validation response
 *
 * @param   {object | array} errors
 */
export function validationResponse(errors) {
  return {
    message: errors,
    error: true,
    statusCode: 422
  };
}

/**
 * @desc    Send any validation response
 *
 * @param   {object | array} errors
 */
export function invalidRequestResponse(errors) {
  return {
    message: errors,
    error: true,
    statusCode: 401
  };
}
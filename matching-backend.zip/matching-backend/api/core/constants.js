const httpStatusCodes = {
    HTTP_SUCCESS: 200,
    UNAUTHORIZED: 401,
    INTERNAL_SERVER: 500,
    BAD_REQUEST: 400,
    NOT_FOUND: 404,
    CREATED: 201,
    FORBIDDEN: 403,
    UNPROCESSABLE: 422,
    LOCKED: 423,
    SERVICE_UNAVAILABLE: 503,
    CONFLICT: 409,
    CATCH_ERROR: 999
}

const messages = {
    LOGIN_SUCCESS: "Login successful",
    LOGIN_FAILED: "Something went wrong while logging in. Please contact support.",
    LOGIN_ERROR: 'Please enter valid username or password',
    RECEIPT_ERROR: 'Please enter valid receipt',
    OTP_SENT: "OTP Sent",
    OTP_SENT_ERROR: "Error while sending OTP. Please try again.",
    SUBSCRIPTION_SUCCESS: "Subscription created",
    SUBSCRIPTION_UPGRADED: "Subscription upgraded",
    SUBSCRIPTION_CANCELLED: "Subscription cancelled",
    My_SUBSCRIPTION_SUCCESS: 'Fetched my subscription list successfully.',
    USER_NOT_EXIST: "User does not exist",
    PHONE_EXISTS: "Phone number already exists, try using another phone number",
    USERNAME_EXISTS: "Username already exists, try using another username",
    EMAIL_EXISTS: "Email already exists, try using another email",
    COUPON_DETAILS_SUCCESS: "Fetched coupon details successfully",
    COUPON_DETAILS_ERROR: "Something went wrong while fetching coupon details. Please contact support.",
    LOGOUT_SUCCESS: "Logout successful",
    LOGOUT_ERROR: "Something went wrong while signing out. Please contact admin",
    INVALID_TOKEN: "Invalid Token",
    INVALID_AGE: "A minimum age of 18 years is required to use our app.",
    GET_DATE_SCHEDULE_SUCCESS: "Fetched date schedule successfully",
    GET_DATE_SCHEDULE_ERROR: "Something went wrong while getting date schedule. Please contact support.",
    USER_LIST_ADMIN_SUCCESS: "Fetched user list successfully",
    USER_LIST_ADMIN_ERROR: "Something went wrong while getting user list. Please try again.",
    GET_QUESTION_FOR_CHATBOT_SUCCESS: "Question successfully fetched.",
    GET_QUESTION_FOR_CHATBOT_ERROR: "Something went wrong while getting question. Please try again.",
    POST_DATE_SCHEDULE_SUCCESS: "Date schedule updated successfully",
    POST_DATE_SCHEDULE_ERROR: "Something went wrong while updating date details. Please try again.",
    UPDATE_USER_INFO_BY_ADMIN_SUCCESS: "Updated user information successfully",
    UPDATE_USER_ACTIVE_STATUS_BY_ADMIN_SUCCESS: "User activated successfully.",
    UPDATE_USER_INACTIVE_STATUS_BY_ADMIN_SUCCESS: "User inactivated successfully",
    UPDATE_USER_DELETE_STATUS_BY_ADMIN_SUCCESS: "User deleted successfully",
    UPDATE_USER_INFO_BY_ADMIN_ERROR: "Something went wrong while updating user information. Please try again.",
    GET_ADMIN_DASHBOARD_SUCCESS: "Fetched admin dashboard details successfully",
    GET_ADMIN_DASHBOARD_ERROR: "Something went wrong while fetching admin dashboard details. Please try again.",
    RESET_PASSWORD_WITH_SAME_PASSWORD_ERROR: "New password can not be same as old password. Please try again.",
    RESET_PASSWORD_DOES_NOT_MATCH: "Password does not match.",
    RESET_PASSWORD_SUCCESS: "Your password has been successfully reset. Please login again.",
    GET_MY_MATCHES_SUCCESS: "Fetched my matches successfully.",
    GET_MY_MATCHES_ERROR: "Something went wrong while fetching your matches. Please contact support.",
    POST_MATCH_STATUS_SUCCESS: "Match Status updated successfully",
    POST_MATCH_STATUS_ERROR: "Something went wrong while updating the match status. Please contact support.",
    DOWNLOAD_USER_REPORT_SUCCESS: "User report downloaded successfully",
    DOWNLOAD_USER_REPORT_ERROR: "Something went wrong while downloading user report. Please try again",
    NO_DATA_FOUND:"No Data Found"
}

const chatbotConstants = {
    consistencyLowMsg: "Low consistency refers to a lack of predictability, reliability, and dependability in one's words, actions, and behaviors within a relationship.",
    consistencyHighMsg: "High consistency refers to a strong level of predictability, reliability, and dependability in one's words, actions, and behaviors within a relationship.",
}
const rules = {
    DATE_TIME_FORMAT: 'YYYY-MM-DD HH:mm:ss.000'
}

const chatbotQuestionIds = {
    raceId: '5fd2e9f1-74f0-49f5-b809-5b2544bbc938',
    religiousId: 'b3b84220-6acb-437d-a9d9-2761b28b8536',
    politicalId: '87375b96-6381-40dd-8939-19633ac64cbb',
    childId: 'aaee5262-bdc7-4c4c-824e-c7b4a4c27d12',
    physicalId: '9e549445-052c-4a66-a36b-516d6c4a72d5',
    conservativeId: '4fbdf57c-2736-43a5-91e8-ed50c6c5338c',
    middleRoadId: 'f978b984-e3e5-490c-b311-5994969b2ffb',
    liberalId: '74269fe9-d1a5-426c-87db-321d806681e9',
    qualityId: 'c4358256-23d4-48ed-8898-dd773fd34f6d',
    valueId: '4c856940-5b7e-4cf7-8884-e6ecbe05f39a',
    lifeStyleId: '401ecb08-35ee-4dd4-a495-90ab8a79baf2',
    physicalPreferenceId:'9e549445-052c-4a66-a36b-516d6c4a72d5',
    agePreferenceId:'f3497527-4397-421c-b0a0-3c08ddf246d5'
}

let personalityAssessmentLogic = [{
    "id": "403bc0e5-e5f0-4588-86ea-a28eaf317a2a",
    "category": "Extraversion",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "861be1c7-d29b-4606-84fa-62a34f60ff14",
    "category": "Agreeableness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "384bed7b-511f-4061-80af-30fdc735bc87",
    "category": "Conscientiousness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7",
    "category": "Emotional Stability",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763",
    "category": "Intellect/Imagination",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "915fd7fc-dbd5-4312-a8e9-c3cf2370c13b",
    "category": "Extraversion",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "641d28ef-989f-4fc2-bf2b-e7bb5b29516a",
    "category": "Agreeableness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "cf769599-1222-47d1-aca5-3ca5182ab45a",
    "category": "Conscientiousness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "e289a73a-d089-4ba1-81e9-6d2cdc9a8965",
    "category": "Emotional Stability",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "8718ae96-b2a0-4d5c-bf8c-1cbe6b40ca39",
    "category": "Intellect/Imagination",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "d70eeb11-f53a-4dd4-9796-f075b58120cc",
    "category": "Extraversion",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "df1c1310-4fa6-459d-a171-76135135d233",
    "category": "Agreeableness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "ad469dc9-685e-485f-a667-94f012db2c01",
    "category": "Conscientiousness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "0e0bf710-863e-447f-ae3e-d0ab3a117276",
    "category": "Emotional Stability",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "760b0bd5-7fd7-4f85-90fa-b03a17b2663d",
    "category": "Intellect/Imagination",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "5c535bfd-c9a1-459d-9741-303adc75264f",
    "category": "Extraversion",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "4f9c6558-7e3a-4d54-9e95-33f5209af061",
    "category": "Agreeableness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "5deec5bf-1be6-4a09-9ed6-2af450b11522",
    "category": "Conscientiousness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "2d67160b-28ec-4c72-8e7f-54d0cc264c58",
    "category": "Emotional Stability",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "ad0e48a5-9f16-4348-a2a7-bbb9b9569132",
    "category": "Intellect/Imagination",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "c8c49b9b-b164-4b11-8dac-49db4e452d46",
    "category": "Extraversion",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "888d078b-7276-47bd-8dc3-77fe9ca452f1",
    "category": "Agreeableness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "c33ec4a6-308f-4a21-b5f9-938d5c6681b3",
    "category": "Conscientiousness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "0e313ea5-442b-40d9-921e-46b786bc5c5a",
    "category": "Emotional Stability",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "1e1a51a5-ebb2-4146-8181-944360337634",
    "category": "Intellect/Imagination",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "e7453f77-05fd-46f8-bc8b-f586bafaca37",
    "category": "Extraversion",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "7f75d44f-1b4e-43ef-ace9-45b6a84559c8",
    "category": "Agreeableness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "96677aa2-fc1d-41f7-b771-7095d6360b27",
    "category": "Conscientiousness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "ad7f5e84-36d4-40f2-96b5-9f31de6bdc52",
    "category": "Emotional Stability",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "4fd48fa8-fbfe-4633-aaeb-da6cce48052f",
    "category": "Intellect/Imagination",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "0d7bf49c-123a-445f-81b7-b3545d029a15",
    "category": "Extraversion",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "631e4d48-7af5-41e6-bed7-18bfc23e3075",
    "category": "Agreeableness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "d9beed6c-199f-4c5e-930e-30733e28fcfa",
    "category": "Conscientiousness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "57e0b354-4002-413a-9f77-731d3df3e97f",
    "category": "Emotional Stability",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "d7ed001f-59fd-448e-8f33-b08392adb308",
    "category": "Intellect/Imagination",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "ad1e0e4d-9f11-4b0f-9f92-aba8255871e1",
    "category": "Extraversion",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "f99078be-198c-45e2-87f0-50778d47ba33",
    "category": "Agreeableness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "86b30f46-b238-4c9b-bdf2-23b755e58d1c",
    "category": "Conscientiousness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "eb645d65-e663-4ef6-9626-a80db0ce03f4",
    "category": "Emotional Stability",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "78c48b8e-4047-4ad4-b440-936fe8213444",
    "category": "Intellect/Imagination",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "4071bb99-4d50-4240-8f82-1b75df28e1b2",
    "category": "Extraversion",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "aaa5a9b4-0d8a-4fb4-9464-274814047dc5",
    "category": "Agreeableness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "d5359d99-200c-473c-9e04-8731b9efd547",
    "category": "Conscientiousness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "07789761-9078-43cc-9e08-52b96496375a",
    "category": "Emotional Stability",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "7ffd6943-8f22-42b1-b4e1-8b5baae653be",
    "category": "Intellect/Imagination",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "8e064194-c2db-479b-88c4-8cde80d617e4",
    "category": "Extraversion",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "9b2e88c8-887a-4cdc-8224-e5e1d9b67cb0",
    "category": "Agreeableness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "9fc5ef51-c423-4658-ad83-e3cd18121eb4",
    "category": "Conscientiousness",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    },
},
{
    "id": "47d01cac-820b-4150-8335-d961da43edfb",
    "category": "Emotional Stability",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 5,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 4,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 2,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 1
    },
},
{
    "id": "4c8506f2-b8cf-41de-bb00-41a06f17ddec",
    "category": "Intellect/Imagination",
    "optionScoringScale": {
        "403bc0e5-e5f0-4588-86ea-a28eaf317a2a": 1,
        "861be1c7-d29b-4606-84fa-62a34f60ff14": 2,
        "384bed7b-511f-4061-80af-30fdc735bc87": 3,
        "34d398d9-9e3e-4ff6-a3e2-42c6ee7671d7": 4,
        "e3a3fbf4-31ba-440d-a8ba-9a243e2c9763": 5
    }
}]
export {
    httpStatusCodes,
    messages,
    rules,
    chatbotConstants,
    chatbotQuestionIds,
    personalityAssessmentLogic
}